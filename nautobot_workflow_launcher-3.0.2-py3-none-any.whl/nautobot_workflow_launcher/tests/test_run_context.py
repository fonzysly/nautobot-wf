"""Tests for the script reporting SDK: ctx dispatch, structured results and artifact caps."""

# pylint: disable=protected-access

import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from nautobot_workflow_launcher import executors, run_context


class ScriptSignatureTestCase(unittest.TestCase):
    """run(params) must keep working while run(params, ctx) opts into the SDK."""

    def test_legacy_single_argument_script_is_not_given_a_context(self):
        def run(params):  # noqa: ARG001
            return None

        self.assertFalse(executors._script_accepts_context(run))

    def test_ctx_parameter_receives_the_context(self):
        def run(params, ctx):  # noqa: ARG001
            return None

        self.assertTrue(executors._script_accepts_context(run))

    def test_context_parameter_receives_the_context(self):
        def run(params, context=None):  # noqa: ARG001
            return None

        self.assertTrue(executors._script_accepts_context(run))

    def test_dependency_injection_parameter_does_not_receive_the_context(self):
        def run(params, api_func=None):  # noqa: ARG001
            return None

        self.assertFalse(executors._script_accepts_context(run))

    def test_var_positional_script_does_not_receive_the_context(self):
        def run(*args):  # noqa: ARG001
            return None

        self.assertFalse(executors._script_accepts_context(run))

    def test_keyword_only_second_parameter_is_not_treated_as_positional(self):
        def run(params, *, ctx=None):  # noqa: ARG001
            return None

        self.assertFalse(executors._script_accepts_context(run))


class StructuredResultTestCase(unittest.TestCase):
    """Structured results are normalized and sanitized before they reach the UI."""

    def test_plain_return_values_are_not_structured(self):
        self.assertIsNone(run_context.normalize_structured_result("done"))
        self.assertIsNone(run_context.normalize_structured_result({"unrelated": 1}))

    def test_summary_and_metrics_are_normalized(self):
        structured = run_context.normalize_structured_result(
            {"summary": "Created 3 interfaces", "metrics": {"created": 3}}
        )

        self.assertEqual(
            structured,
            {
                "summary": "Created 3 interfaces",
                "metrics": [{"label": "created", "value": "3"}],
            },
        )

    def test_unsafe_link_schemes_are_dropped(self):
        structured = run_context.normalize_structured_result(
            {
                "links": [
                    {"label": "ok", "url": "/dcim/devices/1/"},
                    {"label": "external", "url": "https://example.test/x"},
                    {"label": "xss", "url": "javascript:alert(1)"},
                    {"label": "data", "url": "data:text/html;base64,AAAA"},
                    {"label": "protocol relative", "url": "//evil.test"},
                ]
            }
        )

        self.assertEqual([link["label"] for link in (structured or {}).get("links", [])], ["ok", "external"])

    def test_table_rows_accept_dicts_and_lists_and_are_capped(self):
        rows = [{"a": index, "b": index} for index in range(run_context.MAX_TABLE_ROWS + 10)]
        structured = run_context.normalize_structured_result({"table": {"columns": ["a", "b"], "rows": rows}})

        table = (structured or {}).get("table", {})
        self.assertEqual(len(table.get("rows", [])), run_context.MAX_TABLE_ROWS)
        self.assertTrue(table.get("truncated"))

    def test_table_without_columns_is_rejected(self):
        self.assertIsNone(run_context.normalize_structured_result({"table": {"rows": [[1]]}}))

    def test_changed_entries_strip_unsafe_urls_but_keep_labels(self):
        structured = run_context.normalize_structured_result(
            {"changed": [{"label": "Device A", "url": "javascript:alert(1)"}]}
        )

        self.assertEqual((structured or {}).get("changed"), [{"label": "Device A", "url": ""}])


class WorkflowContextTestCase(unittest.TestCase):
    """The context reports progress and messages through the supplied callbacks."""

    def _context(self, **kwargs):
        run = SimpleNamespace(inputs={"a": 1}, requested_by="tester")
        return run_context.WorkflowContext(run, "act", **kwargs)

    def test_progress_is_clamped_and_forwarded(self):
        seen = []
        ctx = self._context(on_progress=lambda **kwargs: seen.append(kwargs))

        ctx.progress(150, "nearly")
        ctx.progress(-10)

        self.assertEqual(seen[0], {"percent": 100, "message": "nearly", "step": None})
        self.assertEqual(seen[1], {"percent": 0, "message": None, "step": None})

    def test_non_numeric_progress_is_ignored(self):
        seen = []
        ctx = self._context(on_progress=lambda **kwargs: seen.append(kwargs))

        ctx.progress("soon")

        self.assertEqual(seen, [])

    def test_messages_are_severity_tagged(self):
        lines = []
        ctx = self._context(on_message=lines.append)

        ctx.info("hello")
        ctx.warn("careful")
        ctx.error("broken")

        self.assertEqual(lines, ["INFO: hello", "WARNING: careful", "ERROR: broken"])

    def test_result_rejects_unknown_keys(self):
        ctx = self._context()

        with self.assertRaises(ValueError):
            ctx.result(summary="ok", bogus=1)

    def test_result_accumulates_and_normalizes(self):
        ctx = self._context()

        ctx.result(summary="first")
        ctx.result(metrics={"count": 2})

        self.assertEqual(
            ctx.get_structured_result(),
            {
                "summary": "first",
                "metrics": [{"label": "count", "value": "2"}],
            },
        )


class ArtifactLimitTestCase(unittest.TestCase):
    """Oversized artifacts fail loudly instead of being silently truncated."""

    def _context(self):
        run = SimpleNamespace(pk="abc", inputs={}, requested_by="tester")
        return run_context.WorkflowContext(run, "act")

    def test_artifact_over_the_per_artifact_cap_is_rejected(self):
        ctx = self._context()

        with (
            patch.object(run_context, "_artifact_max_bytes", return_value=10),
            patch.object(run_context, "_artifact_run_max_bytes", return_value=1000),
        ):
            with self.assertRaises(run_context.ArtifactTooLargeError):
                ctx.artifact("big.txt", "x" * 50)

    def test_artifact_over_the_per_run_cap_is_rejected(self):
        ctx = self._context()
        queryset = MagicMock()
        queryset.values_list.return_value = [900]

        with (
            patch.object(run_context, "_artifact_max_bytes", return_value=1000),
            patch.object(run_context, "_artifact_run_max_bytes", return_value=1000),
            patch("nautobot_workflow_launcher.models.WorkflowRunArtifact") as artifact_model,
        ):
            artifact_model.objects.filter.return_value = queryset
            with self.assertRaises(run_context.ArtifactTooLargeError):
                ctx.artifact("more.txt", "x" * 200)

    def test_artifact_requires_a_name(self):
        ctx = self._context()

        with self.assertRaises(ValueError):
            ctx.artifact("", "content")


class UrlSafetyTestCase(unittest.TestCase):
    """Server-side URL validation mirrors the client's isSafeUrl."""

    def test_accepts_relative_and_http_urls(self):
        self.assertTrue(run_context.is_safe_url("/dcim/devices/"))
        self.assertTrue(run_context.is_safe_url("http://example.test"))
        self.assertTrue(run_context.is_safe_url("https://example.test"))

    def test_rejects_dangerous_and_protocol_relative_urls(self):
        for value in ("javascript:alert(1)", "data:text/html,x", "//evil.test", "", None, 5):
            self.assertFalse(run_context.is_safe_url(value))
