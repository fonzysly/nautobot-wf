# v2.5 Release Notes

This document describes all new features and changes in the release. The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Release Overview

- Added ServiceNow-backed scheduling so workflows can validate a change ticket and align execution with the approved change window.
- Added schedule metadata tracking, sync logic, and cancellation handling for deferred workflow runs.
- Expanded test coverage and user documentation for the new scheduling flow.

## [v2.5.0 (2026-06-08)](https://github.com/Network-Operations/nautobot-app-workflow-launcher/releases/tag/v2.5.0)

### Added

- Added a ServiceNow integration client that validates change tickets, normalizes remote change-window data, and enforces execution-time approval and state checks.
- Added workflow scheduling helpers and persisted schedule metadata so ServiceNow-backed runs can be resynced against the source change window before execution.
- Added a database migration for schedule metadata fields used to track the external record, last sync status, and effective window timestamps.
- Added launch-form and execution tests covering ServiceNow ticket normalization, change-window validation, and schedule resync behavior.

### Changed

- Changed the workflow launch UI and view handling to support ServiceNow as a first-class execution mode alongside immediate and manually scheduled runs.
- Changed scheduled-job execution and task coordination so deferred runs can reschedule or stop cleanly when the backing ServiceNow window changes.
- Changed README guidance to document the ServiceNow external integration requirements and scheduled-run cancellation behavior.

### Fixed

- Fixed default ServiceNow state handling so blocked state checks use a clearer, normalized token set for review, authorization, cancellation, and closed states.
- Fixed change-window synchronization to update the queued job start time when the upstream ServiceNow schedule moves.