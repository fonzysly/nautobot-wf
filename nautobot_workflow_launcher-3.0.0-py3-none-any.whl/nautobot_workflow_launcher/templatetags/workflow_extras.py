"""Template tags for workflow launcher."""

import json
import re

from django import template
from django.templatetags.static import static
from django.utils import dateformat, timezone
from django.utils.html import format_html
from django.utils.safestring import mark_safe

from nautobot_workflow_launcher import __version__
from nautobot_workflow_launcher.ui_helpers import (
    LIVE_RUN_STATUSES,
    accent_index,
    awx_status_meta,
    format_duration,
    format_minutes,
    run_status_meta,
)
from nautobot_workflow_launcher.ui_helpers import relative_time as _relative_time

register = template.Library()

ICON_PATTERN = re.compile(r"^mdi-[a-z0-9-]+$")
_JSON_SCRIPT_ESCAPES = {ord(">"): "\\u003E", ord("<"): "\\u003C", ord("&"): "\\u0026"}


@register.filter(name="to_json")
def to_json(value):
    """Serialize a Python value to a JSON string that is safe to embed in <script> tags."""
    try:
        return mark_safe(json.dumps(value).translate(_JSON_SCRIPT_ESCAPES))  # noqa: S308
    except (TypeError, ValueError):
        return "[]"


@register.simple_tag
def calculate_duration(start_time, end_time):
    """Calculate and format duration between two datetime objects."""
    if not start_time or not end_time:
        return "-"
    return format_duration((end_time - start_time).total_seconds())


@register.simple_tag
def wl_static(path):
    """Return a static URL cache-busted with the app version."""
    return f"{static(path)}?v={__version__}"


@register.simple_tag
def status_badge(status, size=""):
    """Render a workflow run status pill (icon + label, never color alone)."""
    meta = run_status_meta(status)
    classes = f"wl-status wl-tone-{meta['tone']}"
    if size == "lg":
        classes += " wl-status--lg"
    if status in LIVE_RUN_STATUSES:
        icon = format_html('<span class="wl-status__dot" aria-hidden="true"></span>')
    else:
        icon = format_html('<span class="mdi {}" aria-hidden="true"></span>', meta["icon"])
    return format_html('<span class="{}" data-status="{}">{}{}</span>', classes, status or "", icon, meta["label"])


@register.simple_tag
def awx_status_badge(status):
    """Render an AWX job status pill."""
    meta = awx_status_meta(status)
    return format_html(
        '<span class="wl-status wl-tone-{}"><span class="mdi {}" aria-hidden="true"></span>{}</span>',
        meta["tone"],
        meta["icon"],
        str(status or "unknown").title(),
    )


@register.filter
def workflow_icon(workflow):
    """Return the validated MDI icon class declared by `icon:` in the workflow YAML, if any."""
    raw_definition = getattr(workflow, "raw_definition", None)
    icon = raw_definition.get("icon") if isinstance(raw_definition, dict) else None
    if not isinstance(icon, str):
        return ""
    icon = icon.strip().lower()
    if not icon.startswith("mdi-"):
        icon = f"mdi-{icon}"
    return icon if ICON_PATTERN.match(icon) else ""


@register.filter
def initials(value):
    """Return up to two initials for a name ('Configure Interface' -> 'CI', 'jdoe' -> 'JD')."""
    words = re.findall(r"[A-Za-z0-9]+", str(value or ""))
    if not words:
        return "?"
    if len(words) == 1:
        return words[0][:2].upper()
    return (words[0][0] + words[1][0]).upper()


@register.filter
def accent(value):
    """Return a stable accent bucket (0-7) for a string."""
    return accent_index(value)


@register.simple_tag
def workflow_avatar(workflow, size=""):
    """Render a workflow avatar: its YAML icon, or initials, tinted by category."""
    icon = workflow_icon(workflow)
    accent_bucket = accent_index(getattr(workflow, "category", "") or getattr(workflow, "name", ""))
    size_class = f" wl-avatar--{size}" if size in ("sm", "lg") else ""
    if icon:
        inner = format_html('<span class="mdi {}"></span>', icon)
    else:
        inner = initials(getattr(workflow, "name", ""))
    return format_html(
        '<span class="wl-avatar wl-accent-{}{}" aria-hidden="true">{}</span>', accent_bucket, size_class, inner
    )


@register.simple_tag
def user_avatar(username):
    """Render a small round avatar with a user's initials."""
    return format_html(
        '<span class="wl-avatar wl-avatar--xs wl-avatar--round wl-accent-{}" aria-hidden="true">{}</span>',
        accent_index(username),
        initials(username),
    )


@register.filter
def relative_time(value):
    """Return compact relative time text ('5m ago', 'in 2h')."""
    return _relative_time(value)


@register.simple_tag
def time_ago(value, fmt="M d, Y H:i"):
    """Render a <time> element showing relative time, with the absolute timestamp as tooltip."""
    if not value:
        return ""
    absolute = dateformat.format(timezone.localtime(value), fmt)
    return format_html(
        '<time datetime="{}" title="{}" data-wl-relative>{}</time>', value.isoformat(), absolute, _relative_time(value)
    )


@register.filter
def duration(seconds):
    """Format seconds as '45s', '3m 12s' or '2h 5m'."""
    return format_duration(seconds)


@register.filter
def minutes_display(total_minutes):
    """Format minutes as '12h 30m'."""
    return format_minutes(total_minutes)


@register.filter
def css_percent(value):
    """Return a clamped, locale-independent percentage string for inline CSS (e.g. '42.5%')."""
    try:
        number = max(0.0, min(100.0, float(value)))
    except (TypeError, ValueError):
        number = 0.0
    return f"{number:.1f}%"


@register.filter
def widget_attr(bound_field, name):
    """Return an attribute of a bound field's widget (e.g. 'data-required')."""
    try:
        return bound_field.field.widget.attrs.get(name, "")
    except AttributeError:
        return ""


@register.filter
def short_id(value):
    """Return the first 8 characters of an identifier."""
    return str(value or "")[:8]
