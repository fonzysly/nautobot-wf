"""Presentation helpers shared by views, template tags and the live-progress API."""

import json
import zlib

from django.utils import timezone
from django.utils.html import format_html
from nautobot.apps.templatetags import render_markdown

TERMINAL_RUN_STATUSES = frozenset({"success", "failed", "partial", "canceled"})
LIVE_RUN_STATUSES = frozenset({"running", "pending"})

# Canonical display order for run statuses (active first, then outcomes).
RUN_STATUS_ORDER = ("running", "pending", "scheduled", "success", "partial", "failed", "canceled")

RUN_STATUS_META = {
    "pending": {"label": "Pending", "tone": "neutral", "icon": "mdi-timer-sand"},
    "scheduled": {"label": "Scheduled", "tone": "violet", "icon": "mdi-calendar-clock"},
    "running": {"label": "Running", "tone": "primary", "icon": "mdi-progress-clock"},
    "success": {"label": "Success", "tone": "success", "icon": "mdi-check-circle"},
    "failed": {"label": "Failed", "tone": "danger", "icon": "mdi-close-circle"},
    "canceled": {"label": "Canceled", "tone": "neutral", "icon": "mdi-cancel"},
    "partial": {"label": "Partial", "tone": "warning", "icon": "mdi-alert-circle"},
}

AWX_STATUS_META = {
    "successful": {"tone": "success", "icon": "mdi-check-circle"},
    "failed": {"tone": "danger", "icon": "mdi-close-circle"},
    "error": {"tone": "danger", "icon": "mdi-alert-octagon"},
    "running": {"tone": "primary", "icon": "mdi-progress-clock"},
    "canceled": {"tone": "neutral", "icon": "mdi-cancel"},
}

STEP_STATUS_META = {
    "success": {"label": "Succeeded", "tone": "success", "icon": "mdi-check"},
    "failed": {"label": "Failed", "tone": "danger", "icon": "mdi-close"},
    "skipped": {"label": "Skipped", "tone": "neutral", "icon": "mdi-debug-step-over"},
    "running": {"label": "Running", "tone": "primary", "icon": "mdi-loading"},
    "pending": {"label": "Waiting", "tone": "neutral", "icon": "mdi-circle-outline"},
    "not_run": {"label": "Not run", "tone": "neutral", "icon": "mdi-minus"},
}

# Distinct per-status colors for CSS-only charts (statuses sharing a tone still need separate colors).
STATUS_CHART_COLORS = {
    "success": "var(--bs-success)",
    "failed": "var(--bs-danger)",
    "partial": "var(--bs-warning)",
    "running": "var(--bs-primary)",
    "pending": "var(--bs-primary-border-subtle)",
    "scheduled": "var(--wl-violet)",
    "canceled": "var(--bs-secondary)",
}

PHASE_ORDER = ("pre", "main", "post")
PHASE_LABELS = {"pre": "Pre-actions", "main": "Main actions", "post": "Post-actions"}
PHASE_RANK = {phase: index for index, phase in enumerate(PHASE_ORDER)}

ACTION_TYPE_META = {
    "nautobot": {"label": "Nautobot script", "icon": "mdi-language-python"},
    "awx": {"label": "AWX job", "icon": "mdi-ansible"},
}

ACCENT_BUCKETS = 8
STEP_ERROR_MAX_LENGTH = 400


def run_status_meta(status):
    """Return label/tone/icon metadata for a workflow run status."""
    meta = RUN_STATUS_META.get(status)
    if meta:
        return meta
    label = str(status or "Unknown").replace("_", " ").title()
    return {"label": label, "tone": "neutral", "icon": "mdi-help-circle"}


def awx_status_meta(status):
    """Return tone/icon metadata for an AWX job status."""
    return AWX_STATUS_META.get(status, {"tone": "neutral", "icon": "mdi-timer-sand"})


def accent_index(value, buckets=ACCENT_BUCKETS):
    """Return a stable accent color bucket for a string (stable across processes, unlike hash())."""
    return zlib.crc32(str(value or "").encode("utf-8")) % buckets


def format_duration(total_seconds):
    """Format a duration in seconds as compact text such as '45s', '3m 12s' or '2h 5m'."""
    if total_seconds is None:
        return "-"
    total_seconds = int(total_seconds)
    if total_seconds < 0:
        return "-"
    if total_seconds < 60:
        return f"{total_seconds}s"
    if total_seconds < 3600:
        return f"{total_seconds // 60}m {total_seconds % 60}s"
    return f"{total_seconds // 3600}h {(total_seconds % 3600) // 60}m"


def format_bytes(total_bytes):
    """Format a byte count as compact text such as '812 B', '4.2 KB' or '1.1 MB'."""
    size = float(total_bytes or 0)
    if size < 1024:
        return f"{int(size)} B"
    for unit in ("KB", "MB", "GB"):
        size /= 1024
        if size < 1024:
            return f"{size:.1f} {unit}"
    return f"{size:.1f} TB"


def format_minutes(total_minutes):
    """Format a (possibly negative) number of minutes as '12h 30m' / '45m'."""
    total_minutes = int(round(total_minutes or 0))
    sign = "-" if total_minutes < 0 else ""
    hours, minutes = divmod(abs(total_minutes), 60)
    if hours:
        return f"{sign}{hours}h {minutes}m"
    return f"{sign}{minutes}m"


def relative_time(value, now=None):
    """Return a compact relative time such as '5m ago' or 'in 2h'."""
    if not value:
        return ""
    now = now or timezone.now()
    seconds = int((now - value).total_seconds())
    future = seconds < 0
    seconds = abs(seconds)
    if seconds < 45:
        return "just now"
    if seconds < 3600:
        text = f"{max(1, seconds // 60)}m"
    elif seconds < 86400:
        text = f"{seconds // 3600}h"
    elif seconds < 30 * 86400:
        text = f"{seconds // 86400}d"
    elif seconds < 365 * 86400:
        text = f"{seconds // (30 * 86400)}mo"
    else:
        text = f"{seconds // (365 * 86400)}y"
    return f"in {text}" if future else f"{text} ago"


def sorted_actions(actions):
    """Sort workflow actions in execution order: pre → main → post, then order/name like the executor."""
    return sorted(
        actions,
        key=lambda action: (PHASE_RANK.get(action.phase, len(PHASE_ORDER)), action.order, action.name),
    )


def describe_action(action):
    """Return display metadata for a workflow action definition."""
    type_meta = ACTION_TYPE_META.get(action.action_type, {"label": "Action", "icon": "mdi-cog-outline"})
    detail = ""
    if action.action_type == "awx" and action.awx_template_id:
        detail = f"Template {action.awx_template_id}"
    elif action.action_type == "nautobot" and action.script_path:
        detail = action.script_path.lstrip("/")
    return {
        "phase": action.phase,
        "phase_label": PHASE_LABELS.get(action.phase, action.phase.title()),
        "name": action.name,
        "type": action.action_type,
        "type_label": type_meta["label"],
        "type_icon": type_meta["icon"],
        "detail": detail,
        "conditional": bool((action.when or "").strip()),
    }


def _make_step(phase, name, action, result):
    """Build one pipeline step payload."""
    if action is not None:
        step = describe_action(action)
    else:
        step = {
            "phase": phase,
            "phase_label": PHASE_LABELS.get(phase, phase.title()),
            "name": name,
            "type": None,
            "type_label": "Action",
            "type_icon": "mdi-cog-outline",
            "detail": "",
            "conditional": False,
        }

    status = "pending"
    error = ""
    extras = {
        "duration_seconds": None,
        "duration_display": "",
        "progress_percent": None,
        "progress_message": "",
        "current_step": "",
        "structured": None,
        "return_value": None,
    }
    if isinstance(result, dict):
        error = str(result.get("error") or "")
        if result.get("status") in STEP_STATUS_META:
            status = result["status"]
        else:
            status = "failed" if error else "success"

        duration = result.get("duration_seconds")
        if isinstance(duration, int):
            extras["duration_seconds"] = duration
            extras["duration_display"] = format_duration(duration)

        progress = result.get("progress_percent")
        if isinstance(progress, int):
            extras["progress_percent"] = max(0, min(100, progress))

        extras["progress_message"] = str(result.get("progress_message") or "")
        extras["current_step"] = str(result.get("current_step") or "")
        extras["structured"] = result.get("structured") or None
        extras["return_value"] = result.get("return_value")

    step.update(extras)
    step.update(
        {
            "status": status,
            "error": error,
            "error_summary": (error[: STEP_ERROR_MAX_LENGTH - 1] + "…")
            if len(error) > STEP_ERROR_MAX_LENGTH
            else error,
        }
    )
    return step


def collect_structured_results(steps):
    """Return the structured results reported by each step, in pipeline order."""
    return [
        {
            "name": step["name"],
            "phase": step["phase"],
            "phase_label": step["phase_label"],
            "tone": step.get("tone", "neutral"),
            "structured": step["structured"],
        }
        for step in steps
        if step.get("structured")
    ]


def build_run_steps(workflow_run):
    """Return the ordered pipeline (pre → main → post) with the per-action status of a workflow run."""
    phase_results = workflow_run.phase_results if isinstance(workflow_run.phase_results, dict) else {}
    actions = sorted_actions(workflow_run.workflow.actions.all()) if workflow_run.workflow_id else []

    by_phase = {phase: [] for phase in PHASE_ORDER}
    defined_names = {phase: set() for phase in PHASE_ORDER}
    for action in actions:
        phase = action.phase if action.phase in by_phase else "main"
        results = (phase_results.get(phase) or {}).get("results") or {}
        by_phase[phase].append(_make_step(phase, action.name, action, results.get(action.name)))
        defined_names[phase].add(action.name)

    # Keep results for actions that were removed from the workflow definition after this run.
    for phase in PHASE_ORDER:
        results = (phase_results.get(phase) or {}).get("results") or {}
        for name, result in results.items():
            if name not in defined_names[phase]:
                by_phase[phase].append(_make_step(phase, name, None, result))

    steps = [step for phase in PHASE_ORDER for step in by_phase[phase]]

    if workflow_run.status in TERMINAL_RUN_STATUSES:
        for step in steps:
            if step["status"] in ("pending", "running"):
                step["status"] = "not_run" if step["status"] == "pending" else "failed"
    elif workflow_run.status == "running" and not any(step["status"] == "running" for step in steps):
        # Fallback for runs started before per-step state was persisted.
        for step in steps:
            if step["status"] == "pending":
                step["status"] = "running"
                break

    for step in steps:
        meta = STEP_STATUS_META[step["status"]]
        step.update({"status_label": meta["label"], "tone": meta["tone"], "icon": meta["icon"]})
    return steps


def _choice_labels(choices):
    """Map static choice values to labels (dynamic/Jinja choices are returned empty)."""
    if not isinstance(choices, list):
        return {}
    labels = {}
    for choice in choices:
        if isinstance(choice, dict) and "value" in choice:
            labels[str(choice["value"])] = str(choice.get("label", choice["value"]))
    return labels


def _resolve_objects(workflow_input, value, user):
    """Resolve stored object primary keys to display names/links the user is allowed to see."""
    values = value if isinstance(value, list) else [value]
    ids = []
    for item in values:
        if isinstance(item, dict):
            item = item.get("id") or item.get("pk")
        if item not in (None, ""):
            ids.append(str(item))

    resolved = {}
    model = workflow_input.content_type.model_class() if workflow_input.content_type else None
    lookup_ids = [pk for pk in ids if pk != "__create__"]
    if model is not None and lookup_ids:
        queryset = model.objects.all()
        if hasattr(queryset, "restrict"):
            queryset = queryset.restrict(user, "view")
        try:
            resolved = {str(obj.pk): obj for obj in queryset.filter(pk__in=lookup_ids)}
        except Exception:  # Malformed identifiers must never break the run page.
            resolved = {}

    objects = []
    for pk in ids:
        obj = resolved.get(pk)
        url = ""
        label = "Create new" if pk == "__create__" else pk
        if obj is not None:
            label = getattr(obj, "display", None) or str(obj)
            try:
                url = obj.get_absolute_url()
            except Exception:
                url = ""
        objects.append({"id": pk, "label": label, "url": url, "resolved": obj is not None})
    return objects


def _table_rows(definition, value):
    """Return (headers, rows) for a list-of-dictionaries input value."""
    column_defs = [col for col in ((definition.columns if definition else None) or []) if isinstance(col, dict)]
    headers = {col.get("key"): col.get("label") or col.get("key") for col in column_defs}
    columns = [col.get("key") for col in column_defs]
    for item in value:
        for column in item:
            if column not in columns:
                columns.append(column)
    rows = [["" if item.get(column) is None else item.get(column) for column in columns] for item in value]
    return [headers.get(column, column) for column in columns], rows


def build_input_rows(workflow_run, user):
    """Return display-ready rows for the inputs submitted with a workflow run."""
    inputs = workflow_run.inputs if isinstance(workflow_run.inputs, dict) else {}
    definitions = {}
    if workflow_run.workflow_id:
        definitions = {wi.key: wi for wi in workflow_run.workflow.inputs.select_related("content_type")}
    ordered_keys = [key for key in definitions if key in inputs] + [key for key in inputs if key not in definitions]

    rows = []
    for key in ordered_keys:
        value = inputs.get(key)
        definition = definitions.get(key)
        input_type = definition.input_type if definition else ""
        labels = _choice_labels(definition.choices) if definition else {}
        row = {"key": key, "label": definition.label if definition else key, "type": input_type}

        if value is None or value == "" or value == [] or value == {}:
            row["kind"] = "empty"
        elif definition and input_type in ("object", "multiobject") and definition.content_type:
            row["kind"] = "objects"
            row["objects"] = _resolve_objects(definition, value, user)
        elif isinstance(value, bool):
            row["kind"] = "bool"
            row["value"] = value
        elif isinstance(value, list) and all(isinstance(item, dict) for item in value):
            row["kind"] = "table"
            row["columns"], row["rows"] = _table_rows(definition, value)
        elif isinstance(value, list):
            row["kind"] = "list"
            row["items"] = [labels.get(str(item), str(item)) for item in value]
        elif isinstance(value, dict):
            row["kind"] = "json"
            row["pretty"] = json.dumps(value, indent=2, sort_keys=True, default=str)
        else:
            row["kind"] = "text"
            row["text"] = labels.get(str(value), str(value))
            row["raw"] = str(value) if str(value) in labels else ""
        rows.append(row)
    return rows


def render_workflow_guide(workflow):
    """Return sanitized HTML for a workflow's synced user guide, or an empty string when there is none."""
    content = (workflow.guide_content or "").strip()
    if not content:
        return ""
    if workflow.guide_format == "text":
        return format_html('<pre class="wl-guide__text">{}</pre>', content)
    # render_markdown sanitizes through nh3 with Nautobot's tag/attribute allowlist.
    return render_markdown(content)
