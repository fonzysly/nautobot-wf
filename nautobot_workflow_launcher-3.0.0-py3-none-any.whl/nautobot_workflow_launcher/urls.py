"""URL configuration for the workflow launcher plugin."""

from django.templatetags.static import static
from django.urls import include, path
from django.views.generic import RedirectView
from nautobot.apps.urls import NautobotUIViewSetRouter

from . import views

app_name = "nautobot_workflow_launcher"

# Create router and register WorkflowUIViewSet
router = NautobotUIViewSetRouter()
router.register("workflow", views.WorkflowUIViewSet)

urlpatterns = [
    path("problems/report/", views.ReportProblemView.as_view(), name="report_problem"),
    path("workflows_list/", views.WorkflowListView.as_view(), name="workflows_list"),
    path("workflows/<slug:key>/launch/", views.WorkflowRunCreateView.as_view(), name="workflow_launch"),
    path("workflows/<slug:key>/guide/", views.WorkflowGuideView.as_view(), name="workflow_guide"),
    path("workflows/<slug:key>/inputs/<slug:child>/options/", views.InputOptionsView.as_view(), name="input_options"),
    path("runs/", views.WorkflowRunListView.as_view(), name="workflow_run_list"),
    path("runs/<uuid:pk>/", views.WorkflowRunDetailView.as_view(), name="workflow_run"),
    path("runs/<uuid:pk>/progress/", views.WorkflowRunProgressView.as_view(), name="workflow_run_progress"),
    path(
        "runs/<uuid:pk>/artifacts/<uuid:artifact_pk>/",
        views.WorkflowRunArtifactView.as_view(),
        name="workflow_run_artifact",
    ),
    path("runs/<uuid:pk>/cancel/", views.WorkflowRunCancelView.as_view(), name="workflow_run_cancel"),
    path("reports/", views.WorkflowReportView.as_view(), name="workflow_report"),
    path("docs/", RedirectView.as_view(url=static("nautobot_workflow_launcher/docs/index.html")), name="docs"),
    path("", include(router.urls)),
]
