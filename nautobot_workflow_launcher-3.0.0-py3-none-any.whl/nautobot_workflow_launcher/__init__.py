"""App declaration for nautobot_workflow_launcher."""

# Metadata is inherited from Nautobot. If not including Nautobot in the environment, this should be added
import os
from importlib import metadata

from nautobot.apps import NautobotAppConfig

__version__ = metadata.version(__name__)


def _problem_report_recipients():
    """Return configured support recipients, preferring the plural environment variable."""
    raw = os.getenv("WORKFLOW_LAUNCHER_SUPPORT_EMAILS")
    if raw is None:
        raw = os.getenv("WORKFLOW_LAUNCHER_SUPPORT_EMAIL", "")
    return [address.strip() for address in raw.split(",") if address.strip()]


class WorkflowLauncherConfig(NautobotAppConfig):
    """App configuration for the nautobot_workflow_launcher app."""

    name = "nautobot_workflow_launcher"
    verbose_name = "Workflow Launcher"
    version = __version__
    author = "Tony Fynn-Cudjoe"
    description = "General-purpose workflow launcher for Nautobot"
    base_url = "workflow-launcher"
    required_settings = []
    default_settings = {
        "awx_external_integration_name": "AWX",
        "workflow_dir": "workflows",
        "filters_dir": "filters",
        "awx_poll_seconds": 5,
        "show_disabled": False,
        "show_add_new_item": os.getenv("SHOW_ADD_NEW_ITEM", "").split(","),
        # Artifacts are stored inline in the database, so both caps are enforced on write.
        "artifact_max_bytes": 1024 * 1024,
        "artifact_run_max_bytes": 10 * 1024 * 1024,
        "problem_report_recipients": _problem_report_recipients(),
        "problem_report_rate_limit_per_hour": 10,
    }
    caching_config = {}
    docs_view_name = "plugins:nautobot_workflow_launcher:docs"
    searchable_models = ["workflow"]


config = WorkflowLauncherConfig  # pylint:disable=invalid-name
