/*
 * Workflow launch page form engine (loaded after common.js).
 * Enhances the server-rendered #dynamic-form built by DynamicWorkflowForm in place:
 *   select[data-enhance="dropdown"]   searchable Bootstrap dropdown. The native select loses its name; a hidden proxy input
 *                                     right after it carries the value (single = plain string, multi = JSON array).
 *                                     Options load from <workflow>/inputs/<field>/options/ (preload, Jinja, dependencies, search).
 *   input[data-enhance="list"]        tag input; the original input keeps the JSON array value.
 *   input[data-enhance="list-dict"]   grid editor with CSV import and template download; the original input keeps the JSON rows.
 *   data-show-if-* / data-depends-on  progressive disclosure; hidden fields are reset and dependent dropdowns cascade-reset.
 * Visible fields are validated before submitting (summary in #wl-client-errors). The engine also records form-fill time,
 * drives the execution timing controls and shows required-field progress. Untrusted text (labels, options, CSV content,
 * validator messages, file names, server responses) is only written through textContent.
 */
(function () {
    "use strict";

    // ------------------------------------------------------------------------------------------------------------
    // Constants & utilities
    // ------------------------------------------------------------------------------------------------------------

    var PLACEHOLDER_LABEL = "Select\u2026";
    var NATIVE_PLACEHOLDER_LABEL = "\u2014 Select \u2014";
    var SEARCH_DEBOUNCE_MS = 300;
    var MIN_SEARCH_LENGTH = 2;
    var SEARCH_OPTION_THRESHOLD = 5;
    var CREATE_OPTION_VALUE = "__create__";
    var INLINE_ERROR_LIMIT = 5;
    var DEFAULT_MINUTES_AHEAD = 5;
    var DEFAULT_SCHEDULE_OFFSET_MINUTES = 10;
    var CLOCK_INTERVAL_MS = 1000;
    var BLOB_URL_TTL_MS = 10000;
    var TEXT_INPUT_TYPES = ["text", "number", "email", "url", "tel", "search", "password"];
    var SKIPPED_INPUT_TYPES = ["radio", "file", "submit", "button", "reset", "image"];
    var LABEL_EXCLUDED_SELECTOR =
        ".wl-field__required, .visually-hidden, .visually-hidden-focusable, .sr-only, [aria-hidden='true'], input, select, textarea";
    var CLICK_START_SELECTOR = "button, a, input, select, textarea, label";
    // Python `re` flag names (and single-letter JS flags) accepted in YAML validators.
    var REGEX_FLAGS = { i: "i", ignorecase: "i", m: "m", multiline: "m", s: "s", dotall: "s", u: "u", unicode: "u" };
    var SUBMIT_LABELS = {
        immediate: "Review changes",
        scheduled: "Review schedule",
        servicenow: "Review change window",
    };
    var SUBMITTING_LABEL = "Preparing review\u2026";
    var SUBMITTING_ICON_CLASS = "mdi mdi-loading wl-spin";
    var NOTICE_LEVELS = ["info", "success", "warning", "danger"];

    var ui = {};
    var fields = Object.create(null);
    var fieldOrder = [];
    var conditionalFields = [];
    var dependentsByName = Object.create(null);
    var labelCache = Object.create(null);
    var regexCache = Object.create(null);
    var reported = Object.create(null);
    var idCounter = 0;
    var preserveInitial = false;
    var submitting = false;
    var scheduleAutoDefault = false;

    function lib() {
        return window.WorkflowLauncher || null;
    }

    function onReady(callback) {
        var wl = lib();
        if (wl && typeof wl.onReady === "function") {
            wl.onReady(callback);
        } else if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", callback);
        } else {
            callback();
        }
    }

    function announce(message) {
        var wl = lib();
        if (wl && typeof wl.announce === "function") {
            wl.announce(message);
        }
    }

    function toArray(list) {
        return Array.prototype.slice.call(list || []);
    }

    function nextId(prefix) {
        idCounter += 1;
        return prefix + idCounter;
    }

    function createElement(tagName, className, text) {
        var element = document.createElement(tagName);
        if (className) {
            element.className = className;
        }
        if (text !== undefined && text !== null) {
            element.textContent = String(text);
        }
        return element;
    }

    function createIcon(iconName) {
        var icon = createElement("span", "mdi " + iconName);
        icon.setAttribute("aria-hidden", "true");
        return icon;
    }

    function createButton(className, iconName, text) {
        var button = createElement("button", className);
        button.type = "button";
        if (iconName) {
            button.appendChild(createIcon(iconName));
        }
        if (text) {
            button.appendChild(document.createTextNode(text));
        }
        return button;
    }

    function createOption(value, label) {
        var option = document.createElement("option");
        option.value = String(value);
        option.textContent = String(label);
        return option;
    }

    function clearChildren(element) {
        while (element && element.firstChild) {
            element.removeChild(element.firstChild);
        }
    }

    function insertAfter(element, reference) {
        reference.parentNode.insertBefore(element, reference.nextSibling);
    }

    function cssString(value) {
        if (window.CSS && typeof window.CSS.escape === "function") {
            return window.CSS.escape(value);
        }
        return String(value).replace(/["\\]/g, "\\$&");
    }

    function pluralize(count, singular, plural) {
        return count + " " + (count === 1 ? singular : plural || singular + "s");
    }

    function uniqueStrings(values) {
        var seen = Object.create(null);
        return values.filter(function (value) {
            if (!value || value in seen) {
                return false;
            }
            seen[value] = true;
            return true;
        });
    }

    function mergeTokenList(current, additions) {
        return uniqueStrings(String(current || "").split(/\s+/).concat(additions)).join(" ");
    }

    function setInvalid(element, invalid) {
        if (!element) {
            return;
        }
        if (invalid) {
            element.setAttribute("aria-invalid", "true");
        } else {
            element.removeAttribute("aria-invalid");
        }
    }

    function reportOnce(key, message, detail) {
        if (key in reported) {
            return;
        }
        reported[key] = true;
        if (detail === undefined) {
            console.error(message);
        } else {
            console.error(message, detail);
        }
    }

    function parseJson(text, fallback) {
        try {
            return JSON.parse(text);
        } catch (error) {
            return fallback;
        }
    }

    function parseJsonArray(text) {
        var parsed = text ? parseJson(text, null) : null;
        return Array.isArray(parsed) ? parsed : [];
    }

    function debounce(callback, wait) {
        var timer = null;
        function debounced() {
            var args = arguments;
            if (timer) {
                window.clearTimeout(timer);
            }
            timer = window.setTimeout(function () {
                timer = null;
                callback.apply(null, args);
            }, wait);
        }
        debounced.cancel = function () {
            if (timer) {
                window.clearTimeout(timer);
                timer = null;
            }
        };
        return debounced;
    }

    function prefersReducedMotion() {
        return Boolean(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
    }

    function scrollIntoViewCentered(element) {
        element.scrollIntoView({ behavior: prefersReducedMotion() ? "auto" : "smooth", block: "center" });
    }

    function safely(description, callback) {
        try {
            callback();
        } catch (error) {
            console.error("Workflow Launcher: " + description + " failed.", error);
        }
    }

    // Regexes come from workflow YAML: an invalid pattern means "no constraint" and is reported once.
    function normalizeRegexFlags(flags) {
        var names = Array.isArray(flags) ? flags : typeof flags === "string" ? flags.split(/[\s,|]+/) : [];
        var result = "";
        names.forEach(function (name) {
            var key = String(name).trim().replace(/^re\./i, "").toLowerCase();
            var flag = Object.prototype.hasOwnProperty.call(REGEX_FLAGS, key) ? REGEX_FLAGS[key] : "";
            if (flag && result.indexOf(flag) === -1) {
                result += flag;
            }
        });
        return result;
    }

    function compileRegex(pattern, flags) {
        var source = String(pattern);
        var flagString = normalizeRegexFlags(flags);
        var cacheKey = flagString + "/" + source;
        var regex = null;
        if (cacheKey in regexCache) {
            return regexCache[cacheKey];
        }
        try {
            regex = new RegExp(source, flagString);
        } catch (error) {
            // Python's UNICODE flag is implicit; JS "u" mode is stricter, so retry without it before giving up.
            if (flagString.indexOf("u") !== -1) {
                try {
                    regex = new RegExp(source, flagString.replace("u", ""));
                } catch (retryError) {
                    regex = null;
                }
            }
            if (!regex) {
                reportOnce("regex:" + cacheKey, "Workflow Launcher: ignoring invalid validator pattern " + JSON.stringify(source), error);
            }
        }
        regexCache[cacheKey] = regex;
        return regex;
    }

    function matchesValidator(validator, value) {
        var regex = validator && validator.regex ? compileRegex(validator.regex, validator.flags) : null;
        return !regex || regex.test(value);
    }

    function readValidators(element) {
        var raw;
        var parsed;
        if (!element) {
            return [];
        }
        if (element._wlValidators) {
            return element._wlValidators;
        }
        raw = element.getAttribute("data-validators");
        parsed = raw ? parseJson(raw, null) : [];
        if (!Array.isArray(parsed)) {
            reportOnce("validators:" + raw, "Workflow Launcher: ignoring invalid data-validators JSON", raw);
            parsed = [];
        }
        element._wlValidators = parsed.filter(function (validator) {
            return validator && typeof validator === "object";
        });
        return element._wlValidators;
    }

    // Label text without the required marker or visually hidden helper text.
    function readLabelText(label) {
        var text = "";
        toArray(label.childNodes).forEach(function (node) {
            if (node.nodeType === 3) {
                text += node.nodeValue;
            } else if (node.nodeType === 1 && !node.matches(LABEL_EXCLUDED_SELECTOR)) {
                text += node.textContent;
            }
        });
        return text
            .replace(/\s+/g, " ")
            .trim()
            .replace(/\s*\(required\)$/i, "")
            .replace(/\s*\*$/, "")
            .trim();
    }

    function findFieldLabelElement(field) {
        var group = field && field.group;
        if (!group) {
            return null;
        }
        return (
            group.querySelector("label.wl-field__label") ||
            toArray(group.querySelectorAll(".form-check-label")).filter(function (label) {
                return !label.closest(".wl-select__menu");
            })[0] ||
            group.querySelector('label[for="' + cssString("id_" + field.name) + '"]')
        );
    }

    function getFieldLabel(name) {
        var field = fields[name];
        var label;
        var text;
        if (name in labelCache) {
            return labelCache[name];
        }
        label = findFieldLabelElement(field || { name: name, group: document.getElementById("group_" + name) });
        text = label ? readLabelText(label) : "";
        if (!text && field) {
            text = field.source.getAttribute("data-label") || "";
        }
        labelCache[name] = text || name;
        return labelCache[name];
    }

    // ------------------------------------------------------------------------------------------------------------
    // Field registry & value access (getProxyOrReal, ctrlVal, getFieldValue)
    // ------------------------------------------------------------------------------------------------------------

    function depsOf(element) {
        var raw = element.getAttribute("data-depends-on");
        return raw
            ? raw
                  .split(",")
                  .map(function (dep) {
                      return dep.trim();
                  })
                  .filter(Boolean)
            : [];
    }

    function registerFields() {
        toArray(ui.root.querySelectorAll("input[name], select[name], textarea[name]")).forEach(function (control) {
            var name = control.getAttribute("name");
            var type = (control.getAttribute("type") || "").toLowerCase();
            var enhance = control.getAttribute("data-enhance") || "";
            var kind = "text";
            if (!name || name in fields || SKIPPED_INPUT_TYPES.indexOf(type) !== -1) {
                return;
            }
            if (type === "hidden" && enhance !== "list" && enhance !== "list-dict") {
                return;
            }
            if (control.tagName === "SELECT") {
                kind = enhance === "dropdown" ? "select" : "text";
            } else if (enhance === "list") {
                kind = "list";
            } else if (enhance === "list-dict") {
                kind = "listdict";
            } else if (type === "checkbox") {
                kind = "checkbox";
            }
            fields[name] = {
                name: name,
                kind: kind,
                source: control,
                group: document.getElementById("group_" + name),
                deps: depsOf(control),
                visible: null,
                state: null,
            };
            fieldOrder.push(fields[name]);
        });
        fieldOrder.forEach(function (field) {
            field.deps.forEach(function (dep) {
                dependentsByName[dep] = dependentsByName[dep] || [];
                dependentsByName[dep].push(field);
            });
        });
        conditionalFields = fieldOrder.filter(function (field) {
            return field.source.hasAttribute("data-show-if-field") || field.deps.length > 0;
        });
    }

    // Enhanced dropdowns are read through their hidden proxy; everything else through the control itself.
    function getProxyOrReal(name) {
        var field = fields[name];
        if (!field) {
            return null;
        }
        return field.kind === "select" && field.state ? field.state.hidden : field.source;
    }

    function ctrlVal(name) {
        var element = getProxyOrReal(name);
        if (!element) {
            return "";
        }
        if (element.type === "checkbox") {
            return element.checked ? "true" : "false";
        }
        return element.value || "";
    }

    // An emptied multi-select or list ("[]") does not satisfy a dependency (the server treats it as empty too).
    function dependencyValue(name) {
        var value = ctrlVal(name);
        return value === "[]" ? "" : value;
    }

    // Non-empty string when the field has a value; list-like values count only when the array has items.
    function getFieldValue(name) {
        var field = fields[name];
        var element = getProxyOrReal(name);
        var raw;
        var parsed;
        if (!field || !element) {
            return "";
        }
        if (element.type === "checkbox") {
            return element.checked ? "true" : "false";
        }
        raw = element.value || "";
        if (field.kind === "list" || field.kind === "listdict") {
            return parseJsonArray(raw).length ? raw : "";
        }
        if (field.kind === "select" && field.state && field.state.isMulti && raw) {
            parsed = parseJson(raw, undefined);
            if (parsed === undefined) {
                return raw;
            }
            return Array.isArray(parsed) && parsed.length ? raw : "";
        }
        return raw;
    }

    function fieldHasValue(field) {
        return field.kind === "checkbox" ? field.source.checked : getFieldValue(field.name) !== "";
    }

    function isFieldVisible(field) {
        return Boolean(field && field.group) && field.group.style.display !== "none";
    }

    function getFocusTarget(field) {
        if (!field) {
            return null;
        }
        if (field.state && typeof field.state.focusTarget === "function") {
            return field.state.focusTarget();
        }
        return field.source;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Visibility & dependencies
    // ------------------------------------------------------------------------------------------------------------

    function depsSatisfied(field) {
        return field.deps.every(function (dep) {
            return dependencyValue(dep) !== "";
        });
    }

    function readShowIfConditions(element) {
        var raw;
        var conditions = null;
        if (element._wlConditions !== undefined) {
            return element._wlConditions;
        }
        raw = element.getAttribute("data-show-if-conditions");
        if (raw) {
            conditions = parseJson(raw, null);
            if (!conditions || typeof conditions !== "object" || Array.isArray(conditions)) {
                reportOnce("conditions:" + raw, "Workflow Launcher: ignoring invalid data-show-if-conditions JSON", raw);
                conditions = null;
            }
        }
        element._wlConditions = conditions;
        return conditions;
    }

    // data-show-if-field/values (empty allow-list = always) AND every data-show-if-conditions entry.
    function showRuleSatisfied(element) {
        var controller = element.getAttribute("data-show-if-field");
        var allowed;
        var satisfied;
        var conditions;
        if (!controller) {
            return true;
        }
        allowed = (element.getAttribute("data-show-if-values") || "").split("|").filter(Boolean);
        satisfied = !allowed.length || allowed.indexOf(String(ctrlVal(controller))) !== -1;
        conditions = readShowIfConditions(element);
        if (!satisfied || !conditions) {
            return satisfied;
        }
        return Object.keys(conditions).every(function (key) {
            var expected = conditions[key];
            var current = String(ctrlVal(key));
            if (Array.isArray(expected)) {
                return expected.some(function (value) {
                    return String(value) === current;
                });
            }
            return String(expected) === current;
        });
    }

    // Recursively resets dependent dropdowns (legacy dependentsOf semantics) and marks them for a refetch.
    function markDependentsForRefresh(parentName, visited) {
        var seen = visited || Object.create(null);
        seen[parentName] = true;
        (dependentsByName[parentName] || []).forEach(function (child) {
            if (child.kind !== "select" || !child.state || child.name in seen) {
                return;
            }
            seen[child.name] = true;
            child.state.needsRefresh = true;
            resetSelect(child);
            markDependentsForRefresh(child.name, seen);
        });
    }

    function resetFieldValue(field) {
        if (field.kind === "select") {
            resetSelect(field);
        } else if (typeof field.source._wlReset === "function") {
            field.source._wlReset();
        } else if (field.kind === "list" || field.kind === "listdict") {
            field.source.value = "[]";
        } else if (field.kind === "checkbox") {
            // Never blank a checkbox's value attribute: Django would read the submitted "" as False.
            field.source.checked = false;
        } else {
            field.source.value = "";
        }
    }

    function setVisible(field, visible) {
        var previous;
        var keepInitial;
        if (!field.group) {
            return null;
        }
        previous = field.visible === true;
        field.visible = visible;
        field.group.style.display = visible ? "" : "none";
        if (!visible) {
            if (previous || hasFieldError(field)) {
                clearFieldError(field.name);
            }
            keepInitial = preserveInitial && Boolean(field.source.getAttribute("data-initial"));
            if (!keepInitial && (previous || fieldHasValue(field))) {
                resetFieldValue(field);
            }
        }
        return { prev: previous, now: visible };
    }

    function runVisibilityPass() {
        var changed = false;
        conditionalFields.forEach(function (field) {
            var result = setVisible(field, showRuleSatisfied(field.source) && depsSatisfied(field));
            if (result && result.prev !== result.now) {
                changed = true;
            }
        });
        return changed;
    }

    function updateSections() {
        toArray(ui.root.querySelectorAll(".wl-form-section[data-wl-section]")).forEach(function (section) {
            var groups = toArray(section.querySelectorAll(".wl-field"));
            if (!groups.length) {
                return;
            }
            section.hidden = !groups.some(function (group) {
                return group.style.display !== "none";
            });
        });
    }

    function updateVisibility() {
        var wasVisible = conditionalFields.map(function (field) {
            return field.visible === true;
        });
        var passes = 0;
        var becameVisible;
        // Pass 1: apply visibility; repeat while hiding (and resetting) a field changes another field's rules.
        while (runVisibilityPass() && passes < conditionalFields.length) {
            passes += 1;
        }
        becameVisible = conditionalFields.filter(function (field, index) {
            return !wasVisible[index] && field.visible === true;
        });
        // Pass 2: dependents that just became visible; then any dependent marked for refresh or with stale options.
        becameVisible.forEach(function (field) {
            if (field.kind === "select" && field.deps.length) {
                ensureDependentOptions(field);
            }
        });
        fieldOrder.forEach(function (field) {
            if (field.kind === "select" && field.deps.length) {
                ensureDependentOptions(field);
            }
        });
        // Top-level Jinja-choice and preload object fields load once.
        fieldOrder.forEach(function (field) {
            if (field.kind === "select" && !field.deps.length) {
                ensureTopLevelOptions(field);
            }
        });
        updateSections();
    }

    // ------------------------------------------------------------------------------------------------------------
    // Options loading (buildOptionsUrl, populateOptions, performServerSideSearch)
    // ------------------------------------------------------------------------------------------------------------

    function buildOptionsUrl(fieldName, params) {
        var base =
            window.location.pathname.replace(/\/launch\/?$/, "") + "/inputs/" + encodeURIComponent(fieldName) + "/options/";
        var query = params ? params.toString() : "";
        return query ? base + "?" + query : base;
    }

    function dependencyParams(field) {
        var params = new URLSearchParams();
        field.deps.forEach(function (dep) {
            var value = dependencyValue(dep);
            if (value !== "") {
                params.append(dep, value);
            }
        });
        return params;
    }

    function fetchJson(url, signal) {
        var init = { credentials: "same-origin", headers: { Accept: "application/json", "X-Requested-With": "XMLHttpRequest" } };
        if (signal) {
            init.signal = signal;
        }
        return window.fetch(url, init).then(function (response) {
            if (!response.ok) {
                throw new Error("Request failed with status " + response.status);
            }
            return response.json();
        });
    }

    function newAbortController() {
        return typeof window.AbortController === "function" ? new window.AbortController() : null;
    }

    function isAbortError(error) {
        return Boolean(error) && error.name === "AbortError";
    }

    function normalizeOptions(list) {
        var seen = Object.create(null);
        var result = [];
        (Array.isArray(list) ? list : []).forEach(function (option) {
            var value;
            if (!option || typeof option !== "object") {
                return;
            }
            value = option.value === undefined || option.value === null ? "" : String(option.value);
            if (value === "" || value in seen) {
                return;
            }
            seen[value] = true;
            result.push({
                value: value,
                label: option.label === undefined || option.label === null || option.label === "" ? value : String(option.label),
            });
        });
        return result;
    }

    // Replaces the native options with the fetched page, keeping selected values the page does not include.
    function applyFetchedOptions(field, data) {
        var st = field.state;
        var select = st.select;
        var fetched = normalizeOptions(data && data.options);
        var keep = selectedValues(st);
        var previousLabels = Object.create(null);
        var present = Object.create(null);
        toArray(select.options).forEach(function (option) {
            previousLabels[option.value] = option.text;
        });
        clearChildren(select);
        select.appendChild(createOption("", NATIVE_PLACEHOLDER_LABEL));
        fetched.forEach(function (option) {
            present[option.value] = true;
            select.appendChild(createOption(option.value, option.label));
        });
        keep.forEach(function (value) {
            if (!(value in present)) {
                present[value] = true;
                select.appendChild(createOption(value, value in previousLabels ? previousLabels[value] : value));
            }
        });
        st.fetchedCount = fetched.filter(function (option) {
            return option.value !== CREATE_OPTION_VALUE;
        }).length;
        st.totalCount = data && typeof data.total_count === "number" ? data.total_count : null;
        syncNativeSelection(st);
    }

    function populateOptions(field) {
        var st = field.state;
        var params = dependencyParams(field);
        var key = params.toString();
        var controller = newAbortController();
        var seq;
        if (st.loadController) {
            st.loadController.abort();
        }
        cancelSearch(st);
        if (st.view !== "options") {
            st.search.value = "";
            st.view = "options";
        }
        st.loadSeq += 1;
        seq = st.loadSeq;
        st.loadController = controller;
        st.loading = true;
        st.loadingKey = key;
        st.loadFailed = false;
        rebuildDropdown(field);
        fetchJson(buildOptionsUrl(field.name, params), controller ? controller.signal : null)
            .then(function (data) {
                if (seq !== st.loadSeq) {
                    return;
                }
                applyFetchedOptions(field, data);
                st.loaded = true;
                st.loadedKey = key;
                st.failedKey = null;
                st.needsRefresh = false;
            })
            .catch(function (error) {
                if (seq !== st.loadSeq || isAbortError(error)) {
                    return;
                }
                console.error('Workflow Launcher: could not load options for "' + field.name + '".', error);
                st.loadFailed = true;
                st.failedKey = key;
                st.needsRefresh = false;
            })
            .then(function () {
                if (seq !== st.loadSeq) {
                    return;
                }
                st.loading = false;
                st.loadingKey = null;
                st.loadController = null;
                rebuildDropdown(field);
            });
    }

    // Dependents refetch only when marked for refresh or when their dependency values changed since the last load.
    function ensureDependentOptions(field) {
        var st = field.state;
        var key;
        if (!st || !depsSatisfied(field) || (field.group && !isFieldVisible(field))) {
            return;
        }
        key = dependencyParams(field).toString();
        if (st.loading && st.loadingKey === key) {
            return;
        }
        if (!st.needsRefresh && (st.loadedKey === key || st.failedKey === key)) {
            return;
        }
        populateOptions(field);
    }

    function ensureTopLevelOptions(field) {
        var st = field.state;
        if (!st || st.loaded || st.loading || st.loadFailed) {
            return;
        }
        if (st.isJinja || (st.isObject && st.preload)) {
            populateOptions(field);
        }
    }

    function retryFailedLoad(field) {
        var st = field.state;
        if (!st.loadFailed || st.loading) {
            return;
        }
        if (field.deps.length) {
            st.needsRefresh = true;
            ensureDependentOptions(field);
        } else {
            populateOptions(field);
        }
    }

    function abortSearchRequest(st) {
        st.searchSeq += 1;
        if (st.searchController) {
            st.searchController.abort();
            st.searchController = null;
        }
    }

    function cancelSearch(st) {
        st.debouncedSearch.cancel();
        abortSearchRequest(st);
    }

    function performServerSideSearch(field, term) {
        var st = field.state;
        var params = dependencyParams(field);
        var controller = newAbortController();
        var seq;
        abortSearchRequest(st);
        seq = st.searchSeq;
        st.searchController = controller;
        params.append("search", term);
        showMenuStatus(st, "Searching\u2026");
        fetchJson(buildOptionsUrl(field.name, params), controller ? controller.signal : null)
            .then(function (data) {
                if (seq !== st.searchSeq) {
                    return;
                }
                st.searchController = null;
                renderSearchResults(field, data);
            })
            .catch(function (error) {
                if (seq !== st.searchSeq || isAbortError(error)) {
                    return;
                }
                st.searchController = null;
                console.error('Workflow Launcher: option search failed for "' + field.name + '".', error);
                showMenuStatus(st, "Search failed. Please try again.");
            });
    }

    // ------------------------------------------------------------------------------------------------------------
    // Validation (validateField, validateListDict, showFieldError, clearFieldError, renderErrorSummary, validateForm)
    // ------------------------------------------------------------------------------------------------------------

    function validateField(name) {
        var field = fields[name];
        var errors = [];
        var value;
        var label;
        if (!field) {
            return errors;
        }
        if (field.kind === "list" || field.kind === "listdict") {
            return validateListLike(field);
        }
        value = getFieldValue(name);
        label = getFieldLabel(name);
        if (field.source.getAttribute("data-required") === "true" && (!value || value.trim() === "")) {
            errors.push(label + " is required.");
        }
        if (value) {
            readValidators(field.source).forEach(function (validator) {
                if (validator.regex && !matchesValidator(validator, value)) {
                    errors.push(validator.message || label + " format is invalid.");
                }
            });
        }
        return errors;
    }

    function validateListLike(field) {
        var label = getFieldLabel(field.name);
        var rows = parseJsonArray(field.source.value);
        if (field.source.getAttribute("data-required") === "true" && !rows.length) {
            return [label + " is required."];
        }
        return field.kind === "listdict" ? validateListDict(field, rows, label) : [];
    }

    function listDictCellValue(row, column) {
        return row && typeof row === "object" ? row[column.key] : undefined;
    }

    function validateListDict(field, rows, label) {
        var columns = field.state ? field.state.columns : readListDictColumns(field.source, field.name);
        var errors = [];
        rows.forEach(function (row, index) {
            var prefix = label + " row " + (index + 1) + ": ";
            columns.forEach(function (column) {
                var labelText = column.label || column.key || "Value";
                var type = columnType(column);
                var value = listDictCellValue(row, column);
                var missing;
                if (column.required === true && type !== "boolean") {
                    missing = isNumericType(type)
                        ? value === "" || value === null || value === undefined
                        : !value || String(value).trim() === "";
                    if (missing) {
                        errors.push(prefix + labelText + " is required.");
                    }
                }
                if (isNumericType(type) && value !== "" && value !== null && value !== undefined && isNaN(Number(value))) {
                    errors.push(prefix + labelText + " must be a number.");
                }
                if (Array.isArray(column.validators) && value) {
                    column.validators.forEach(function (validator) {
                        if (validator && validator.regex && !matchesValidator(validator, String(value))) {
                            errors.push(prefix + (validator.message || labelText + " format is invalid."));
                        }
                    });
                }
            });
        });
        columns.forEach(function (column) {
            var seen = Object.create(null);
            if (column.unique !== true) {
                return;
            }
            rows.forEach(function (row, index) {
                var value = listDictCellValue(row, column);
                var key;
                if (value === undefined || value === null || String(value).trim() === "") {
                    return;
                }
                key = String(value).trim().toLowerCase();
                if (key in seen) {
                    errors.push(label + " row " + (index + 1) + ": " + (column.label || column.key || "Value") + " must be unique.");
                } else {
                    seen[key] = index;
                }
            });
        });
        if (errors.length && field.state && typeof field.state.touchAll === "function") {
            field.state.touchAll();
        }
        return errors;
    }

    function getFeedback(field) {
        var feedback;
        if (!field || !field.group) {
            return null;
        }
        feedback = document.getElementById("feedback_" + field.name) || field.group.querySelector("[data-wl-feedback]");
        if (!feedback) {
            feedback = createElement("div", "wl-field__feedback");
            feedback.id = "feedback_" + field.name;
            feedback.setAttribute("data-wl-feedback", "");
            feedback.setAttribute("aria-live", "polite");
            field.group.appendChild(feedback);
        }
        return feedback;
    }

    // True for client-side errors and for server-rendered messages still shown in the feedback element.
    function hasFieldError(field) {
        var feedback = getFeedback(field);
        if (!feedback) {
            return false;
        }
        return field.group.classList.contains("has-error") || feedback.textContent.trim() !== "";
    }

    function showFieldError(name, errors) {
        var field = fields[name];
        var feedback = getFeedback(field);
        var messages;
        if (!feedback) {
            return;
        }
        messages = field.kind === "listdict" ? summarizeCSVMessages(errors, INLINE_ERROR_LIMIT) : errors;
        clearChildren(feedback);
        messages.forEach(function (message) {
            feedback.appendChild(createElement("div", null, message));
        });
        field.group.classList.toggle("has-error", errors.length > 0);
        // Grid cells carry their own aria-invalid state.
        if (field.kind !== "listdict") {
            setInvalid(getFocusTarget(field), errors.length > 0);
        }
    }

    function clearFieldError(name) {
        showFieldError(name, []);
    }

    function getClientErrorsHost() {
        var host = ui.clientErrors || document.getElementById("wl-client-errors");
        if (!host) {
            host = createElement("div");
            host.id = "wl-client-errors";
            ui.form.parentNode.insertBefore(host, ui.form);
        }
        ui.clientErrors = host;
        return host;
    }

    function createErrorAlert() {
        var alert = createElement("div", "alert alert-danger wl-alert");
        alert.setAttribute("role", "alert");
        alert.tabIndex = -1;
        alert.appendChild(createIcon("mdi-alert-circle-outline"));
        return alert;
    }

    function revealAlert(alert) {
        alert.focus({ preventScroll: true });
        scrollIntoViewCentered(alert);
    }

    function focusField(name) {
        var field = fields[name];
        var target;
        if (!field || !field.group) {
            return;
        }
        scrollIntoViewCentered(field.group);
        target = getFocusTarget(field);
        if (target && typeof target.focus === "function") {
            target.focus({ preventScroll: true });
        }
    }

    function renderErrorSummary(errors) {
        var host = getClientErrorsHost();
        var alert;
        var body;
        var list;
        clearChildren(host);
        if (!errors.length) {
            return null;
        }
        alert = createErrorAlert();
        body = createElement("div");
        list = createElement("ul");
        body.appendChild(createElement("strong", null, "Please fix the following:"));
        errors.forEach(function (error) {
            var item = createElement("li");
            var link = createElement("a", null, error.label + ":");
            link.href = "#group_" + error.name;
            link.addEventListener("click", function (event) {
                event.preventDefault();
                focusField(error.name);
            });
            item.appendChild(link);
            item.appendChild(document.createTextNode(" " + error.message));
            list.appendChild(item);
        });
        body.appendChild(list);
        alert.appendChild(body);
        host.appendChild(alert);
        return alert;
    }

    function renderUnexpectedError(error) {
        var host = getClientErrorsHost();
        var alert = createErrorAlert();
        var message = error && error.message ? error.message : String(error);
        clearChildren(host);
        alert.appendChild(createElement("div", null, "An unexpected error occurred: " + message));
        host.appendChild(alert);
        revealAlert(alert);
    }

    // Validates visible fields only; renders inline errors plus the summary. Returns true when the form may be submitted.
    function validateForm() {
        var summary = [];
        fieldOrder.forEach(function (field) {
            if (field.kind === "listdict" && typeof field.source._syncListDictFromDom === "function") {
                field.source._syncListDictFromDom();
            }
        });
        renderErrorSummary([]);
        fieldOrder.forEach(function (field) {
            var errors;
            var label;
            if (!field.group) {
                return;
            }
            if (!isFieldVisible(field)) {
                clearFieldError(field.name);
                return;
            }
            errors = validateField(field.name);
            label = getFieldLabel(field.name);
            showFieldError(field.name, errors);
            errors.forEach(function (message) {
                summary.push({ name: field.name, label: label, message: message });
            });
        });
        if (summary.length) {
            revealAlert(renderErrorSummary(summary));
        }
        return summary.length === 0;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Value change notifications
    // ------------------------------------------------------------------------------------------------------------

    // Every committed selection/edit (including programmatic ones from the widgets) goes through here.
    function onValueChanged(name) {
        markDependentsForRefresh(name);
        updateVisibility();
        revalidateIfNeeded(name);
        updateRequiredProgress();
    }

    // Keystroke-level edits: no cascade (dependents refresh on the committing "change" instead).
    function onValueEdited(name) {
        revalidateIfNeeded(name);
        updateRequiredProgress();
    }

    function revalidateIfNeeded(name) {
        var field = fields[name];
        if (!field || !hasFieldError(field)) {
            return;
        }
        showFieldError(name, isFieldVisible(field) ? validateField(name) : []);
    }

    function eventField(event) {
        var target = event.target;
        var name = target && target.getAttribute ? target.getAttribute("name") : null;
        var field = name ? fields[name] : null;
        if (!field || field.source !== target) {
            return null;
        }
        return field.kind === "text" || field.kind === "checkbox" ? field : null;
    }

    function onNativeInput(event) {
        var field = eventField(event);
        if (field && field.kind === "text") {
            onValueEdited(field.name);
        }
    }

    function onNativeChange(event) {
        var field = eventField(event);
        if (field) {
            onValueChanged(field.name);
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Dropdown enhancer (enhanceSelect, buildMenuFromSelect, rebuildDropdown, filterMenuItems, keyboard, tokens)
    // ------------------------------------------------------------------------------------------------------------

    function findOption(select, value) {
        var options = select.options;
        for (var index = 0; index < options.length; index += 1) {
            if (options[index].value === value) {
                return options[index];
            }
        }
        return null;
    }

    function ensureOption(select, value, label) {
        return findOption(select, value) || select.appendChild(createOption(value, label ? label : value));
    }

    function ensurePlaceholder(select) {
        if (!select.options.length || select.options[0].value !== "") {
            select.insertBefore(createOption("", NATIVE_PLACEHOLDER_LABEL), select.firstChild);
        }
    }

    function realOptions(select) {
        var result = [];
        toArray(select.options).forEach(function (option) {
            if (option.value !== "") {
                result.push({ value: option.value, label: option.text });
            }
        });
        return result;
    }

    // Initial value: server-provided data-initial, else an option the server explicitly marked selected (bound form).
    // The legacy rule "never auto-select" still holds: nothing is picked just because it is the first option.
    function readInitialSelection(select, isMulti, isStatic) {
        var raw = select.getAttribute("data-initial");
        var values = [];
        var parsed;
        if (raw) {
            if (isMulti) {
                parsed = parseJson(raw, raw);
                values = Array.isArray(parsed) ? parsed : [parsed];
            } else {
                values = [raw];
            }
        } else {
            toArray(select.options).forEach(function (option) {
                if (option.defaultSelected && option.value !== "") {
                    values.push(option.value);
                }
            });
            if (!isMulti) {
                values = values.slice(-1);
            }
        }
        values = uniqueStrings(
            values
                .filter(function (value) {
                    return value !== null && value !== undefined;
                })
                .map(String)
        );
        // Static single choices are complete server-side, so an unknown value can never be valid.
        if (isStatic && !isMulti) {
            values = values.filter(function (value) {
                return Boolean(findOption(select, value));
            });
        }
        return values;
    }

    function getMultiValues(st) {
        var raw = st.hidden.value;
        var parsed;
        if (!raw) {
            return [];
        }
        parsed = parseJson(raw, undefined);
        if (parsed === undefined) {
            return [raw];
        }
        if (!Array.isArray(parsed)) {
            return parsed === null ? [] : [String(parsed)];
        }
        return uniqueStrings(
            parsed
                .filter(function (value) {
                    return value !== null && value !== undefined;
                })
                .map(String)
        );
    }

    function selectedValues(st) {
        if (st.isMulti) {
            return getMultiValues(st);
        }
        return st.hidden.value ? [st.hidden.value] : [];
    }

    function optionLabel(st, value) {
        var option = findOption(st.select, value);
        return option ? option.text : value;
    }

    function syncNativeSelection(st) {
        var values = selectedValues(st);
        toArray(st.select.options).forEach(function (option) {
            option.selected = option.value !== "" && values.indexOf(option.value) !== -1;
        });
        if (!values.length) {
            st.select.selectedIndex = 0;
        }
    }

    function enhanceSelect(field) {
        if (field.source.dataset.enhanced === "1") {
            return;
        }
        var select = field.source;
        var name = field.name;
        var isMultichoice = select.getAttribute("data-multichoice") === "true";
        var isMultiobject = select.getAttribute("data-multiobject") === "true";
        var isObject = select.getAttribute("data-object-field") === "true";
        var isJinja = select.getAttribute("data-jinja-choices") === "true";
        var isMulti = isMultichoice || isMultiobject;
        var initial;
        var describedBy = select.getAttribute("aria-describedby");
        var labelElement = findFieldLabelElement(field);
        var fieldLabel = getFieldLabel(name);
        var hidden = document.createElement("input");
        var wrapper = createElement("div", "dropdown wl-select");
        var toggle = createElement("button", "form-select wl-select__toggle");
        var display = createElement("span", "wl-select__label b3-label");
        var menu = createElement("ul", "dropdown-menu wl-select__menu");
        var searchItem = createElement("li", "wl-select__search");
        var search = createElement("input", "form-control form-control-sm");
        var tokens = null;
        var st;

        initial = readInitialSelection(select, isMulti, !isObject && !isJinja && !field.deps.length);
        ensurePlaceholder(select);

        // The proxy is inserted before the select loses its name so the value always reaches the server.
        hidden.type = "hidden";
        hidden.name = name;
        hidden.value = isMulti ? (initial.length ? JSON.stringify(initial) : "") : initial[0] || "";
        hidden.setAttribute("data-proxy-for", name);
        if (isMultichoice) {
            hidden.setAttribute("data-multichoice", "true");
        }
        if (isMultiobject) {
            hidden.setAttribute("data-multiobject", "true");
        }
        insertAfter(hidden, select);

        select.removeAttribute("name");
        select.dataset.originalName = name;
        select.id = "id_" + name + "_native";
        select.style.display = "none";
        select.tabIndex = -1;
        select.setAttribute("aria-hidden", "true");

        toggle.type = "button";
        toggle.id = "id_" + name;
        toggle.setAttribute("data-bs-toggle", "dropdown");
        toggle.setAttribute("data-bs-display", "static");
        // Clicks inside the menu (search row, checkboxes) never close it; single picks close it explicitly.
        toggle.setAttribute("data-bs-auto-close", "outside");
        toggle.setAttribute("aria-expanded", "false");
        display.id = "id_" + name + "_display";
        toggle.appendChild(display);
        menu.id = "id_" + name + "_menu";
        toggle.setAttribute("aria-controls", menu.id);
        if (labelElement) {
            if (!labelElement.id) {
                labelElement.id = "id_" + name + "_label";
            }
            toggle.setAttribute("aria-labelledby", labelElement.id + " " + display.id);
        } else {
            toggle.setAttribute("aria-label", fieldLabel);
        }
        if (describedBy) {
            toggle.setAttribute("aria-describedby", describedBy);
        }

        search.type = "search";
        search.placeholder = "Search\u2026";
        search.setAttribute("aria-label", "Search " + fieldLabel);
        search.setAttribute("autocomplete", "off");
        search.setAttribute("data-no-validate", "true");
        searchItem.appendChild(search);
        menu.appendChild(searchItem);
        wrapper.appendChild(toggle);
        wrapper.appendChild(menu);
        insertAfter(wrapper, hidden);
        if (isMulti) {
            tokens = createElement("div", "wl-tokens");
            insertAfter(tokens, wrapper);
        }

        st = {
            field: field,
            name: name,
            select: select,
            hidden: hidden,
            wrapper: wrapper,
            toggle: toggle,
            display: display,
            menu: menu,
            searchItem: searchItem,
            search: search,
            tokens: tokens,
            noResultsItem: null,
            highlighted: null,
            isMulti: isMulti,
            isObject: isObject,
            isJinja: isJinja,
            preload: select.getAttribute("data-preload") === "true",
            view: "options",
            loading: false,
            loaded: false,
            loadFailed: false,
            loadingKey: null,
            loadedKey: null,
            failedKey: null,
            needsRefresh: false,
            loadSeq: 0,
            loadController: null,
            searchSeq: 0,
            searchController: null,
            totalCount: null,
            fetchedCount: 0,
            debouncedSearch: debounce(function (term) {
                performServerSideSearch(field, term);
            }, SEARCH_DEBOUNCE_MS),
            focusTarget: function () {
                return toggle;
            },
        };
        field.state = st;
        select._wl = st;

        toggle.addEventListener("shown.bs.dropdown", function () {
            onMenuShown(field);
        });
        toggle.addEventListener("hidden.bs.dropdown", function () {
            onMenuHidden(field);
        });
        search.addEventListener("input", function () {
            onSearchInput(field);
        });
        search.addEventListener("keydown", function (event) {
            onSearchKeydown(field, event);
        });
        menu.addEventListener("click", function (event) {
            onMenuClick(field, event);
        });
        menu.addEventListener("keydown", function (event) {
            onMenuKeydown(field, event);
        });
        menu.addEventListener("mouseover", function () {
            clearHighlight(st);
        });

        select.dataset.enhanced = "1";
        syncNativeSelection(st);
        rebuildDropdown(field);
    }

    function isMenuOpen(st) {
        return st.menu.classList.contains("show");
    }

    function hideMenu(st) {
        var Dropdown = window.bootstrap && window.bootstrap.Dropdown;
        if (!isMenuOpen(st)) {
            return;
        }
        if (Dropdown) {
            Dropdown.getOrCreateInstance(st.toggle).hide();
        } else {
            st.menu.classList.remove("show");
            st.toggle.classList.remove("show");
            st.toggle.setAttribute("aria-expanded", "false");
            onMenuHidden(st.field);
        }
    }

    function optionRows(st) {
        return toArray(st.menu.querySelectorAll("li.wl-select__option"));
    }

    function removeMenuRows(st) {
        toArray(st.menu.children).forEach(function (child) {
            if (child !== st.searchItem) {
                st.menu.removeChild(child);
            }
        });
        st.noResultsItem = null;
        st.highlighted = null;
    }

    function appendMenuStatus(st, message) {
        var item = createElement("li", "wl-select__status");
        item.appendChild(createElement("span", "dropdown-item-text", message));
        st.menu.appendChild(item);
        return item;
    }

    function showMenuStatus(st, message) {
        removeMenuRows(st);
        st.view = "status";
        appendMenuStatus(st, message);
    }

    function buildOptionRow(st, value, label) {
        var item = createElement("li", "wl-select__option");
        var row;
        var box;
        var text;
        var link;
        item._wlValue = value;
        item._wlLabel = label;
        item.setAttribute("data-search-text", label.toLowerCase());
        if (st.isMulti) {
            row = createElement("div", "dropdown-item form-check");
            box = createElement("input", "form-check-input");
            text = createElement("label", "form-check-label", label);
            box.type = "checkbox";
            box.id = nextId("id_" + st.name + "_option_");
            text.htmlFor = box.id;
            item.setAttribute("data-value", value);
            row.appendChild(box);
            row.appendChild(text);
            item.appendChild(row);
        } else {
            link = createElement("a", "dropdown-item", label);
            link.href = "#";
            link.setAttribute("data-value", value);
            item.appendChild(link);
        }
        return item;
    }

    function emptyMenuMessage(st) {
        if (st.loadFailed) {
            return st.isObject ? "Could not load options. Type to search instead." : "Could not load options.";
        }
        if (st.isObject) {
            return st.preload && !st.loaded ? "Loading options\u2026" : "Type to search for options\u2026";
        }
        return "No options available";
    }

    // Options view: one row per real option of the native select (the select is the option store).
    function buildMenuFromSelect(field) {
        var st = field.state;
        var options = realOptions(st.select);
        var term;
        st.searchItem.hidden = !(st.isObject || options.length > SEARCH_OPTION_THRESHOLD);
        if (st.searchItem.hidden) {
            st.search.value = "";
        }
        term = st.search.value.trim();
        removeMenuRows(st);
        st.view = "options";
        if (st.loading) {
            appendMenuStatus(st, "Loading options\u2026");
            return;
        }
        if (!options.length) {
            appendMenuStatus(st, emptyMenuMessage(st));
            return;
        }
        options.forEach(function (option) {
            st.menu.appendChild(buildOptionRow(st, option.value, option.label));
        });
        if (st.isObject && st.totalCount !== null && st.totalCount > st.fetchedCount) {
            appendMenuStatus(st, "Showing " + st.fetchedCount + " of " + st.totalCount + " results. Type to search for more.");
        }
        renderRowStates(st);
        if (!st.isObject && term) {
            filterMenuItems(st, term);
        }
    }

    // Keeps an open search/status view intact; otherwise rebuilds the option rows. Always refreshes label and tokens.
    function rebuildDropdown(field) {
        var st = field.state;
        if (!st) {
            return;
        }
        if (!isMenuOpen(st) || st.view === "options") {
            buildMenuFromSelect(field);
        } else {
            renderRowStates(st);
        }
        renderToggle(st);
    }

    function renderRowStates(st) {
        var values = selectedValues(st);
        optionRows(st).forEach(function (item) {
            var selected = values.indexOf(item._wlValue) !== -1;
            var box;
            var link;
            if (st.isMulti) {
                box = item.querySelector('input[type="checkbox"]');
                if (box) {
                    box.checked = selected;
                }
            } else {
                item.classList.toggle("active", selected);
                link = item.querySelector("a.dropdown-item");
                if (link && selected) {
                    link.setAttribute("aria-current", "true");
                } else if (link) {
                    link.removeAttribute("aria-current");
                }
            }
        });
    }

    function renderToggle(st) {
        var values = selectedValues(st);
        var text = PLACEHOLDER_LABEL;
        if (values.length === 1) {
            text = optionLabel(st, values[0]);
        } else if (values.length > 1) {
            text = values.length + " selected";
        }
        st.display.textContent = text;
        st.display.classList.toggle("is-placeholder", values.length === 0);
        if (st.tokens) {
            renderTokens(st, values);
        }
    }

    function renderTokens(st, values) {
        clearChildren(st.tokens);
        values.forEach(function (value) {
            var label = optionLabel(st, value);
            var token = createElement("span", "wl-token");
            var remove = createElement("button", "wl-token__remove");
            token.title = label;
            token.appendChild(createElement("span", "wl-token__label", label));
            remove.type = "button";
            remove.setAttribute("aria-label", "Remove " + label);
            remove.appendChild(createIcon("mdi-close"));
            remove.addEventListener("click", function () {
                removeToken(st.field, value);
            });
            token.appendChild(remove);
            st.tokens.appendChild(token);
        });
    }

    function removeToken(field, value) {
        var st = field.state;
        var index = getMultiValues(st).indexOf(value);
        var buttons;
        setMultiValueSelected(field, value, false);
        buttons = st.tokens.querySelectorAll(".wl-token__remove");
        (buttons[Math.min(Math.max(index, 0), buttons.length - 1)] || st.toggle).focus();
    }

    function resetSelect(field) {
        var st = field.state;
        if (!st) {
            field.source.selectedIndex = 0;
            return;
        }
        st.hidden.value = "";
        syncNativeSelection(st);
        renderRowStates(st);
        renderToggle(st);
    }

    function selectSingleValue(field, value, label) {
        var st = field.state;
        var changed = st.hidden.value !== value;
        ensureOption(st.select, value, label);
        st.hidden.value = value;
        syncNativeSelection(st);
        renderRowStates(st);
        renderToggle(st);
        hideMenu(st);
        st.toggle.focus();
        if (changed) {
            onValueChanged(field.name);
        }
    }

    // Toggles one value in the hidden JSON array, so picks made from earlier search results are kept.
    function setMultiValueSelected(field, value, selected, label) {
        var st = field.state;
        var values = getMultiValues(st);
        var index = values.indexOf(value);
        if (selected && index === -1) {
            ensureOption(st.select, value, label);
            values.push(value);
        } else if (!selected && index !== -1) {
            values.splice(index, 1);
        } else {
            renderRowStates(st);
            return;
        }
        st.hidden.value = JSON.stringify(values);
        syncNativeSelection(st);
        renderRowStates(st);
        renderToggle(st);
        onValueChanged(field.name);
    }

    function filterMenuItems(st, term) {
        var needle = String(term || "").toLowerCase();
        var rows = optionRows(st);
        var anyVisible = false;
        var showNoResults;
        rows.forEach(function (item) {
            var matches = !needle || (item.getAttribute("data-search-text") || "").indexOf(needle) !== -1;
            item.hidden = !matches;
            anyVisible = anyVisible || matches;
        });
        if (st.highlighted && st.highlighted.hidden) {
            clearHighlight(st);
        }
        showNoResults = Boolean(needle) && rows.length > 0 && !anyVisible;
        if (showNoResults && !st.noResultsItem) {
            st.noResultsItem = appendMenuStatus(st, "No results found");
        }
        if (st.noResultsItem) {
            st.noResultsItem.hidden = !showNoResults;
        }
    }

    function renderSearchResults(field, data) {
        var st = field.state;
        var results = normalizeOptions(data && data.options);
        var total = data && typeof data.total_count === "number" ? data.total_count : results.length;
        var summary = pluralize(results.length, "result");
        removeMenuRows(st);
        st.view = "search";
        if (!results.length) {
            appendMenuStatus(st, "No results found");
            announce("No results found");
            return;
        }
        results.forEach(function (option) {
            st.menu.appendChild(buildOptionRow(st, option.value, option.label));
        });
        if (total > results.length) {
            summary = "Showing " + results.length + " of " + total + " results";
            appendMenuStatus(st, summary);
        } else if (data && data.has_more) {
            appendMenuStatus(st, "More results available. Refine your search to narrow them down.");
        }
        renderRowStates(st);
        announce(summary);
    }

    function clearHighlight(st) {
        if (st.highlighted) {
            st.highlighted.classList.remove("highlighted");
        }
        st.highlighted = null;
    }

    function setHighlight(st, item) {
        clearHighlight(st);
        item.classList.add("highlighted");
        st.highlighted = item;
        item.scrollIntoView({ block: "nearest" });
    }

    function moveHighlight(st, delta) {
        var rows = optionRows(st).filter(function (item) {
            return !item.hidden;
        });
        var index;
        if (!rows.length) {
            return;
        }
        index = st.highlighted ? rows.indexOf(st.highlighted) : -1;
        setHighlight(st, rows[index === -1 ? 0 : Math.min(Math.max(index + delta, 0), rows.length - 1)]);
    }

    function activateRow(field, item) {
        var box;
        if (field.state.isMulti) {
            box = item.querySelector('input[type="checkbox"]');
            if (box) {
                box.click();
            }
        } else {
            selectSingleValue(field, item._wlValue, item._wlLabel);
        }
    }

    function onMenuShown(field) {
        var st = field.state;
        cancelSearch(st);
        st.search.value = "";
        retryFailedLoad(field);
        buildMenuFromSelect(field);
        st.menu.scrollTop = 0;
        if (!st.searchItem.hidden) {
            // Deferred so it wins over Bootstrap focusing the first item after a keyboard open.
            window.setTimeout(function () {
                if (isMenuOpen(st)) {
                    st.search.focus();
                }
            }, 0);
        }
    }

    function onMenuHidden(field) {
        var st = field.state;
        cancelSearch(st);
        clearHighlight(st);
    }

    function onSearchInput(field) {
        var st = field.state;
        var term = st.search.value.trim();
        clearHighlight(st);
        if (!st.isObject) {
            filterMenuItems(st, term);
            return;
        }
        cancelSearch(st);
        if (!term) {
            buildMenuFromSelect(field);
        } else if (term.length < MIN_SEARCH_LENGTH) {
            showMenuStatus(st, "Type at least " + MIN_SEARCH_LENGTH + " characters to search\u2026");
        } else {
            st.debouncedSearch(term);
        }
    }

    function onSearchKeydown(field, event) {
        var st = field.state;
        if (event.key === "ArrowDown" || event.key === "ArrowUp") {
            event.preventDefault();
            moveHighlight(st, event.key === "ArrowDown" ? 1 : -1);
        } else if (event.key === "Enter") {
            // Always swallow Enter so the search box never submits the launch form.
            event.preventDefault();
            if (st.highlighted) {
                activateRow(field, st.highlighted);
            }
        } else if (event.key === "Escape") {
            event.preventDefault();
            event.stopPropagation();
            hideMenu(st);
            st.toggle.focus();
        }
    }

    function onMenuKeydown(field, event) {
        var target = event.target;
        if (event.key === "Enter" && target && target.type === "checkbox" && field.state.menu.contains(target)) {
            event.preventDefault();
            target.click();
        }
    }

    function onMenuClick(field, event) {
        var st = field.state;
        var item = event.target && event.target.closest ? event.target.closest("li.wl-select__option") : null;
        var box;
        if (!item || !st.menu.contains(item)) {
            return;
        }
        if (!st.isMulti) {
            event.preventDefault();
            selectSingleValue(field, item._wlValue, item._wlLabel);
            return;
        }
        box = item.querySelector('input[type="checkbox"]');
        if (!box) {
            return;
        }
        if (event.target === box) {
            setMultiValueSelected(field, item._wlValue, box.checked, item._wlLabel);
        } else if (!event.target.closest("label")) {
            // Row padding: forward to the checkbox. Label clicks are forwarded by the browser itself.
            event.preventDefault();
            box.click();
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // List editor (tag input for `list` inputs)
    // ------------------------------------------------------------------------------------------------------------

    function enhanceListField(field) {
        if (field.source.dataset.enhanced === "1") {
            return;
        }
        var inputEl = field.source;
        var name = field.name;
        var label = getFieldLabel(name);
        var validators = readValidators(inputEl);
        var items = parseJsonArray(inputEl.value);
        var originalId = inputEl.id || "id_" + name;
        var tags = createElement("div", "wl-tags");
        var textInput = createElement("input", "wl-tags__input");
        var addButton = createButton("btn btn-secondary btn-sm", "mdi-plus", "Add");
        var meta = createElement("div", "wl-tags__meta");
        var count = createElement("span");
        var error = createElement("span", "wl-tags__error");

        inputEl.style.display = "none";
        // The visible tag input takes over the id so the field's <label for> focuses it.
        inputEl.id = "id_" + name + "_data";
        textInput.type = "text";
        textInput.id = originalId;
        textInput.setAttribute("aria-label", label);
        textInput.placeholder = inputEl.getAttribute("placeholder") || "Type a value and press Enter";
        textInput.setAttribute("autocomplete", "off");
        textInput.setAttribute("data-no-validate", "true");
        textInput.setAttribute("data-list-helper", "true");
        error.id = "id_" + name + "_list_error";
        error.setAttribute("role", "alert");
        textInput.setAttribute("aria-describedby", error.id);
        tags.appendChild(textInput);
        tags.appendChild(addButton);
        meta.appendChild(count);
        meta.appendChild(error);
        insertAfter(tags, inputEl);
        insertAfter(meta, tags);

        function commit(notify) {
            inputEl.value = JSON.stringify(items);
            inputEl.dispatchEvent(new Event("input", { bubbles: true }));
            if (notify) {
                onValueChanged(name);
            }
        }

        function setError(message) {
            error.textContent = message || "";
            setInvalid(textInput, Boolean(message) || Boolean(field.group && field.group.classList.contains("has-error")));
        }

        function validateItem(value) {
            for (var index = 0; index < validators.length; index += 1) {
                if (validators[index].regex && !matchesValidator(validators[index], value)) {
                    return validators[index].message || "Invalid format";
                }
            }
            return "";
        }

        function contains(value) {
            return items.some(function (item) {
                return String(item) === value;
            });
        }

        function render() {
            toArray(tags.querySelectorAll(".wl-token")).forEach(function (token) {
                tags.removeChild(token);
            });
            items.forEach(function (item, index) {
                var text = String(item);
                var token = createElement("span", "wl-token");
                var remove = createElement("button", "wl-token__remove");
                token.title = text;
                token.appendChild(createElement("span", "wl-token__label", text));
                remove.type = "button";
                remove.setAttribute("aria-label", "Remove " + text);
                remove.appendChild(createIcon("mdi-close"));
                remove.addEventListener("click", function () {
                    removeAt(index, true);
                });
                token.appendChild(remove);
                tags.insertBefore(token, textInput);
            });
            count.textContent = pluralize(items.length, "item");
        }

        function removeAt(index, moveFocus) {
            var removed = items.splice(index, 1);
            var buttons;
            render();
            commit(true);
            if (moveFocus) {
                buttons = tags.querySelectorAll(".wl-token__remove");
                (buttons[Math.min(index, buttons.length - 1)] || textInput).focus();
            } else if (removed.length) {
                announce("Removed " + String(removed[0]));
            }
        }

        // Validates each value (regex validators, then duplicates); returns the values that were rejected and why.
        function addValues(values) {
            var added = 0;
            var problems = [];
            values.forEach(function (raw) {
                var value = String(raw).trim();
                var message;
                if (!value) {
                    return;
                }
                message = validateItem(value) || (contains(value) ? "Item already exists in the list" : "");
                if (message) {
                    problems.push({ value: value, message: message });
                    return;
                }
                items.push(value);
                added += 1;
            });
            if (added) {
                render();
                commit(true);
            }
            return { added: added, problems: problems };
        }

        function addFromInput() {
            var result;
            if (!textInput.value.trim()) {
                return;
            }
            result = addValues([textInput.value]);
            if (result.problems.length) {
                setError(result.problems[0].message);
                return;
            }
            textInput.value = "";
            setError("");
        }

        tags.addEventListener("click", function (event) {
            if (event.target === tags) {
                textInput.focus();
            }
        });
        addButton.addEventListener("click", function () {
            addFromInput();
            textInput.focus();
        });
        textInput.addEventListener("keydown", function (event) {
            if (event.isComposing) {
                return;
            }
            if (event.key === "Enter") {
                event.preventDefault();
                addFromInput();
            } else if (event.key === "Backspace" && textInput.value === "" && items.length) {
                event.preventDefault();
                removeAt(items.length - 1, false);
            }
        });
        textInput.addEventListener("paste", function (event) {
            var clipboard = event.clipboardData || window.clipboardData;
            var text = clipboard ? clipboard.getData("text") : "";
            var result;
            var reasons;
            if (!/[\r\n]/.test(text)) {
                return;
            }
            event.preventDefault();
            result = addValues(text.split(/\r\n|\r|\n/));
            if (!result.problems.length) {
                setError("");
                return;
            }
            reasons = uniqueStrings(
                result.problems.map(function (problem) {
                    return problem.message;
                })
            );
            setError(
                (result.added ? "Added " + pluralize(result.added, "item") + ". " : "") +
                    pluralize(result.problems.length, "value") +
                    " not added: " +
                    reasons.join("; ")
            );
        });

        inputEl._wlReset = function () {
            items = [];
            textInput.value = "";
            setError("");
            render();
            commit(false);
        };
        field.state = {
            textInput: textInput,
            tags: tags,
            meta: meta,
            focusTarget: function () {
                return textInput;
            },
        };
        render();
        inputEl.value = JSON.stringify(items);
        inputEl.dataset.enhanced = "1";
    }

    // ------------------------------------------------------------------------------------------------------------
    // CSV helpers (ported unchanged from the legacy engine)
    // ------------------------------------------------------------------------------------------------------------

    function normalizeCSVHeader(value) {
        return String(value || "").trim().toLowerCase();
    }

    function parseCSV(text) {
        var source = String(text || "");
        var rows = [];
        var row = [];
        var cell = "";
        var inQuotes = false;
        var currentLine = 1;
        var character;
        var nextCharacter;
        var headerRow;
        var headers;
        var issues;
        var dataRows;

        if (source.charCodeAt(0) === 0xfeff) {
            source = source.slice(1);
        }
        source = source.replace(/\r\n/g, "\n").replace(/\r/g, "\n");

        for (var index = 0; index < source.length; index += 1) {
            character = source[index];
            nextCharacter = source[index + 1];

            if (inQuotes) {
                if (character === '"') {
                    if (nextCharacter === '"') {
                        cell += '"';
                        index += 1;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    cell += character;
                }
                continue;
            }

            if (character === '"') {
                inQuotes = true;
            } else if (character === ",") {
                row.push(cell);
                cell = "";
            } else if (character === "\n") {
                row.push(cell);
                rows.push({ values: row, lineNumber: currentLine });
                row = [];
                cell = "";
                currentLine += 1;
            } else {
                cell += character;
            }
        }

        if (inQuotes) {
            throw new Error("The CSV contains an unterminated quoted field.");
        }

        if (cell !== "" || row.length > 0) {
            row.push(cell);
            rows.push({ values: row, lineNumber: currentLine });
        }

        if (!rows.length) {
            return { headers: [], rows: [], issues: [] };
        }

        headerRow = rows.shift();
        headers = headerRow.values.map(function (header) {
            return String(header || "").trim();
        });

        issues = [];
        dataRows = rows.filter(function (currentRow) {
            var hasData = currentRow.values.some(function (value) {
                return String(value || "").trim() !== "";
            });

            if (hasData && currentRow.values.length !== headers.length) {
                issues.push(
                    "Row " +
                        currentRow.lineNumber +
                        ": expected " +
                        headers.length +
                        " column" +
                        (headers.length === 1 ? "" : "s") +
                        ", found " +
                        currentRow.values.length +
                        "."
                );
            }

            return hasData;
        });

        return { headers: headers, rows: dataRows, issues: issues };
    }

    function getDefaultTabularValue(column) {
        var type = String((column && column.type) || "string").toLowerCase();
        return type === "boolean" ? false : "";
    }

    function coerceCSVColumnValue(column, rawValue) {
        var type = String((column && column.type) || "string").toLowerCase();
        var normalized = String(rawValue == null ? "" : rawValue).trim();
        var lowered;
        var matchedChoice = null;

        if (type === "boolean") {
            if (!normalized) {
                return { value: false, issue: null, blocking: false };
            }
            lowered = normalized.toLowerCase();
            if (["true", "1", "yes", "y", "on"].indexOf(lowered) !== -1) {
                return { value: true, issue: null, blocking: false };
            }
            if (["false", "0", "no", "n", "off", ""].indexOf(lowered) !== -1) {
                return { value: false, issue: null, blocking: false };
            }

            return {
                value: false,
                issue: 'Unrecognized boolean value "' + normalized + '". Use true/false, yes/no, on/off, or 1/0.',
                blocking: true,
            };
        }

        if (type === "choice") {
            if (!normalized) {
                return { value: "", issue: null, blocking: false };
            }

            lowered = normalized.toLowerCase();
            (column.choices || []).some(function (choice) {
                var choiceValue = String(choice && choice.value != null ? choice.value : "").trim().toLowerCase();
                var labelSource = choice ? (choice.label != null ? choice.label : choice.value) : null;
                var choiceLabel = String(labelSource != null ? labelSource : "").trim().toLowerCase();
                if (lowered === choiceValue || lowered === choiceLabel) {
                    matchedChoice = choice;
                    return true;
                }
                return false;
            });

            if (matchedChoice) {
                return { value: matchedChoice.value, issue: null, blocking: false };
            }

            return {
                value: normalized,
                issue: 'Choice value "' + normalized + '" does not match any configured option.',
                blocking: false,
            };
        }

        return {
            value: rawValue == null ? getDefaultTabularValue(column) : rawValue,
            issue: null,
            blocking: false,
        };
    }

    function mapCSVToColumns(parsed, columns) {
        var headerIndexByName = Object.create(null);
        var matchedIndexes = Object.create(null);
        var issues = (parsed.issues || []).slice();
        var blockingIssues = [];
        var mappedColumns;
        var missingColumns;
        var unmappedHeaders;
        var mappedRows;

        parsed.headers.forEach(function (header, index) {
            var normalized = normalizeCSVHeader(header);
            if (normalized && headerIndexByName[normalized] === undefined) {
                headerIndexByName[normalized] = index;
            }
        });

        mappedColumns = columns.map(function (column) {
            var keyMatch = headerIndexByName[normalizeCSVHeader(column.key)];
            var labelMatch = headerIndexByName[normalizeCSVHeader(column.label || "")];
            var mappedIndex = keyMatch;
            if (mappedIndex === undefined) {
                mappedIndex = labelMatch;
            }
            if (mappedIndex !== undefined) {
                matchedIndexes[mappedIndex] = true;
            }
            return { column: column, index: mappedIndex };
        });

        missingColumns = mappedColumns
            .filter(function (entry) {
                return entry.index === undefined && entry.column.required === true;
            })
            .map(function (entry) {
                return entry.column.label || entry.column.key;
            });

        unmappedHeaders = parsed.headers.filter(function (header, index) {
            return !matchedIndexes[index];
        });

        mappedRows = parsed.rows.map(function (rowEntry) {
            var row = {};
            mappedColumns.forEach(function (entry) {
                var rawValue = entry.index === undefined ? getDefaultTabularValue(entry.column) : rowEntry.values[entry.index];
                var coercion = coerceCSVColumnValue(entry.column, rawValue);
                var issueText;
                row[entry.column.key] = coercion.value;

                if (coercion.issue) {
                    issueText = "Row " + rowEntry.lineNumber + ", " + (entry.column.label || entry.column.key) + ": " + coercion.issue;
                    if (coercion.blocking) {
                        blockingIssues.push(issueText);
                    } else {
                        issues.push(issueText);
                    }
                }
            });
            return row;
        });

        return {
            mappedRows: mappedRows,
            unmappedHeaders: unmappedHeaders,
            missingColumns: missingColumns,
            issues: issues,
            blockingIssues: blockingIssues,
        };
    }

    function summarizeCSVMessages(messages, limit) {
        var rows = Array.isArray(messages) ? messages.filter(Boolean) : [];
        var maxItems = typeof limit === "number" ? limit : 5;
        var visible;
        if (rows.length <= maxItems) {
            return rows;
        }

        visible = rows.slice(0, maxItems);
        visible.push(rows.length - maxItems + " more issue" + (rows.length - maxItems === 1 ? "" : "s") + " not shown.");
        return visible;
    }

    function buildCSVTemplateContent(columns) {
        var headers = columns.map(function (column) {
            return '"' + String(column.label || column.key || "").replace(/"/g, '""') + '"';
        });
        return headers.join(",") + "\n";
    }

    // ------------------------------------------------------------------------------------------------------------
    // List-dict editor (grid editor for `listdict` inputs)
    // ------------------------------------------------------------------------------------------------------------

    function readListDictColumns(inputEl, name) {
        var columns = null;
        var script = document.getElementById("listdict-columns-" + name);
        if (script) {
            columns = parseJson(script.textContent || "", null);
            if (!Array.isArray(columns)) {
                reportOnce("columns-json:" + name, 'Workflow Launcher: invalid column schema JSON for list-dict input "' + name + '".');
            }
        }
        if ((!Array.isArray(columns) || !columns.length) && inputEl.getAttribute("data-columns")) {
            columns = parseJson(inputEl.getAttribute("data-columns"), null);
        }
        return Array.isArray(columns)
            ? columns.filter(function (column) {
                  return column && typeof column === "object";
              })
            : [];
    }

    function columnType(column) {
        return String((column && column.type) || "string").toLowerCase();
    }

    function isNumericType(type) {
        return type === "integer" || type === "number";
    }

    function getColumnMinWidth(column) {
        var type = columnType(column);
        if (type === "boolean") {
            return "110px";
        }
        if (isNumericType(type)) {
            return "140px";
        }
        if (type === "choice") {
            return "170px";
        }
        return "220px";
    }

    function getColumnInputValue(type, input) {
        if (type === "boolean") {
            return input.checked;
        }
        if (isNumericType(type)) {
            return input.value === "" ? "" : Number(input.value);
        }
        return input.value;
    }

    // Per-cell checks (legacy validateCell): required, number, regex validators on text cells.
    function cellErrors(input) {
        var column = input._wlColumn;
        var type = input._wlType;
        var labelText = column.label || column.key || "Value";
        var required = column.required === true;
        var errors = [];
        var value = input.value;
        if (type === "boolean") {
            return errors;
        }
        if (isNumericType(type)) {
            if (required && value === "") {
                errors.push(labelText + " is required.");
            } else if (value !== "" && isNaN(Number(value))) {
                errors.push(labelText + " must be a number.");
            }
            return errors;
        }
        if (type === "choice" && Array.isArray(column.choices)) {
            if (required && !value) {
                errors.push(labelText + " is required.");
            }
            return errors;
        }
        if (required && (!value || value.trim() === "")) {
            errors.push(labelText + " is required.");
        }
        if (value && Array.isArray(column.validators)) {
            column.validators.forEach(function (validator) {
                if (validator && validator.regex && !matchesValidator(validator, value)) {
                    errors.push(validator.message || labelText + " format is invalid.");
                }
            });
        }
        return errors;
    }

    function refreshCell(input) {
        var column = input._wlColumn;
        var errors = input._wlTouched ? cellErrors(input) : [];
        if (input._wlDuplicate) {
            errors.push((column.label || column.key || "Value") + " must be unique.");
        }
        input.classList.toggle("is-invalid", errors.length > 0);
        setInvalid(input, errors.length > 0);
        if (errors.length) {
            input.title = errors.join("\n");
        } else {
            input.removeAttribute("title");
        }
    }

    function enhanceListDictField(field) {
        if (field.source.dataset.enhanced === "1") {
            return;
        }
        var inputEl = field.source;
        var name = field.name;
        var columns = readListDictColumns(inputEl, name);
        var editor = createElement("div", "wl-grid-editor");
        var toolbar = createElement("div", "wl-grid-editor__toolbar");
        var addRowButton = createButton("btn btn-secondary btn-sm", "mdi-table-row-plus-after", "Add row");
        var importButton = createButton("btn btn-secondary btn-sm", "mdi-file-upload-outline", "Import CSV");
        var templateButton = createButton("btn btn-secondary btn-sm", "mdi-file-download-outline", "Download template");
        var fileInput = createElement("input");
        var countEl = createElement("span", "wl-grid-editor__count");
        var statusNotice = createElement("div", "alert alert-info wl-grid-editor__notice");
        var duplicateNotice = createElement(
            "div",
            "alert alert-warning wl-grid-editor__notice",
            "Duplicate values found in columns marked as unique."
        );
        var scroll = createElement("div", "wl-grid-editor__scroll");
        var table = createElement("table", "table table-sm wl-grid-editor__table");
        var thead = createElement("thead");
        var headRow = createElement("tr");
        var tbody = createElement("tbody");
        var indexHeader = createElement("th", "wl-grid-editor__index", "#");
        var actionsHeader = createElement("th", "wl-grid-editor__actions");
        var control = field.group ? field.group.querySelector(".wl-field__control") : null;
        var state;

        if (!columns.length) {
            reportOnce(
                "columns:" + name,
                'Workflow Launcher: no columns defined for list-dict input "' +
                    name +
                    '"; ensure the workflow YAML has a "columns" list and the Git repository has been re-synced.'
            );
        }
        inputEl.style.display = "none";

        fileInput.type = "file";
        fileInput.accept = ".csv,text/csv";
        fileInput.hidden = true;
        fileInput.tabIndex = -1;
        fileInput.setAttribute("aria-hidden", "true");
        countEl.setAttribute("aria-live", "polite");
        toolbar.appendChild(addRowButton);
        toolbar.appendChild(importButton);
        toolbar.appendChild(templateButton);
        toolbar.appendChild(fileInput);
        toolbar.appendChild(countEl);
        statusNotice.hidden = true;
        statusNotice.setAttribute("aria-live", "polite");
        duplicateNotice.hidden = true;

        indexHeader.scope = "col";
        headRow.appendChild(indexHeader);
        columns.forEach(function (column) {
            var th = createElement("th", null, column.label || column.key || "Column");
            var marker;
            th.scope = "col";
            th.style.minWidth = getColumnMinWidth(column);
            if (column.required === true) {
                marker = createElement("span", "wl-field__required", " *");
                marker.setAttribute("aria-hidden", "true");
                th.appendChild(marker);
                th.appendChild(createElement("span", "visually-hidden", " (required)"));
            }
            headRow.appendChild(th);
        });
        actionsHeader.scope = "col";
        actionsHeader.appendChild(createElement("span", "visually-hidden", "Actions"));
        headRow.appendChild(actionsHeader);
        thead.appendChild(headRow);
        table.appendChild(thead);
        table.appendChild(tbody);
        table.setAttribute("aria-label", getFieldLabel(name));
        scroll.appendChild(table);
        editor.appendChild(toolbar);
        editor.appendChild(statusNotice);
        editor.appendChild(duplicateNotice);
        editor.appendChild(scroll);
        if (control) {
            control.appendChild(editor);
        } else {
            insertAfter(editor, inputEl);
        }

        state = {
            columns: columns,
            rows: parseJsonArray(inputEl.value).map(function (row) {
                return row && typeof row === "object" && !Array.isArray(row) ? row : {};
            }),
            rowControls: [],
            table: table,
            focusTarget: function () {
                return (state.rowControls[0] && state.rowControls[0][0]) || addRowButton;
            },
            touchAll: function () {
                state.rowControls.forEach(function (controls) {
                    controls.forEach(function (input) {
                        input._wlTouched = true;
                        refreshCell(input);
                    });
                });
            },
        };
        field.state = state;

        function commit(notification) {
            inputEl.value = JSON.stringify(state.rows);
            inputEl.dispatchEvent(new Event("input", { bubbles: true }));
            if (notification === "changed") {
                onValueChanged(name);
            } else if (notification === "edited") {
                onValueEdited(name);
            }
        }

        function showCSVStatus(level, message) {
            var list;
            clearChildren(statusNotice);
            if (!message || (Array.isArray(message) && message.length === 0)) {
                statusNotice.hidden = true;
                statusNotice.className = "alert alert-info wl-grid-editor__notice";
                return;
            }
            statusNotice.className =
                "alert alert-" + (NOTICE_LEVELS.indexOf(level) !== -1 ? level : "info") + " wl-grid-editor__notice";
            if (Array.isArray(message) && message.length > 1) {
                list = createElement("ul");
                message.forEach(function (line) {
                    list.appendChild(createElement("li", null, line));
                });
                statusNotice.appendChild(list);
            } else {
                statusNotice.textContent = Array.isArray(message) ? message[0] : message;
            }
            statusNotice.hidden = false;
        }

        function applyUniquenessHighlights() {
            var anyDuplicates = false;
            state.columns.forEach(function (column, columnIndex) {
                var seen = Object.create(null);
                var duplicates = Object.create(null);
                if (column.unique !== true) {
                    return;
                }
                state.rows.forEach(function (row, rowIndex) {
                    var value = listDictCellValue(row, column);
                    var key;
                    if (value === undefined || value === null || String(value).trim() === "") {
                        return;
                    }
                    key = String(value).trim().toLowerCase();
                    if (key in seen) {
                        duplicates[seen[key]] = true;
                        duplicates[rowIndex] = true;
                    } else {
                        seen[key] = rowIndex;
                    }
                });
                state.rowControls.forEach(function (controls, rowIndex) {
                    var input = controls[columnIndex];
                    if (!input) {
                        return;
                    }
                    input._wlDuplicate = rowIndex in duplicates;
                    anyDuplicates = anyDuplicates || input._wlDuplicate;
                    refreshCell(input);
                });
            });
            duplicateNotice.hidden = !anyDuplicates;
        }

        function buildInputForColumn(column, value, rowIndex) {
            var type = columnType(column);
            var input;
            if (type === "boolean") {
                input = createElement("input", "form-check-input");
                input.type = "checkbox";
                input.checked = value === true || value === "true";
            } else if (isNumericType(type)) {
                input = createElement("input", "form-control form-control-sm");
                input.type = "number";
                input.value = value !== undefined && value !== null ? value : "";
            } else if (type === "choice" && Array.isArray(column.choices)) {
                input = createElement("select", "form-select form-select-sm");
                input.appendChild(createOption("", NATIVE_PLACEHOLDER_LABEL));
                column.choices.forEach(function (choice) {
                    var isObject = choice && typeof choice === "object";
                    var choiceValue = isObject ? choice.value : choice;
                    input.appendChild(createOption(choiceValue, (isObject && choice.label) || choiceValue));
                });
                if (value !== undefined && value !== null) {
                    input.value = String(value);
                }
            } else {
                input = createElement("input", "form-control form-control-sm");
                input.type = "text";
                input.value = value !== undefined && value !== null ? value : "";
            }
            if (type !== "boolean") {
                input.style.minWidth = getColumnMinWidth(column);
            }
            input.setAttribute("data-no-validate", "true");
            input.setAttribute("aria-label", (column.label || column.key || "Column") + " row " + (rowIndex + 1));
            input._wlColumn = column;
            input._wlType = type;

            function syncCellValue(notification) {
                state.rows[rowIndex] = state.rows[rowIndex] || {};
                state.rows[rowIndex][column.key] = getColumnInputValue(type, input);
                input._wlTouched = true;
                commit(notification);
                refreshCell(input);
                applyUniquenessHighlights();
            }

            input.addEventListener("input", function () {
                syncCellValue("edited");
            });
            input.addEventListener("change", function () {
                syncCellValue("changed");
            });
            input.addEventListener("blur", function () {
                input._wlTouched = true;
                refreshCell(input);
            });
            return input;
        }

        function renderRows() {
            var emptyRow;
            var emptyCell;
            clearChildren(tbody);
            state.rowControls = [];
            if (!state.rows.length) {
                emptyRow = createElement("tr");
                emptyCell = createElement("td", "wl-grid-editor__empty", "No rows yet. Add a row or import a CSV file.");
                emptyCell.colSpan = state.columns.length + 2;
                emptyRow.appendChild(emptyCell);
                tbody.appendChild(emptyRow);
            }
            state.rows.forEach(function (row, rowIndex) {
                var tr = createElement("tr");
                var actions = createElement("td", "wl-grid-editor__actions");
                var remove = createButton("btn btn-danger btn-sm wl-btn-icon", "mdi-trash-can-outline", "");
                var controls = [];
                tr.appendChild(createElement("td", "wl-grid-editor__index", rowIndex + 1));
                state.columns.forEach(function (column) {
                    var td = createElement("td");
                    var input = buildInputForColumn(column, listDictCellValue(row, column), rowIndex);
                    controls.push(input);
                    td.appendChild(input);
                    tr.appendChild(td);
                });
                remove.setAttribute("aria-label", "Remove row " + (rowIndex + 1));
                remove.title = "Remove row";
                remove.addEventListener("click", function () {
                    removeRow(rowIndex);
                });
                actions.appendChild(remove);
                tr.appendChild(actions);
                state.rowControls.push(controls);
                tbody.appendChild(tr);
            });
            countEl.textContent = pluralize(state.rows.length, "row");
            applyUniquenessHighlights();
        }

        function removeRow(rowIndex) {
            var buttons;
            state.rows.splice(rowIndex, 1);
            renderRows();
            commit("changed");
            buttons = tbody.querySelectorAll(".wl-grid-editor__actions .btn");
            (buttons[Math.min(rowIndex, buttons.length - 1)] || addRowButton).focus();
        }

        // Rebuilds the rows from the cell controls (column keys only), like the legacy syncCurrentListFromDom.
        function syncFromDom() {
            state.rows = state.rowControls
                .filter(function (controls) {
                    return controls.length > 0;
                })
                .map(function (controls) {
                    var rowData = {};
                    state.columns.forEach(function (column, columnIndex) {
                        if (controls[columnIndex]) {
                            rowData[column.key] = getColumnInputValue(columnType(column), controls[columnIndex]);
                        }
                    });
                    return rowData;
                });
            commit(null);
        }

        function importCSV(file, text) {
            var parsed = parseCSV(text);
            var mapped;
            var matchedColumns;
            var messages;
            if (!parsed.headers.length) {
                showCSVStatus("danger", "The uploaded CSV is empty or missing a header row.");
                return;
            }

            mapped = mapCSVToColumns(parsed, state.columns);
            matchedColumns = state.columns.length - mapped.missingColumns.length;
            if (!mapped.mappedRows.length && parsed.rows.length) {
                showCSVStatus("danger", "The CSV could not be mapped to any configured columns.");
                return;
            }

            if (mapped.blockingIssues.length) {
                showCSVStatus(
                    "danger",
                    summarizeCSVMessages(
                        ["The CSV was not imported because some values cannot be represented in the form."].concat(
                            mapped.blockingIssues
                        ),
                        6
                    )
                );
                return;
            }

            state.rows = mapped.mappedRows;
            renderRows();
            commit("changed");

            messages = [
                "Loaded " +
                    mapped.mappedRows.length +
                    " row" +
                    (mapped.mappedRows.length === 1 ? "" : "s") +
                    " from " +
                    file.name +
                    ".",
            ];
            if (matchedColumns <= 0) {
                messages.push("No matching headers were found.");
            }
            if (mapped.missingColumns.length) {
                messages.push("Missing required columns: " + mapped.missingColumns.join(", ") + ".");
            }
            if (mapped.unmappedHeaders.length) {
                messages.push("Ignored CSV columns: " + mapped.unmappedHeaders.join(", ") + ".");
            }
            if (mapped.issues.length) {
                messages = messages.concat(summarizeCSVMessages(mapped.issues, 5));
            }

            showCSVStatus(mapped.missingColumns.length || mapped.issues.length ? "warning" : "success", messages);
        }

        addRowButton.addEventListener("click", function () {
            var newRow = {};
            var controls;
            showCSVStatus("", "");
            state.columns.forEach(function (column) {
                newRow[column.key] = getDefaultTabularValue(column);
            });
            state.rows.push(newRow);
            renderRows();
            commit("changed");
            controls = state.rowControls[state.rowControls.length - 1];
            if (controls && controls[0]) {
                controls[0].focus();
            }
        });

        importButton.addEventListener("click", function () {
            fileInput.click();
        });

        templateButton.addEventListener("click", function () {
            var blob = new Blob([buildCSVTemplateContent(state.columns)], { type: "text/csv;charset=utf-8;" });
            var url = URL.createObjectURL(blob);
            var link = createElement("a");
            link.href = url;
            link.download = name + "_template.csv";
            link.hidden = true;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.setTimeout(function () {
                URL.revokeObjectURL(url);
            }, BLOB_URL_TTL_MS);
        });

        fileInput.addEventListener("change", function () {
            var selectedFile = fileInput.files && fileInput.files[0];
            var reader;
            if (!selectedFile) {
                return;
            }
            reader = new FileReader();
            reader.onload = function (loadEvent) {
                try {
                    importCSV(selectedFile, loadEvent.target && loadEvent.target.result ? loadEvent.target.result : "");
                } catch (error) {
                    showCSVStatus(
                        "danger",
                        String(
                            error && error.message
                                ? error.message
                                : "Unable to parse the CSV file. Check quoting and delimiters, then try again."
                        )
                    );
                } finally {
                    fileInput.value = "";
                }
            };
            reader.onerror = function () {
                showCSVStatus("danger", "The selected file could not be read.");
                fileInput.value = "";
            };
            reader.readAsText(selectedFile);
        });

        inputEl._syncListDictFromDom = syncFromDom;
        inputEl._wlReset = function () {
            state.rows = [];
            showCSVStatus("", "");
            renderRows();
            commit(null);
        };
        renderRows();
        inputEl.value = JSON.stringify(state.rows);
        inputEl.dataset.enhanced = "1";
    }

    // ------------------------------------------------------------------------------------------------------------
    // Validator guidance & accessibility wiring
    // ------------------------------------------------------------------------------------------------------------

    function isTextControl(field) {
        var source = field.source;
        var type = (source.getAttribute("type") || "text").toLowerCase();
        return field.kind === "text" && (source.tagName === "TEXTAREA" || (source.tagName === "INPUT" && TEXT_INPUT_TYPES.indexOf(type) !== -1));
    }

    // Replaces the legacy hover tooltips: validator messages are listed under the control unless help text exists.
    function setupValidatorHint(field, hint) {
        var validators;
        var target;
        var titles;
        var messages;
        var node;
        var anchor;
        if (!isTextControl(field) && field.kind !== "list") {
            return null;
        }
        validators = readValidators(field.source);
        if (!validators.length) {
            return null;
        }
        target = getFocusTarget(field);
        titles = uniqueStrings(
            validators.map(function (validator) {
                if (validator.message) {
                    return String(validator.message);
                }
                return validator.regex ? "Must match pattern: " + validator.regex : "";
            })
        );
        if (titles.length && target) {
            target.title = titles.join("\n");
        }
        messages = uniqueStrings(
            validators.map(function (validator) {
                return validator.message ? String(validator.message) : "";
            })
        );
        if (!messages.length || hint || !field.group) {
            return null;
        }
        node = createElement("div", "form-text wl-validator-hint");
        node.id = "hint_" + field.name + "_validators";
        messages.forEach(function (message) {
            node.appendChild(createElement("div", null, message));
        });
        anchor = field.group.querySelector(".wl-field__control") || (field.state && field.state.meta) || field.source;
        insertAfter(node, anchor);
        return node;
    }

    function setupFieldAccessibility(field) {
        var hint;
        var validatorHint;
        var feedback;
        var target;
        var ids = [];
        if (!field.group) {
            return;
        }
        hint = document.getElementById("hint_" + field.name);
        validatorHint = setupValidatorHint(field, hint);
        feedback = getFeedback(field);
        target = field.kind === "listdict" && field.state ? field.state.table : getFocusTarget(field);
        if (hint) {
            ids.push(hint.id);
        }
        if (validatorHint) {
            ids.push(validatorHint.id);
        }
        if (!feedback.id) {
            feedback.id = "feedback_" + field.name;
        }
        ids.push(feedback.id);
        if (target) {
            target.setAttribute("aria-describedby", mergeTokenList(target.getAttribute("aria-describedby"), ids));
        }
        if (field.kind !== "listdict" && field.group.classList.contains("has-error")) {
            setInvalid(getFocusTarget(field), true);
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Timing & scheduling
    // ------------------------------------------------------------------------------------------------------------

    function pad2(value) {
        return (value < 10 ? "0" : "") + value;
    }

    function formatLocalDateTime(date) {
        return (
            date.getFullYear() +
            "-" +
            pad2(date.getMonth() + 1) +
            "-" +
            pad2(date.getDate()) +
            "T" +
            pad2(date.getHours()) +
            ":" +
            pad2(date.getMinutes())
        );
    }

    function parseLocalDateTime(value) {
        var match = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?/.exec(String(value || "").trim());
        var date;
        if (!match) {
            return null;
        }
        date = new Date(+match[1], +match[2] - 1, +match[3], +match[4], +match[5], match[6] ? +match[6] : 0);
        return isNaN(date.getTime()) ? null : date;
    }

    function browserTimeZone() {
        try {
            return Intl.DateTimeFormat().resolvedOptions().timeZone || "";
        } catch (error) {
            return "";
        }
    }

    function updateClock() {
        var now = new Date();
        if (ui.serverTime) {
            ui.serverTime.textContent = now.toISOString().slice(0, 19).replace("T", " ") + " UTC";
        }
        if (ui.localTime) {
            ui.localTime.textContent = now.toLocaleString() + " (" + (browserTimeZone() || "Local Time") + ")";
        }
    }

    function getExecutionType() {
        var checked = ui.form.querySelector('input[name="execution_type"]:checked');
        return checked ? checked.value : "immediate";
    }

    function minutesAhead(input) {
        var minutes = parseInt(input.getAttribute("data-minutes-ahead") || String(DEFAULT_MINUTES_AHEAD), 10);
        return Math.max(1, isNaN(minutes) ? DEFAULT_MINUTES_AHEAD : minutes);
    }

    // Local-time min (now + data-minutes-ahead) and, when requested, the default value (now + 10 minutes).
    function applyScheduleBounds(setDefault) {
        var input = ui.scheduleInput;
        var now = Date.now();
        if (!input) {
            return;
        }
        input.setAttribute("min", formatLocalDateTime(new Date(now + minutesAhead(input) * 60000)));
        if (setDefault) {
            input.value = formatLocalDateTime(new Date(now + DEFAULT_SCHEDULE_OFFSET_MINUTES * 60000));
            scheduleAutoDefault = true;
        }
    }

    // The server converts the local schedule with this offset, so use the offset in effect at the scheduled time (DST).
    function refreshTimezoneOffset() {
        var offsetInput = document.getElementById("browser_timezone_offset_minutes");
        var scheduled = null;
        if (!offsetInput) {
            return;
        }
        if (ui.scheduleInput && getExecutionType() === "scheduled") {
            scheduled = parseLocalDateTime(ui.scheduleInput.value);
        }
        offsetInput.value = String((scheduled || new Date()).getTimezoneOffset());
    }

    function clearScheduleFeedback() {
        var feedback = ui.scheduleGroup ? ui.scheduleGroup.querySelector("[data-wl-feedback]") : null;
        if (feedback && feedback.textContent.trim()) {
            clearChildren(feedback);
        }
        if (ui.scheduleGroup) {
            ui.scheduleGroup.classList.remove("has-error");
        }
        setInvalid(ui.scheduleInput, false);
    }

    function updateSubmitLabel() {
        var type = getExecutionType();
        if (submitting || !ui.submitLabel) {
            return;
        }
        ui.submitLabel.textContent = Object.prototype.hasOwnProperty.call(SUBMIT_LABELS, type)
            ? SUBMIT_LABELS[type]
            : SUBMIT_LABELS.immediate;
    }

    function updateTimingVisibility() {
        var type = getExecutionType();
        if (ui.scheduleGroup) {
            ui.scheduleGroup.hidden = type !== "scheduled";
        }
        if (ui.servicenowNote) {
            ui.servicenowNote.hidden = type !== "servicenow";
        }
        if (type === "scheduled") {
            // Refresh an untouched default so a form left open for a while does not propose a past time.
            applyScheduleBounds(scheduleAutoDefault || !(ui.scheduleInput && ui.scheduleInput.value));
        }
        updateSubmitLabel();
    }

    function initTiming() {
        var nameInput = document.getElementById("browser_timezone_name");
        var offsetInput = document.getElementById("browser_timezone_offset_minutes");
        if (offsetInput) {
            offsetInput.value = String(new Date().getTimezoneOffset());
        }
        if (nameInput) {
            nameInput.value = browserTimeZone();
        }
        if (ui.serverTime || ui.localTime) {
            updateClock();
            window.setInterval(updateClock, CLOCK_INTERVAL_MS);
        }
        if (ui.scheduleInput) {
            applyScheduleBounds(!ui.scheduleInput.value);
            ["input", "change"].forEach(function (type) {
                ui.scheduleInput.addEventListener(type, function () {
                    scheduleAutoDefault = false;
                    clearScheduleFeedback();
                });
            });
        }
        toArray(ui.form.querySelectorAll('input[name="execution_type"]')).forEach(function (radio) {
            radio.addEventListener("change", updateTimingVisibility);
        });
        updateTimingVisibility();
    }

    // ------------------------------------------------------------------------------------------------------------
    // Form-fill timing
    // ------------------------------------------------------------------------------------------------------------

    function initFormFillTiming() {
        var startedInput = document.getElementById("form_started_at");
        var started = false;
        if (!startedInput) {
            return;
        }
        // Capture phase, so widgets that stop propagation still count; synthetic events from our own syncs do not.
        function markStart(event) {
            var target = event.target;
            if (started || event.isTrusted === false) {
                return;
            }
            if (event.type === "click" && !(target && target.closest && target.closest(CLICK_START_SELECTOR))) {
                return;
            }
            started = true;
            startedInput.value = String(Date.now());
        }
        ui.root.addEventListener("input", markStart, true);
        ui.root.addEventListener("change", markStart, true);
        ui.root.addEventListener("click", markStart, true);
    }

    function computeFormDuration() {
        var durationInput = document.getElementById("form_duration_seconds");
        var startedInput = document.getElementById("form_started_at");
        var started;
        var now;
        var seconds = 0;
        if (!durationInput) {
            return;
        }
        try {
            started = parseInt((startedInput && startedInput.value) || "0", 10);
            now = Date.now();
            if (!isNaN(started) && started > 0 && now >= started) {
                seconds = Math.round((now - started) / 1000);
            }
            durationInput.value = String(Math.max(0, seconds));
        } catch (error) {
            durationInput.value = "0";
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Required progress
    // ------------------------------------------------------------------------------------------------------------

    function updateRequiredProgress() {
        var total = 0;
        var done = 0;
        var percent;
        if (!ui.progressText && !ui.progressBar) {
            return;
        }
        fieldOrder.forEach(function (field) {
            if (field.source.getAttribute("data-required") !== "true" || !isFieldVisible(field)) {
                return;
            }
            total += 1;
            if (field.kind === "checkbox" || getFieldValue(field.name).trim() !== "") {
                done += 1;
            }
        });
        if (!total) {
            return;
        }
        percent = Math.round((done / total) * 100);
        if (ui.progressText) {
            ui.progressText.textContent = done + " of " + total + " required fields completed";
        }
        if (ui.progressBar) {
            ui.progressBar.style.setProperty("--wl-value", percent + "%");
            if (ui.progressBar.getAttribute("role") === "progressbar") {
                ui.progressBar.setAttribute("aria-valuenow", String(percent));
            }
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Submit handling
    // ------------------------------------------------------------------------------------------------------------

    function setSubmitting(active) {
        submitting = active;
        if (!ui.submit) {
            return;
        }
        ui.submit.disabled = active;
        if (active) {
            ui.submit.setAttribute("aria-busy", "true");
        } else {
            ui.submit.removeAttribute("aria-busy");
        }
        if (ui.submitIcon) {
            ui.submitIcon.className = active ? SUBMITTING_ICON_CLASS : ui.submitIconClass;
        }
        if (active && ui.submitLabel) {
            ui.submitLabel.textContent = SUBMITTING_LABEL;
        } else {
            updateSubmitLabel();
        }
    }

    function onSubmit(event) {
        var valid;
        if (event.defaultPrevented) {
            return;
        }
        event.preventDefault();
        // A submission is already on its way; ignore repeated submits (legacy _submitPassThrough guard).
        if (submitting) {
            return;
        }
        try {
            valid = validateForm();
        } catch (error) {
            console.error("Workflow Launcher: validation failed unexpectedly.", error);
            renderUnexpectedError(error);
            return;
        }
        if (!valid) {
            return;
        }
        computeFormDuration();
        refreshTimezoneOffset();
        setSubmitting(true);
        try {
            // Native submit bypasses this listener (no submit event is fired).
            HTMLFormElement.prototype.submit.call(ui.form);
        } catch (error) {
            console.error("Workflow Launcher: the form could not be submitted.", error);
            setSubmitting(false);
            renderUnexpectedError(error);
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Init
    // ------------------------------------------------------------------------------------------------------------

    function init() {
        ui.form = document.getElementById("workflow-launch-form");
        if (!ui.form) {
            return;
        }
        ui.root = document.getElementById("dynamic-form");
        ui.clientErrors = document.getElementById("wl-client-errors");
        ui.submit = document.getElementById("wl-submit");
        ui.submitIcon = ui.submit ? ui.submit.querySelector("[data-wl-submit-icon]") : null;
        ui.submitIconClass = ui.submitIcon ? ui.submitIcon.className : "";
        ui.submitLabel = ui.submit ? ui.submit.querySelector("[data-wl-submit-label]") : null;
        ui.progressText = document.getElementById("wl-required-progress-text");
        ui.progressBar = document.getElementById("wl-required-progress-bar");
        ui.scheduleGroup = document.getElementById("group_scheduled_datetime");
        ui.scheduleInput = ui.form.querySelector('input[name="scheduled_datetime"]');
        ui.servicenowNote = document.getElementById("wl-servicenow-note");
        ui.serverTime = document.getElementById("server-time");
        ui.localTime = document.getElementById("local-time");

        if (ui.root) {
            registerFields();
            fieldOrder.forEach(function (field) {
                if (field.kind === "select") {
                    safely('enhancing dropdown "' + field.name + '"', function () {
                        enhanceSelect(field);
                    });
                }
            });
            fieldOrder.forEach(function (field) {
                if (field.kind === "list") {
                    safely('enhancing list "' + field.name + '"', function () {
                        enhanceListField(field);
                    });
                }
            });
            fieldOrder.forEach(function (field) {
                if (field.kind === "listdict") {
                    safely('enhancing table "' + field.name + '"', function () {
                        enhanceListDictField(field);
                    });
                }
            });
            fieldOrder.forEach(function (field) {
                safely('wiring accessibility for "' + field.name + '"', function () {
                    setupFieldAccessibility(field);
                });
            });
            // Initial pass: hidden fields keep server-provided prefill (data-initial) instead of being reset.
            preserveInitial = true;
            try {
                updateVisibility();
            } finally {
                preserveInitial = false;
            }
            ui.root.addEventListener("input", onNativeInput);
            ui.root.addEventListener("change", onNativeChange);
            initFormFillTiming();
        }
        initTiming();
        updateRequiredProgress();
        ui.form.addEventListener("submit", onSubmit);
        window.addEventListener("pageshow", function (event) {
            if (event.persisted) {
                setSubmitting(false);
            }
        });
    }

    onReady(init);
})();
