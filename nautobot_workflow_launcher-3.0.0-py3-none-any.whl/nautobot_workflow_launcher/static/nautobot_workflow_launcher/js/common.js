/*
 * Workflow Launcher shared behaviors, loaded on every app page before page scripts.
 * Declarative hooks:
 *   form[data-wl-autosubmit]           submit when a control changes (skip controls with data-wl-no-autosubmit)
 *   [data-wl-range-control]            radio/select; value "custom" reveals [data-wl-custom-range] instead of submitting
 *   tr[data-wl-href]                   whole-row navigation (ctrl/cmd/middle click opens a new tab)
 *   [data-wl-copy="text"]              copy literal text; [data-wl-copy-target="#id"] copies the element's text
 *   form[data-wl-confirm="message"]    confirm before submitting
 *   time[data-wl-relative]             relative time text kept fresh every minute
 * Page scripts can use window.WorkflowLauncher.{onReady, copyText, announce, escapeHtml, formatRelative, isSafeUrl}.
 */
(function () {
    "use strict";

    var RELATIVE_REFRESH_MS = 60000;
    var COPY_FEEDBACK_MS = 1500;
    // Keyboard users arrow through radios/selects; wait until they settle before reloading the page.
    var KEYBOARD_SUBMIT_DELAY_MS = 900;
    var FOCUS_RESTORE_KEY = "wl-autosubmit-focus";

    var lastInputWasKeyboard = false;
    var pendingSubmits = typeof WeakMap === "function" ? new WeakMap() : null;

    function onReady(callback) {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", callback);
        } else {
            callback();
        }
    }

    function escapeHtml(value) {
        return String(value == null ? "" : value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function isSafeUrl(value) {
        if (!value) {
            return false;
        }
        try {
            var url = new URL(value, window.location.href);
            return url.protocol === "http:" || url.protocol === "https:";
        } catch (error) {
            return false;
        }
    }

    function isSameOriginUrl(value) {
        try {
            return new URL(value, window.location.href).origin === window.location.origin;
        } catch (error) {
            return false;
        }
    }

    var liveRegion = null;
    function announce(message) {
        if (!liveRegion) {
            liveRegion = document.createElement("div");
            liveRegion.className = "visually-hidden";
            liveRegion.setAttribute("role", "status");
            liveRegion.setAttribute("aria-live", "polite");
            document.body.appendChild(liveRegion);
        }
        liveRegion.textContent = "";
        window.setTimeout(function () {
            liveRegion.textContent = message;
        }, 50);
    }

    function copyText(text) {
        if (navigator.clipboard && window.isSecureContext) {
            return navigator.clipboard.writeText(text);
        }
        return new Promise(function (resolve, reject) {
            var area = document.createElement("textarea");
            area.value = text;
            area.setAttribute("readonly", "");
            area.style.position = "fixed";
            area.style.opacity = "0";
            document.body.appendChild(area);
            area.select();
            try {
                if (document.execCommand("copy")) {
                    resolve();
                } else {
                    reject(new Error("Copy command was rejected"));
                }
            } catch (error) {
                reject(error);
            } finally {
                document.body.removeChild(area);
            }
        });
    }

    function flashCopied(button) {
        var icon = button.querySelector(".mdi");
        var originalIcon = icon ? icon.className : null;
        button.classList.add("is-copied");
        if (icon) {
            icon.className = "mdi mdi-check";
        }
        window.setTimeout(function () {
            button.classList.remove("is-copied");
            if (icon && originalIcon) {
                icon.className = originalIcon;
            }
        }, COPY_FEEDBACK_MS);
    }

    function formatRelative(date, now) {
        var reference = now || new Date();
        var seconds = Math.round((reference.getTime() - date.getTime()) / 1000);
        var future = seconds < 0;
        var text;
        seconds = Math.abs(seconds);
        if (seconds < 45) {
            return "just now";
        }
        if (seconds < 3600) {
            text = Math.max(1, Math.floor(seconds / 60)) + "m";
        } else if (seconds < 86400) {
            text = Math.floor(seconds / 3600) + "h";
        } else if (seconds < 30 * 86400) {
            text = Math.floor(seconds / 86400) + "d";
        } else if (seconds < 365 * 86400) {
            text = Math.floor(seconds / (30 * 86400)) + "mo";
        } else {
            text = Math.floor(seconds / (365 * 86400)) + "y";
        }
        return future ? "in " + text : text + " ago";
    }

    function refreshRelativeTimes() {
        var now = new Date();
        document.querySelectorAll("time[data-wl-relative][datetime]").forEach(function (element) {
            var date = new Date(element.getAttribute("datetime"));
            if (!isNaN(date.getTime())) {
                element.textContent = formatRelative(date, now);
            }
        });
    }

    function syncCustomRange(form) {
        var control = form.querySelector("input[data-wl-range-control]:checked, select[data-wl-range-control]");
        var isCustom = Boolean(control && control.value === "custom");
        form.querySelectorAll("[data-wl-custom-range]").forEach(function (container) {
            container.hidden = !isCustom;
            container.querySelectorAll("input, select").forEach(function (input) {
                input.disabled = !isCustom;
            });
        });
        return isCustom;
    }

    function submitForm(form) {
        if (typeof form.requestSubmit === "function") {
            form.requestSubmit();
        } else {
            form.submit();
        }
    }

    function autoSubmit(form, field) {
        if (field.id) {
            try {
                window.sessionStorage.setItem(FOCUS_RESTORE_KEY, field.id);
            } catch (error) {
                // Storage may be unavailable (private mode); focus restore is a nicety.
            }
        }
        if (!lastInputWasKeyboard || !pendingSubmits) {
            submitForm(form);
            return;
        }
        window.clearTimeout(pendingSubmits.get(form));
        pendingSubmits.set(
            form,
            window.setTimeout(function () {
                submitForm(form);
            }, KEYBOARD_SUBMIT_DELAY_MS)
        );
    }

    function restoreFocus() {
        var id = null;
        try {
            id = window.sessionStorage.getItem(FOCUS_RESTORE_KEY);
            window.sessionStorage.removeItem(FOCUS_RESTORE_KEY);
        } catch (error) {
            return;
        }
        var element = id ? document.getElementById(id) : null;
        if (element && !element.disabled) {
            element.focus({ preventScroll: true });
        }
    }

    function handleChange(event) {
        var field = event.target;
        var form = field && field.form;
        if (!form) {
            return;
        }
        if (field.hasAttribute("data-wl-range-control") && syncCustomRange(form)) {
            var firstInput = form.querySelector("[data-wl-custom-range] input");
            if (firstInput) {
                firstInput.focus();
            }
            return;
        }
        if (form.hasAttribute("data-wl-autosubmit") && !field.hasAttribute("data-wl-no-autosubmit")) {
            autoSubmit(form, field);
        }
    }

    function handleClick(event) {
        var copyButton = event.target.closest("[data-wl-copy], [data-wl-copy-target]");
        if (copyButton) {
            event.preventDefault();
            var text = copyButton.getAttribute("data-wl-copy");
            var targetSelector = copyButton.getAttribute("data-wl-copy-target");
            if (targetSelector) {
                var target = document.querySelector(targetSelector);
                text = target ? target.textContent : "";
            }
            copyText(text || "").then(
                function () {
                    flashCopied(copyButton);
                    announce("Copied to clipboard");
                },
                function () {
                    announce("Copy failed");
                }
            );
            return;
        }

        var row = event.target.closest("tr[data-wl-href]");
        if (!row || event.defaultPrevented || event.button > 1) {
            return;
        }
        if (event.target.closest("a, button, input, select, textarea, label, summary, [data-wl-no-row-link]")) {
            return;
        }
        if (window.getSelection && String(window.getSelection()).length > 0) {
            return;
        }
        var href = row.getAttribute("data-wl-href");
        if (!isSameOriginUrl(href)) {
            return;
        }
        if (event.metaKey || event.ctrlKey || event.button === 1) {
            window.open(href, "_blank", "noopener");
        } else {
            window.location.assign(href);
        }
    }

    function handleSubmit(event) {
        var form = event.target;
        var message = form && form.getAttribute && form.getAttribute("data-wl-confirm");
        if (message && !window.confirm(message)) {
            event.preventDefault();
            event.stopImmediatePropagation();
        }
    }

    document.addEventListener("change", handleChange);
    document.addEventListener(
        "keydown",
        function () {
            lastInputWasKeyboard = true;
        },
        true
    );
    document.addEventListener(
        "pointerdown",
        function () {
            lastInputWasKeyboard = false;
        },
        true
    );
    document.addEventListener("click", handleClick);
    document.addEventListener("auxclick", function (event) {
        if (event.button === 1) {
            handleClick(event);
        }
    });
    document.addEventListener("submit", handleSubmit, true);

    onReady(function () {
        document.querySelectorAll("form").forEach(function (form) {
            if (form.querySelector("[data-wl-range-control]")) {
                syncCustomRange(form);
            }
        });
        refreshRelativeTimes();
        window.setInterval(refreshRelativeTimes, RELATIVE_REFRESH_MS);
        restoreFocus();
    });

    window.WorkflowLauncher = {
        onReady: onReady,
        copyText: copyText,
        flashCopied: flashCopied,
        announce: announce,
        escapeHtml: escapeHtml,
        formatRelative: formatRelative,
        isSafeUrl: isSafeUrl,
    };
})();
