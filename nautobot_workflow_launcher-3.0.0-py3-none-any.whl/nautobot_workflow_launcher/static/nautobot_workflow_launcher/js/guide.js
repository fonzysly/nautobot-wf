/*
 * Workflow user guide dialog.
 * Declarative hook: [data-wl-guide-url] opens the shared #wl-guide-dialog and lazily loads the
 * server-rendered guide fragment for that workflow.
 */
(function () {
    "use strict";

    var api = window.WorkflowLauncher || {};
    var cache = {};

    function isSameOrigin(value) {
        try {
            return new URL(value, window.location.href).origin === window.location.origin;
        } catch (error) {
            return false;
        }
    }

    function setMessage(content, message) {
        content.textContent = "";
        var paragraph = document.createElement("p");
        paragraph.className = "wl-guide__message";
        paragraph.textContent = message;
        content.appendChild(paragraph);
    }

    function open(dialog, trigger) {
        var content = dialog.querySelector("[data-wl-guide-content]");
        var title = dialog.querySelector(".wl-guide__title");
        var url = trigger.getAttribute("data-wl-guide-url");
        if (!content || !url || !isSameOrigin(url)) {
            return;
        }

        title.textContent = trigger.getAttribute("data-wl-guide-title") || "User guide";
        dialog.wlReturnFocus = trigger;

        if (typeof dialog.showModal === "function") {
            dialog.showModal();
        } else {
            dialog.setAttribute("open", "open");
        }

        if (cache[url]) {
            // Fragment HTML is sanitized server-side by render_workflow_guide.
            content.innerHTML = cache[url];
            return;
        }

        setMessage(content, "Loading guide…");
        window
            .fetch(url, { credentials: "same-origin", headers: { "X-Requested-With": "XMLHttpRequest" } })
            .then(function (response) {
                if (!response.ok) {
                    throw new Error("Guide request failed");
                }
                return response.text();
            })
            .then(function (html) {
                cache[url] = html;
                content.innerHTML = html;
                content.scrollTop = 0;
            })
            .catch(function () {
                setMessage(content, "This guide could not be loaded. Try again later.");
            });
    }

    function close(dialog) {
        if (typeof dialog.close === "function") {
            dialog.close();
        } else {
            dialog.removeAttribute("open");
        }
    }

    function init() {
        var dialog = document.getElementById("wl-guide-dialog");
        if (!dialog) {
            return;
        }

        document.addEventListener("click", function (event) {
            var trigger = event.target.closest("[data-wl-guide-url]");
            if (trigger) {
                event.preventDefault();
                open(dialog, trigger);
                return;
            }
            if (event.target.closest("[data-wl-guide-close]")) {
                close(dialog);
            }
        });

        // Native dialogs treat the backdrop as part of the element, so compare against its box.
        dialog.addEventListener("click", function (event) {
            if (event.target !== dialog) {
                return;
            }
            var box = dialog.getBoundingClientRect();
            var outside =
                event.clientX < box.left ||
                event.clientX > box.right ||
                event.clientY < box.top ||
                event.clientY > box.bottom;
            if (outside) {
                close(dialog);
            }
        });

        dialog.addEventListener("close", function () {
            if (dialog.wlReturnFocus) {
                dialog.wlReturnFocus.focus();
                dialog.wlReturnFocus = null;
            }
        });
    }

    if (typeof api.onReady === "function") {
        api.onReady(init);
    } else {
        document.addEventListener("DOMContentLoaded", init);
    }
})();
