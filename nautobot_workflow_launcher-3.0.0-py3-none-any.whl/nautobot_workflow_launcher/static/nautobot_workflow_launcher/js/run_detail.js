/*
 * Workflow run detail page ("live run console").
 * Renders the pipeline, AWX jobs and log viewer from #wl-run-state plus the server-rendered logs, then polls
 * #wl-run-root[data-progress-url] until the run is terminal. Untrusted text (logs, names, errors, AWX data) is
 * only written through textContent, and only http(s) URLs become links.
 */
(function () {
    "use strict";

    var POLL_MS = 3000;
    var MAX_POLL_MS = 15000;
    // Scheduled runs can be hours away; pre-action preparation reports as "running" and polls fast.
    var SCHEDULED_POLL_MS = 30000;
    var BOTTOM_THRESHOLD_PX = 24;
    var BLOB_URL_TTL_MS = 10000;
    var WRAP_STORAGE_KEY = "wl-log-wrap";
    var STOP_POLLING_HTTP_STATUSES = [401, 403, 404];
    var PHASE_ORDER = ["pre", "main", "post"];
    var DEFAULT_PHASE_LABELS = { pre: "Pre-actions", main: "Main actions", post: "Post-actions" };
    var COMPLETE_STEP_STATUSES = ["success", "failed", "skipped"];
    var TONES = ["success", "danger", "warning", "primary", "violet", "neutral"];
    var ICON_PATTERN = /^mdi-[a-z0-9-]+$/;
    var LOG_ID_BY_TAB = { "wl-tab-output": "run-user-log", "wl-tab-debug": "run-debug-log" };
    var LINE_ERROR = /traceback|exception|error|failed|failure/i;
    var LINE_WARN = /warn/i;
    var LINE_INFO = /^\s*\[(pre|main|post)\]/i;
    var LINE_OK = /\b(success|successful|succeeded|completed)\b/i;
    var DASH = "\u2014";
    var UNAVAILABLE = new Error("Live updates unavailable");

    var ui = {};
    var state = null;
    var progressUrl = "";
    var shortId = "";
    var logCache = {};
    var pipelineKey = null;
    var resultsKey = null;
    var awxKey = null;
    var badgeKey = "";
    var progressValue = 0;
    var follow = false;
    var wrap = false;
    var activeLogId = "run-user-log";
    var polling = false;
    var pollTimer = null;
    var inFlight = false;
    var failures = 0;

    function lib() {
        return window.WorkflowLauncher || null;
    }

    function onReady(callback) {
        var wl = lib();
        if (wl && typeof wl.onReady === "function") {
            wl.onReady(callback);
        } else if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", callback);
        } else {
            callback();
        }
    }

    function announce(message) {
        var wl = lib();
        if (wl && typeof wl.announce === "function") {
            wl.announce(message);
        }
    }

    function isSafeUrl(url) {
        var wl = lib();
        return Boolean(url && wl && typeof wl.isSafeUrl === "function" && wl.isSafeUrl(url));
    }

    function hasText(value) {
        return /\S/.test(value);
    }

    function readStorage(area, key) {
        try {
            return window[area].getItem(key);
        } catch (error) {
            return null;
        }
    }

    function writeStorage(area, key, value) {
        try {
            window[area].setItem(key, value);
        } catch (error) {
            // Preferences are best-effort when storage is blocked or full.
        }
    }

    function byId(id) {
        return document.getElementById(id);
    }

    function el(tag, className, text) {
        var node = document.createElement(tag);
        if (className) {
            node.className = className;
        }
        if (text !== undefined && text !== null) {
            node.textContent = String(text);
        }
        return node;
    }

    function icon(name, fallback) {
        var node = el("span", "mdi " + (ICON_PATTERN.test(String(name || "")) ? name : fallback || "mdi-circle-small"));
        node.setAttribute("aria-hidden", "true");
        return node;
    }

    function hiddenText(text) {
        return el("span", "visually-hidden", text);
    }

    function toneOf(value) {
        return TONES.indexOf(value) === -1 ? "neutral" : value;
    }

    function setTone(node, value) {
        if (!node) {
            return;
        }
        Array.prototype.slice.call(node.classList).forEach(function (name) {
            if (name.indexOf("wl-tone-") === 0) {
                node.classList.remove(name);
            }
        });
        node.classList.add("wl-tone-" + toneOf(value));
    }

    function setText(node, value) {
        var text = value === undefined || value === null ? "" : String(value);
        if (node && node.textContent !== text) {
            node.textContent = text;
        }
    }

    function replaceContent(node, content) {
        node.textContent = "";
        node.appendChild(content);
    }

    function setPressed(button, pressed) {
        if (button) {
            button.setAttribute("aria-pressed", pressed ? "true" : "false");
            button.classList.toggle("is-active", pressed);
        }
    }

    // Mirrors Python's str.title() used by the awx_status_badge template tag.
    function titleCase(value) {
        return String(value)
            .toLowerCase()
            .replace(/(^|[^a-z])([a-z])/g, function (match, before, letter) {
                return before + letter.toUpperCase();
            });
    }

    function externalLink(url, className, text) {
        var link = el("a", className, text);
        link.href = url;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        return link;
    }

    function statusBadge(badge, status, large) {
        var pill = el("span", "wl-status wl-tone-" + toneOf(badge.tone) + (large ? " wl-status--lg" : ""));
        var dot;
        pill.setAttribute("data-status", status || "");
        if (badge.live) {
            dot = el("span", "wl-status__dot");
            dot.setAttribute("aria-hidden", "true");
            pill.appendChild(dot);
        } else {
            pill.appendChild(icon(badge.icon, "mdi-help-circle"));
        }
        pill.appendChild(document.createTextNode(badge.label || status || ""));
        return pill;
    }

    function awxBadge(run) {
        var pill = el("span", "wl-status wl-tone-" + toneOf(run.tone));
        pill.appendChild(icon(run.icon, "mdi-timer-sand"));
        pill.appendChild(document.createTextNode(titleCase(run.status || "unknown")));
        return pill;
    }

    function badgeSignature(payload) {
        var badge = payload.status_badge || {};
        return [payload.status, badge.label, badge.tone, badge.icon, badge.live].join("|");
    }

    function isComplete(step) {
        return COMPLETE_STEP_STATUSES.indexOf(step.status) !== -1;
    }

    function phaseTone(steps) {
        var statuses = steps.map(function (step) {
            return step.status;
        });
        if (statuses.indexOf("failed") !== -1) {
            return "danger";
        }
        if (statuses.indexOf("running") !== -1) {
            return "primary";
        }
        var finished = statuses.every(function (status) {
            return status === "success" || status === "skipped";
        });
        return finished ? "success" : "neutral";
    }

    function groupSteps(steps) {
        var groups = {};
        PHASE_ORDER.forEach(function (phase) {
            groups[phase] = { phase: phase, label: "", steps: [] };
        });
        steps.forEach(function (step) {
            // The executor treats unknown phases as "main"; group them the same way.
            var phase = step.phase === "pre" || step.phase === "post" ? step.phase : "main";
            var group = groups[phase];
            if (!group.label && step.phase === phase && step.phase_label) {
                group.label = String(step.phase_label);
            }
            group.steps.push(step);
        });
        return PHASE_ORDER.map(function (phase) {
            return groups[phase];
        }).filter(function (group) {
            return group.steps.length > 0;
        });
    }

    function buildStepProgress(step) {
        var wrapper = el("div", "wl-step__progress");
        var bar = el("div", "wl-progress wl-progress--slim");
        var fill = el("div", "wl-progress__fill");
        var percent = Math.max(0, Math.min(100, Number(step.progress_percent)));

        fill.style.width = percent + "%";
        bar.setAttribute("role", "progressbar");
        bar.setAttribute("aria-valuenow", String(percent));
        bar.setAttribute("aria-valuemin", "0");
        bar.setAttribute("aria-valuemax", "100");
        bar.setAttribute("aria-label", (step.name || "Step") + " progress");
        bar.appendChild(fill);
        wrapper.appendChild(bar);
        if (step.progress_message) {
            wrapper.appendChild(el("span", "wl-meta", step.progress_message));
        }
        return wrapper;
    }

    function buildStepDetails(step) {
        var details = el("details", "wl-step__details");
        var summary = el("summary", null, "Details");
        var body = el("div", "wl-step__details-body");
        var returned;

        details.appendChild(summary);
        if (step.error) {
            body.appendChild(el("h4", "wl-step__details-heading", "Error"));
            body.appendChild(el("pre", "wl-pre wl-tone-danger", step.error));
        }
        if (step.return_value !== null && step.return_value !== undefined && step.return_value !== "") {
            try {
                returned = JSON.stringify(step.return_value, null, 2);
            } catch (error) {
                returned = String(step.return_value);
            }
            body.appendChild(el("h4", "wl-step__details-heading", "Returned"));
            body.appendChild(el("pre", "wl-pre", returned));
        }
        details.appendChild(body);
        return details;
    }

    function buildStep(step) {
        var item = el("li", "wl-step");
        var marker = el("span", "wl-step__icon wl-tone-" + toneOf(step.tone));
        var body = el("div", "wl-step__body");
        var meta = el("div", "wl-step__meta");
        var type = el("span", "wl-meta");
        var detail;
        var conditional;
        var hasDetails;

        item.setAttribute("data-status", step.status || "pending");
        if (step.status === "running") {
            item.setAttribute("aria-current", "step");
        }
        marker.appendChild(icon(step.icon, "mdi-circle-outline"));
        item.appendChild(marker);

        body.appendChild(el("span", "wl-step__name", step.name));
        type.appendChild(icon(step.type_icon, "mdi-cog-outline"));
        type.appendChild(document.createTextNode(step.type_label || "Action"));
        meta.appendChild(type);
        if (step.detail) {
            detail = el("span", "wl-mono wl-truncate", step.detail);
            detail.title = String(step.detail);
            meta.appendChild(detail);
        }
        meta.appendChild(el("span", null, step.status_label || step.status));
        if (step.duration_display) {
            meta.appendChild(el("span", "wl-meta", step.duration_display));
        }
        if (step.current_step) {
            meta.appendChild(el("span", "wl-tag wl-tone-primary", step.current_step));
        }
        if (step.conditional) {
            conditional = el("span", "wl-tag wl-tone-warning", "Conditional");
            conditional.title = "Runs only when its condition is met";
            meta.appendChild(conditional);
        }
        body.appendChild(meta);

        if (step.status === "running" && typeof step.progress_percent === "number") {
            body.appendChild(buildStepProgress(step));
        }
        if (step.error) {
            body.appendChild(el("p", "wl-step__error", step.error_summary || step.error));
        }
        hasDetails =
            (step.error && step.error !== step.error_summary) ||
            (step.return_value !== null && step.return_value !== undefined && step.return_value !== "");
        if (hasDetails) {
            body.appendChild(buildStepDetails(step));
        }
        item.appendChild(body);
        return item;
    }

    function buildPhase(group) {
        var labelId = "wl-phase-" + group.phase;
        var total = group.steps.length;
        var done = group.steps.filter(isComplete).length;
        var phase = el("div", "wl-phase wl-tone-" + phaseTone(group.steps));
        var head = el("div", "wl-phase__head");
        var label = el("span", null, group.label || DEFAULT_PHASE_LABELS[group.phase]);
        var count = el("span", "wl-num", done + "/" + total);
        var list = el("ol", "wl-phase__steps");

        label.id = labelId;
        count.setAttribute("aria-hidden", "true");
        head.appendChild(label);
        head.appendChild(count);
        head.appendChild(hiddenText(done + " of " + total + " complete"));
        phase.appendChild(head);

        list.setAttribute("aria-labelledby", labelId);
        group.steps.forEach(function (step) {
            list.appendChild(buildStep(step));
        });
        phase.appendChild(list);
        return phase;
    }

    function renderPipeline(steps) {
        var list = Array.isArray(steps) ? steps : [];
        var key = JSON.stringify(list);
        var fragment;
        var complete;
        if (!ui.pipeline || key === pipelineKey) {
            return;
        }
        pipelineKey = key;
        fragment = document.createDocumentFragment();
        groupSteps(list).forEach(function (group) {
            fragment.appendChild(buildPhase(group));
        });
        replaceContent(ui.pipeline, fragment);
        complete = list.filter(isComplete).length;
        setText(ui.pipelineMeta, complete + " of " + list.length + (list.length === 1 ? " step" : " steps") + " complete");
    }

    function buildResultLinks(links) {
        var list = el("ul", "wl-result__links");
        links.forEach(function (link) {
            var item = el("li");
            var anchor;
            if (isSafeUrl(link.url)) {
                anchor = el("a", "wl-link", link.label || link.url);
                anchor.href = String(link.url);
                item.appendChild(anchor);
            } else {
                item.appendChild(el("span", null, link.label || ""));
            }
            list.appendChild(item);
        });
        return list;
    }

    function buildResultTable(table) {
        var wrapper = el("div", "wl-table-wrap");
        var node = el("table", "table wl-table");
        var thead = el("thead");
        var headRow = el("tr");
        var tbody = el("tbody");

        (table.columns || []).forEach(function (column) {
            headRow.appendChild(el("th", null, column));
        });
        thead.appendChild(headRow);
        node.appendChild(thead);

        (table.rows || []).forEach(function (row) {
            var tr = el("tr");
            row.forEach(function (cell) {
                tr.appendChild(el("td", null, cell));
            });
            tbody.appendChild(tr);
        });
        node.appendChild(tbody);
        wrapper.appendChild(node);
        if (table.truncated) {
            wrapper.appendChild(el("p", "wl-meta", "Showing the first " + (table.rows || []).length + " rows."));
        }
        return wrapper;
    }

    function buildResultMetrics(metrics) {
        var list = el("dl", "wl-result__metrics");
        metrics.forEach(function (metric) {
            list.appendChild(el("dt", null, metric.label));
            list.appendChild(el("dd", null, metric.value));
        });
        return list;
    }

    function buildResultBlock(entry) {
        var data = entry.structured || {};
        var block = el("section", "wl-result");
        var head = el("div", "wl-result__head");

        head.appendChild(el("h3", "wl-result__title", entry.name));
        head.appendChild(el("span", "wl-meta", entry.phase_label || ""));
        block.appendChild(head);

        if (data.summary) {
            block.appendChild(el("p", "wl-result__summary", data.summary));
        }
        if (Array.isArray(data.metrics) && data.metrics.length) {
            block.appendChild(buildResultMetrics(data.metrics));
        }
        if (data.table) {
            block.appendChild(buildResultTable(data.table));
        }
        if (Array.isArray(data.changed) && data.changed.length) {
            block.appendChild(el("h4", "wl-result__heading", "Changed"));
            block.appendChild(buildResultLinks(data.changed));
        }
        if (Array.isArray(data.links) && data.links.length) {
            block.appendChild(el("h4", "wl-result__heading", "Links"));
            block.appendChild(buildResultLinks(data.links));
        }
        return block;
    }

    function buildArtifactList(artifacts) {
        var block = el("section", "wl-result");
        var list = el("ul", "wl-result__links");

        block.appendChild(el("h3", "wl-result__title", "Files"));
        artifacts.forEach(function (artifact) {
            var item = el("li");
            var anchor;
            if (isSafeUrl(artifact.url)) {
                anchor = el("a", "wl-link", artifact.name);
                anchor.href = String(artifact.url);
                anchor.setAttribute("download", "");
                item.appendChild(anchor);
            } else {
                item.appendChild(el("span", null, artifact.name));
            }
            item.appendChild(el("span", "wl-meta", artifact.size_display || ""));
            list.appendChild(item);
        });
        block.appendChild(list);
        return block;
    }

    function renderResults(results, artifacts) {
        var entries = Array.isArray(results) ? results : [];
        var files = Array.isArray(artifacts) ? artifacts : [];
        var key = JSON.stringify([entries, files]);
        var fragment;

        if (!ui.results || key === resultsKey) {
            return;
        }
        resultsKey = key;

        if (!entries.length && !files.length) {
            ui.resultsSection.hidden = true;
            replaceContent(ui.results, document.createDocumentFragment());
            return;
        }

        fragment = document.createDocumentFragment();
        entries.forEach(function (entry) {
            fragment.appendChild(buildResultBlock(entry));
        });
        if (files.length) {
            fragment.appendChild(buildArtifactList(files));
        }
        replaceContent(ui.results, fragment);
        ui.resultsSection.hidden = false;
    }

    function buildAwxRow(run) {
        var row = el("tr");
        var url = isSafeUrl(run.url) ? String(run.url) : "";
        var job = run.job_id ? "#" + run.job_id : "";
        var jobCell = el("td");
        var statusCell = el("td");
        var actionCell = el("td", "wl-col-actions");
        var link;

        row.appendChild(el("td", "wl-mono", run.template_id));

        if (job && url) {
            link = externalLink(url, null, job + " ");
            link.appendChild(icon("mdi-open-in-new"));
            link.appendChild(hiddenText(" (opens in a new tab)"));
            jobCell.appendChild(link);
        } else if (job) {
            jobCell.textContent = job;
        } else {
            jobCell.appendChild(el("span", "wl-subtle", DASH));
        }
        row.appendChild(jobCell);

        statusCell.appendChild(awxBadge(run));
        row.appendChild(statusCell);

        if (url) {
            link = externalLink(url, "btn btn-secondary btn-sm", "Open in AWX");
            link.appendChild(hiddenText(" (" + (job ? "job " + job + ", " : "") + "opens in a new tab)"));
            actionCell.appendChild(link);
        }
        row.appendChild(actionCell);
        return row;
    }

    function renderAwx(runs) {
        var list = Array.isArray(runs) ? runs : [];
        var key = JSON.stringify(list);
        var fragment;
        if (key === awxKey) {
            return;
        }
        awxKey = key;
        if (ui.awxBody) {
            fragment = document.createDocumentFragment();
            list.forEach(function (run) {
                fragment.appendChild(buildAwxRow(run));
            });
            replaceContent(ui.awxBody, fragment);
        }
        setText(ui.awxCount, list.length);
        if (list.length > 0) {
            if (ui.awxTabItem) {
                ui.awxTabItem.hidden = false;
            }
            if (ui.awxTab) {
                ui.awxTab.disabled = false;
            }
        }
    }

    function activeLog() {
        return activeLogId === "run-debug-log" ? ui.debugLog : ui.userLog;
    }

    function isNearBottom(pre) {
        return pre.scrollHeight - pre.scrollTop - pre.clientHeight <= BOTTOM_THRESHOLD_PX;
    }

    function scrollToBottom(pre) {
        if (pre) {
            pre.scrollTop = pre.scrollHeight;
        }
    }

    function emptyLogMessage(pre) {
        if (state && state.is_terminal) {
            return "No output was produced.";
        }
        return pre.id === "run-debug-log" ? "No debug output yet." : "No output yet.";
    }

    function splitLines(text) {
        var lines = text.split(/\r?\n/);
        if (lines.length > 1 && lines[lines.length - 1] === "") {
            lines.pop();
        }
        // Executors append "\n<message>" to empty logs; the HTML parser also drops a <pre>'s first newline.
        if (lines.length > 1 && lines[0] === "") {
            lines.shift();
        }
        return lines;
    }

    function lineModifier(line) {
        if (LINE_ERROR.test(line)) {
            return "wl-log__line--error";
        }
        if (LINE_WARN.test(line)) {
            return "wl-log__line--warn";
        }
        if (LINE_INFO.test(line)) {
            return "wl-log__line--info";
        }
        if (LINE_OK.test(line)) {
            return "wl-log__line--ok";
        }
        return "";
    }

    function renderLog(pre, text) {
        if (!pre) {
            return;
        }
        var raw = text === undefined || text === null ? "" : String(text);
        var emptyMessage = hasText(raw) ? "" : emptyLogMessage(pre);
        var cached = logCache[pre.id];
        if (cached && cached.raw === raw && cached.emptyMessage === emptyMessage) {
            return;
        }
        logCache[pre.id] = { raw: raw, emptyMessage: emptyMessage };

        var stick = follow || isNearBottom(pre);
        var top = pre.scrollTop;
        var left = pre.scrollLeft;
        var fragment = document.createDocumentFragment();
        if (emptyMessage) {
            fragment.appendChild(el("div", "wl-log__empty", emptyMessage));
        } else {
            splitLines(raw).forEach(function (line) {
                var node = el("span", "wl-log__line", line);
                var modifier = lineModifier(line);
                if (modifier) {
                    node.classList.add(modifier);
                }
                fragment.appendChild(node);
            });
        }
        replaceContent(pre, fragment);
        pre.scrollLeft = left;
        pre.scrollTop = stick ? pre.scrollHeight : top;
    }

    function setFollow(on) {
        follow = Boolean(on);
        setPressed(ui.followButton, follow);
        if (follow) {
            scrollToBottom(activeLog());
        }
    }

    function setWrap(on) {
        wrap = Boolean(on);
        [ui.userLog, ui.debugLog].forEach(function (pre) {
            if (pre) {
                pre.classList.toggle("is-wrapped", wrap);
            }
        });
        setPressed(ui.wrapButton, wrap);
        if (follow) {
            scrollToBottom(activeLog());
        }
    }

    // Scrolling away from the bottom pauses follow, like a terminal; programmatic scrolls always land at the bottom.
    function onLogScroll(event) {
        var pre = event.currentTarget;
        if (follow && pre.id === activeLogId && !isNearBottom(pre)) {
            setFollow(false);
        }
    }

    function activeLogText() {
        var cached = logCache[activeLogId];
        return cached ? cached.raw : "";
    }

    function copyActiveLog() {
        var wl = lib();
        var text = activeLogText();
        if (!hasText(text)) {
            announce("The log is empty");
            return;
        }
        if (!wl || typeof wl.copyText !== "function") {
            return;
        }
        wl.copyText(text).then(
            function () {
                if (typeof wl.flashCopied === "function") {
                    wl.flashCopied(ui.copyButton);
                }
                announce("Log copied to clipboard");
            },
            function () {
                announce("Copy failed");
            }
        );
    }

    function downloadActiveLog() {
        var text = activeLogText();
        var url;
        var link;
        if (!hasText(text)) {
            announce("The log is empty");
            return;
        }
        url = window.URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
        link = el("a");
        link.href = url;
        link.download = "workflow-run-" + shortId + (activeLogId === "run-debug-log" ? "-debug.log" : "-output.log");
        link.hidden = true;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.setTimeout(function () {
            window.URL.revokeObjectURL(url);
        }, BLOB_URL_TTL_MS);
    }

    function bindTools() {
        if (ui.wrapButton) {
            ui.wrapButton.addEventListener("click", function () {
                setWrap(!wrap);
                writeStorage("localStorage", WRAP_STORAGE_KEY, wrap ? "1" : "0");
            });
        }
        if (ui.followButton) {
            ui.followButton.addEventListener("click", function () {
                setFollow(!follow);
            });
        }
        if (ui.copyButton) {
            ui.copyButton.addEventListener("click", copyActiveLog);
        }
        if (ui.downloadButton) {
            ui.downloadButton.addEventListener("click", downloadActiveLog);
        }
        [ui.userLog, ui.debugLog].forEach(function (pre) {
            if (pre) {
                pre.addEventListener("scroll", onLogScroll, { passive: true });
            }
        });
    }

    function onTabShown(button) {
        var logId = Object.prototype.hasOwnProperty.call(LOG_ID_BY_TAB, button.id) ? LOG_ID_BY_TAB[button.id] : "";
        if (ui.logTools) {
            ui.logTools.hidden = !logId;
        }
        if (logId) {
            activeLogId = logId;
            if (follow) {
                scrollToBottom(activeLog());
            }
        }
    }

    function bindTabs() {
        var buttons = ui.tabList ? Array.prototype.slice.call(ui.tabList.querySelectorAll('[data-bs-toggle="tab"]')) : [];
        buttons.forEach(function (button) {
            button.addEventListener("shown.bs.tab", function () {
                onTabShown(button);
            });
        });
    }

    function updateProgress(payload, tone) {
        var value = Math.max(0, Math.min(100, Math.round(Number(payload.progress_percent) || 0)));
        value = payload.is_terminal ? 100 : Math.max(value, progressValue);
        progressValue = value;
        if (ui.progressBar) {
            ui.progressBar.style.setProperty("--wl-value", value + "%");
            ui.progressBar.setAttribute("aria-valuenow", String(value));
            setTone(ui.progressBar, tone);
        }
        if (ui.progress) {
            ui.progress.classList.toggle("is-live", !payload.is_terminal);
        }
        setText(ui.progressText, payload.progress_text);
    }

    function stopPolling() {
        polling = false;
        window.clearTimeout(pollTimer);
        pollTimer = null;
        document.removeEventListener("visibilitychange", onVisibilityChange);
    }

    function finish(payload) {
        stopPolling();
        setFollow(false);
        setText(ui.updated, "");
        announce("Run finished: " + (payload.status_label || payload.status || ""));
    }

    function apply(payload) {
        if (!payload || typeof payload !== "object") {
            return;
        }
        var wasTerminal = Boolean(state && state.is_terminal);
        var badge = payload.status_badge || { label: payload.status_label, tone: "neutral", live: false };
        var nextBadgeKey = badgeSignature(payload);
        state = payload;

        // The badge container is a live region: only touch it when the status really changed.
        if (ui.badge && nextBadgeKey !== badgeKey) {
            badgeKey = nextBadgeKey;
            replaceContent(ui.badge, statusBadge(badge, payload.status, true));
        }
        setTone(ui.hero, badge.tone);
        setText(ui.headline, payload.headline);
        updateProgress(payload, badge.tone);
        document.querySelectorAll('[data-wl-bind="execution_duration_display"]').forEach(function (node) {
            setText(node, payload.execution_duration_display || "-");
        });
        if (ui.postWarning) {
            ui.postWarning.hidden = !payload.has_post_action_errors;
        }
        if (ui.cancelForm) {
            ui.cancelForm.hidden = payload.status !== "scheduled";
        }
        renderPipeline(payload.steps);
        renderResults(payload.results, payload.artifacts);
        renderAwx(payload.awx_runs);
        if (typeof payload.user_log === "string") {
            renderLog(ui.userLog, payload.user_log);
        }
        if (typeof payload.log === "string") {
            renderLog(ui.debugLog, payload.log);
        }
        if (payload.is_terminal && !wasTerminal) {
            finish(payload);
        }
    }

    function nextPollDelay() {
        return state && state.status === "scheduled" ? SCHEDULED_POLL_MS : POLL_MS;
    }

    function schedulePoll(delay) {
        window.clearTimeout(pollTimer);
        pollTimer = null;
        if (polling && !document.hidden) {
            pollTimer = window.setTimeout(poll, delay);
        }
    }

    function onVisibilityChange() {
        if (document.hidden) {
            window.clearTimeout(pollTimer);
            pollTimer = null;
        } else {
            poll();
        }
    }

    function poll() {
        pollTimer = null;
        if (!polling || inFlight || document.hidden) {
            return;
        }
        inFlight = true;
        window
            .fetch(progressUrl, {
                method: "GET",
                credentials: "same-origin",
                cache: "no-store",
                headers: { "X-Requested-With": "XMLHttpRequest", Accept: "application/json" },
            })
            .then(function (response) {
                // A redirect means the session expired and we were sent to the login page.
                if (response.redirected || STOP_POLLING_HTTP_STATUSES.indexOf(response.status) !== -1) {
                    throw UNAVAILABLE;
                }
                if (!response.ok) {
                    throw new Error("Progress request failed with HTTP " + response.status);
                }
                return response.json();
            })
            .then(function (payload) {
                inFlight = false;
                failures = 0;
                apply(payload);
                if (polling) {
                    setText(ui.updated, "Updated just now");
                    schedulePoll(nextPollDelay());
                }
            })
            .catch(function (error) {
                inFlight = false;
                if (error === UNAVAILABLE) {
                    stopPolling();
                    if (ui.progress) {
                        ui.progress.classList.remove("is-live");
                    }
                    setText(ui.updated, "Live updates unavailable");
                    return;
                }
                window.console.warn("Workflow Launcher: live update failed", error);
                failures += 1;
                setText(ui.updated, "Reconnecting\u2026");
                schedulePoll(Math.min(MAX_POLL_MS, POLL_MS * Math.pow(2, failures)));
            });
    }

    function startPolling() {
        polling = true;
        document.addEventListener("visibilitychange", onVisibilityChange);
        schedulePoll(nextPollDelay());
    }

    function init() {
        var root = byId("wl-run-root");
        var stateNode = byId("wl-run-state");
        if (!root || !stateNode) {
            return;
        }
        try {
            state = JSON.parse(stateNode.textContent);
        } catch (error) {
            window.console.error("Workflow Launcher: unreadable run state", error);
            return;
        }

        progressUrl = root.getAttribute("data-progress-url") || "";
        shortId = String(root.getAttribute("data-run-id") || state.pk || "")
            .replace(/[^A-Za-z0-9-]/g, "")
            .slice(0, 8);
        ui = {
            hero: byId("wl-run-hero"),
            badge: byId("run-status-badge-container"),
            headline: byId("wl-run-headline"),
            progress: byId("wl-progress"),
            progressBar: byId("live-progress-bar"),
            progressText: byId("live-progress-text"),
            updated: byId("wl-progress-updated"),
            postWarning: byId("post-action-warning"),
            cancelForm: byId("wl-cancel-form"),
            pipeline: byId("wl-pipeline"),
            pipelineMeta: byId("wl-pipeline-meta"),
            results: byId("wl-results"),
            resultsSection: byId("wl-results-section"),
            awxBody: byId("awx-runs-body"),
            awxCount: byId("wl-awx-count"),
            awxTabItem: byId("wl-tab-awx-item"),
            awxTab: byId("wl-tab-awx"),
            tabList: byId("wl-run-tabs"),
            logTools: byId("wl-logtools"),
            wrapButton: byId("wl-log-wrap"),
            followButton: byId("wl-log-follow"),
            copyButton: byId("wl-log-copy"),
            downloadButton: byId("wl-log-download"),
            userLog: byId("run-user-log"),
            debugLog: byId("run-debug-log"),
        };
        badgeKey = badgeSignature(state);
        progressValue = Number(state.progress_percent) || 0;

        renderPipeline(state.steps);
        renderResults(state.results, state.artifacts);
        renderAwx(state.awx_runs);
        setWrap(readStorage("localStorage", WRAP_STORAGE_KEY) === "1");
        setFollow(!state.is_terminal);
        renderLog(ui.userLog, ui.userLog ? ui.userLog.textContent : "");
        renderLog(ui.debugLog, ui.debugLog ? ui.debugLog.textContent : "");
        bindTools();
        bindTabs();

        if (!state.is_terminal && progressUrl) {
            startPolling();
        }
    }

    onReady(init);
})();
