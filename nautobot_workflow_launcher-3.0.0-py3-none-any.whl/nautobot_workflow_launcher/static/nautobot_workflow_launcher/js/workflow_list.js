/*
 * Workflow catalog page behavior (loaded after common.js).
 *   #wl-catalog-search  instant multi-word filter over [data-wl-item][data-wl-search]; "/" focuses it, Escape clears it
 *   [data-wl-group]     hidden when none of its items match; its [data-wl-group-count] shows the visible count
 *   .wl-group-toggle    list-view category collapse, remembered in localStorage
 *   #wl-collapse-all    collapses or expands every category group at once
 */
(function () {
    "use strict";

    var SEARCH_STORAGE_KEY = "wl-catalog-search";
    var COLLAPSED_STORAGE_KEY = "wl-catalog-collapsed";
    var SEARCH_DEBOUNCE_MS = 120;
    var COLLAPSE_ALL_ICON = "mdi-unfold-less-horizontal";
    var EXPAND_ALL_ICON = "mdi-unfold-more-horizontal";

    function readStorage(storageName, key) {
        try {
            return window[storageName].getItem(key);
        } catch (error) {
            return null;
        }
    }

    function writeStorage(storageName, key, value) {
        try {
            if (value) {
                window[storageName].setItem(key, value);
            } else {
                window[storageName].removeItem(key);
            }
        } catch (error) {
            // Storage can be disabled or full; the page keeps working without remembering state.
        }
    }

    function readCollapsedKeys() {
        try {
            var parsed = JSON.parse(readStorage("localStorage", COLLAPSED_STORAGE_KEY) || "[]");
            return Array.isArray(parsed)
                ? parsed.filter(function (key) {
                      return typeof key === "string";
                  })
                : [];
        } catch (error) {
            return [];
        }
    }

    function toArray(list) {
        return Array.prototype.slice.call(list);
    }

    function tokenize(query) {
        return String(query || "")
            .toLowerCase()
            .split(/\s+/)
            .filter(function (token) {
                return token.length > 0;
            });
    }

    function matchesAll(text, tokens) {
        for (var i = 0; i < tokens.length; i++) {
            if (text.indexOf(tokens[i]) === -1) {
                return false;
            }
        }
        return true;
    }

    function isTypingTarget(target) {
        if (!target || !target.tagName) {
            return false;
        }
        var tag = target.tagName;
        return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || target.isContentEditable === true;
    }

    function describeMatches(visible, total, query) {
        var noun = total === 1 ? "workflow" : "workflows";
        var verb = visible === 1 ? "matches" : "match";
        return visible + " of " + total + " " + noun + " " + verb + " \u201C" + query + "\u201D";
    }

    function init() {
        var searchInput = document.getElementById("wl-catalog-search");
        var summary = document.getElementById("wl-catalog-summary");
        var noResults = document.getElementById("wl-catalog-noresults");
        var clearButton = document.getElementById("wl-clear-search");
        var collapseAllButton = document.getElementById("wl-collapse-all");
        var summaryText = summary ? summary.textContent.replace(/\s+/g, " ").trim() : "";
        var toggles = toArray(document.querySelectorAll(".wl-group-toggle[aria-controls]"));
        var searchActive = false;
        var debounceTimer = null;

        var items = toArray(document.querySelectorAll("[data-wl-item]")).map(function (element) {
            return { element: element, text: (element.getAttribute("data-wl-search") || "").toLowerCase() };
        });

        var groups = toArray(document.querySelectorAll("[data-wl-group]")).map(function (element) {
            var count = element.querySelector("[data-wl-group-count]");
            return {
                element: element,
                items: toArray(element.querySelectorAll("[data-wl-item]")),
                count: count,
                originalCount: count ? count.getAttribute("data-wl-group-count") || count.textContent.trim() : "",
            };
        });

        function groupKey(toggle) {
            return toggle.getAttribute("data-wl-group-key") || "";
        }

        function isExpanded(toggle) {
            return toggle.getAttribute("aria-expanded") !== "false";
        }

        function setExpanded(toggle, expanded) {
            var body = document.getElementById(toggle.getAttribute("aria-controls"));
            toggle.setAttribute("aria-expanded", expanded ? "true" : "false");
            if (body) {
                body.hidden = !expanded;
            }
        }

        function syncCollapseAllButton() {
            if (!collapseAllButton) {
                return;
            }
            var allExpanded = toggles.every(isExpanded);
            var icon = collapseAllButton.querySelector(".mdi");
            var label = collapseAllButton.querySelector("[data-wl-collapse-label]");
            collapseAllButton.setAttribute("aria-expanded", allExpanded ? "true" : "false");
            if (icon) {
                icon.classList.toggle(COLLAPSE_ALL_ICON, allExpanded);
                icon.classList.toggle(EXPAND_ALL_ICON, !allExpanded);
            }
            if (label) {
                label.textContent = allExpanded ? "Collapse all" : "Expand all";
            }
        }

        function saveCollapsedGroups() {
            // Keep keys of groups that are not rendered here, e.g. while a category filter is active.
            var pageKeys = toggles.map(groupKey);
            var keys = readCollapsedKeys().filter(function (key) {
                return pageKeys.indexOf(key) === -1;
            });
            toggles.forEach(function (toggle) {
                if (!isExpanded(toggle)) {
                    keys.push(groupKey(toggle));
                }
            });
            writeStorage("localStorage", COLLAPSED_STORAGE_KEY, keys.length ? JSON.stringify(keys) : "");
        }

        function restoreCollapsedGroups() {
            var collapsed = readCollapsedKeys();
            toggles.forEach(function (toggle) {
                setExpanded(toggle, collapsed.indexOf(groupKey(toggle)) === -1);
            });
            syncCollapseAllButton();
        }

        function setSearchActive(active) {
            if (active === searchActive) {
                return;
            }
            searchActive = active;
            if (!active) {
                restoreCollapsedGroups();
                return;
            }
            // Reveal matches inside collapsed groups without overwriting the remembered collapse state.
            toggles.forEach(function (toggle) {
                setExpanded(toggle, true);
            });
            syncCollapseAllButton();
        }

        function onCollapseChanged() {
            syncCollapseAllButton();
            // Groups are force-expanded while searching, so only changes made outside a search are remembered.
            if (!searchActive) {
                saveCollapsedGroups();
            }
        }

        function applyFilter(query) {
            var tokens = tokenize(query);
            var active = tokens.length > 0;
            var visibleTotal = 0;

            setSearchActive(active);

            items.forEach(function (item) {
                var visible = !active || matchesAll(item.text, tokens);
                item.element.hidden = !visible;
                if (visible) {
                    visibleTotal += 1;
                }
            });

            groups.forEach(function (group) {
                var visibleInGroup = group.items.filter(function (element) {
                    return !element.hidden;
                }).length;
                group.element.hidden = visibleInGroup === 0;
                if (group.count) {
                    group.count.textContent = active ? String(visibleInGroup) : group.originalCount;
                }
            });

            if (noResults) {
                noResults.hidden = !(active && items.length > 0 && visibleTotal === 0);
            }
            if (summary) {
                summary.textContent = active ? describeMatches(visibleTotal, items.length, query.trim()) : summaryText;
            }
        }

        function runSearch() {
            window.clearTimeout(debounceTimer);
            applyFilter(searchInput.value);
            writeStorage("sessionStorage", SEARCH_STORAGE_KEY, tokenize(searchInput.value).length ? searchInput.value : "");
        }

        function clearSearch() {
            searchInput.value = "";
            runSearch();
        }

        toggles.forEach(function (toggle) {
            toggle.addEventListener("click", function () {
                setExpanded(toggle, !isExpanded(toggle));
                onCollapseChanged();
            });
        });

        if (collapseAllButton) {
            collapseAllButton.addEventListener("click", function () {
                var expand = !toggles.every(isExpanded);
                toggles.forEach(function (toggle) {
                    setExpanded(toggle, expand);
                });
                onCollapseChanged();
            });
        }

        restoreCollapsedGroups();

        if (!searchInput) {
            return;
        }

        searchInput.addEventListener("input", function () {
            window.clearTimeout(debounceTimer);
            debounceTimer = window.setTimeout(runSearch, SEARCH_DEBOUNCE_MS);
        });

        searchInput.addEventListener("keydown", function (event) {
            if (event.key !== "Escape" && event.key !== "Esc") {
                return;
            }
            event.preventDefault();
            if (searchInput.value) {
                clearSearch();
            } else {
                searchInput.blur();
            }
        });

        if (clearButton) {
            clearButton.addEventListener("click", function () {
                clearSearch();
                searchInput.focus();
            });
        }

        document.addEventListener("keydown", function (event) {
            if (event.key !== "/" || event.defaultPrevented || event.ctrlKey || event.metaKey || event.altKey) {
                return;
            }
            if (event.isComposing || isTypingTarget(event.target)) {
                return;
            }
            event.preventDefault();
            searchInput.focus();
            searchInput.select();
        });

        // Restore the last query so browser Back returns to the same filtered catalog.
        var initialQuery = searchInput.value || readStorage("sessionStorage", SEARCH_STORAGE_KEY) || "";
        if (tokenize(initialQuery).length) {
            searchInput.value = initialQuery;
            applyFilter(initialQuery);
        }
    }

    var launcher = window.WorkflowLauncher;
    if (launcher && typeof launcher.onReady === "function") {
        launcher.onReady(init);
    } else if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
