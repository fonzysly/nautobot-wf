"""Filters for nautobot_workflow_launcher."""

import django_filters
from nautobot.apps.filters import NautobotFilterSet, SearchFilter

from .models import (
    AwxRun,
    Workflow,
    WorkflowAction,
    WorkflowFilterModule,
    WorkflowHelper,
    WorkflowInput,
    WorkflowRun,
)


class WorkflowFilterSet(NautobotFilterSet):
    """FilterSet for Workflow model."""

    q = SearchFilter(
        filter_predicates={
            "name": "icontains",
            "description": "icontains",
            "category": "icontains",
        },
    )

    class Meta:
        """Meta class for WorkflowFilterSet."""

        model = Workflow
        exclude = ["tags"]


class WorkflowInputFilterSet(NautobotFilterSet):
    """FilterSet for WorkflowInput model."""

    q = SearchFilter(
        filter_predicates={
            "key": "icontains",
            "label": "icontains",
        },
    )
    workflow_key = django_filters.CharFilter(field_name="workflow__key", label="Workflow key")

    class Meta:
        """Meta class for WorkflowInputFilterSet."""

        model = WorkflowInput
        fields = "__all__"


class WorkflowActionFilterSet(NautobotFilterSet):
    """FilterSet for WorkflowAction model."""

    q = SearchFilter(
        filter_predicates={
            "name": "icontains",
            "script_path": "icontains",
        },
    )
    workflow_key = django_filters.CharFilter(field_name="workflow__key", label="Workflow key")

    class Meta:
        """Meta class for WorkflowActionFilterSet."""

        model = WorkflowAction
        fields = "__all__"


class WorkflowRunFilterSet(NautobotFilterSet):
    """FilterSet for WorkflowRun model."""

    q = SearchFilter(
        filter_predicates={
            "workflow__name": "icontains",
            "schedule_change_ticket": "icontains",
        },
    )
    workflow_key = django_filters.CharFilter(field_name="workflow__key", label="Workflow key")
    started = django_filters.DateTimeFromToRangeFilter()
    finished = django_filters.DateTimeFromToRangeFilter()
    scheduled_for = django_filters.DateTimeFromToRangeFilter()

    class Meta:
        """Meta class for WorkflowRunFilterSet."""

        model = WorkflowRun
        fields = "__all__"


class AwxRunFilterSet(NautobotFilterSet):
    """FilterSet for AwxRun model."""

    q = SearchFilter(
        filter_predicates={
            "status": "icontains",
            "url": "icontains",
        },
    )

    class Meta:
        """Meta class for AwxRunFilterSet."""

        model = AwxRun
        fields = "__all__"


class WorkflowHelperFilterSet(NautobotFilterSet):
    """FilterSet for WorkflowHelper model."""

    q = SearchFilter(
        filter_predicates={
            "file_path": "icontains",
        },
    )

    class Meta:
        """Meta class for WorkflowHelperFilterSet."""

        model = WorkflowHelper
        fields = "__all__"


class WorkflowFilterModuleFilterSet(NautobotFilterSet):
    """FilterSet for WorkflowFilterModule model."""

    q = SearchFilter(
        filter_predicates={
            "file_path": "icontains",
        },
    )

    class Meta:
        """Meta class for WorkflowFilterModuleFilterSet."""

        model = WorkflowFilterModule
        fields = "__all__"
