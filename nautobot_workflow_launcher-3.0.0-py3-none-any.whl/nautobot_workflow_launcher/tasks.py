"""Celery tasks for AWX job monitoring and workflow execution."""

import logging
import time
import traceback

import requests
from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.mail import send_mail
from django.core.validators import validate_email
from django.utils import timezone
from nautobot.core.celery import app  # In RQ setups, adjust to RQ equivalent
from nautobot.extras.models import ExternalIntegration

from .executors import parse_awx_auth, run_pre_actions_for_scheduled_run
from .models import AwxRun, ProblemReport, WorkflowRun
from .scheduling import create_scheduled_job_for_run

PLUGIN_CFG = settings.PLUGINS_CONFIG.get("nautobot_workflow_launcher", {})
logger = logging.getLogger(__name__)


def _configured_problem_report_recipients():
    """Return validated, case-insensitively deduplicated support recipients and invalid entries."""
    configured = PLUGIN_CFG.get("problem_report_recipients", [])
    if isinstance(configured, str):
        configured = configured.split(",")

    valid = []
    invalid = []
    seen = set()
    for raw_address in configured or []:
        address = str(raw_address or "").strip()
        key = address.casefold()
        if not address or key in seen:
            continue
        seen.add(key)
        try:
            validate_email(address)
        except ValidationError:
            invalid.append(address)
        else:
            valid.append(address)
    return valid, invalid


def _delivery_error(exc):
    """Return a bounded delivery error suitable for admin-only diagnostics."""
    return f"{exc.__class__.__name__}: {exc}"[:1000]


def _problem_report_subject(report):
    """Return a single-line email subject safe from header injection."""
    summary = " ".join((report.summary or "").splitlines())[:120]
    return f"[Workflow Launcher problem {report.reference}] {summary}"


def _support_message(report):
    """Build the support email without logs, workflow inputs, artifacts, or browser metadata."""
    lines = [
        f"Reference: {report.reference}",
        f"Reporter: {report.reported_by.username}",
        f"Reporter email: {report.reported_by.email or '(not set)'}",
        f"Category: {report.get_category_display()}",
        f"Summary: {report.summary}",
        "",
        "What happened:",
        report.description,
    ]
    if report.expected_behavior:
        lines.extend(["", "Expected behavior:", report.expected_behavior])
    if report.steps_to_reproduce:
        lines.extend(["", "Steps to reproduce:", report.steps_to_reproduce])
    if report.workflow:
        lines.extend(["", f"Workflow: {report.workflow.name} ({report.workflow.key})"])
    if report.workflow_run_id:
        lines.append(f"Workflow run: {report.workflow_run_id}")
    if report.page_url:
        lines.append(f"Source page: {report.page_url}")
    lines.extend(
        [
            "",
            "Workflow logs, submitted inputs, artifacts, cookies, and browser metadata were not attached.",
        ]
    )
    return "\n".join(lines)


def _acknowledgment_message(report):
    """Build the reporter acknowledgment without internal delivery details."""
    return "\n".join(
        [
            f"Your Workflow Launcher problem report was received. Reference: {report.reference}",
            "",
            f"Category: {report.get_category_display()}",
            f"Summary: {report.summary}",
            "",
            "What happened:",
            report.description,
            "",
            "Keep this reference for follow-up with the support team.",
        ]
    )


@app.task
def send_problem_report_emails(report_id, recipient_filter=None):
    """Deliver support notifications separately and acknowledge the submitter."""
    report = ProblemReport.objects.select_related("reported_by", "workflow", "workflow_run").get(pk=report_id)
    from_email = settings.DEFAULT_FROM_EMAIL
    previous_results = {
        str(result.get("address", "")).casefold(): result
        for result in (report.support_delivery_results or [])
        if isinstance(result, dict) and result.get("address")
    }

    configured, invalid = _configured_problem_report_recipients()
    if previous_results:
        intended = [result["address"] for result in previous_results.values()]
        invalid = [
            result["address"]
            for result in previous_results.values()
            if result.get("status") == "failed" and result.get("error") == "Invalid email address."
        ]
    else:
        intended = configured + invalid

    requested = {str(address).casefold() for address in (recipient_filter or [])}
    results_by_address = dict(previous_results)
    subject = _problem_report_subject(report)
    body = _support_message(report)

    for address in intended:
        key = address.casefold()
        previous = results_by_address.get(key, {})
        if previous.get("status") == "sent":
            continue
        if requested and key not in requested:
            continue
        if address in invalid:
            results_by_address[key] = {
                "address": address,
                "status": "failed",
                "error": "Invalid email address.",
            }
            continue
        try:
            delivered = send_mail(subject, body, from_email, [address], fail_silently=False)
            if delivered != 1:
                raise RuntimeError("Email backend did not accept the support message.")
        except Exception as exc:  # noqa: BLE001
            results_by_address[key] = {"address": address, "status": "failed", "error": _delivery_error(exc)}
        else:
            results_by_address[key] = {"address": address, "status": "sent", "error": ""}

    results = list(results_by_address.values())
    sent_count = sum(result.get("status") == "sent" for result in results)
    failed_count = sum(result.get("status") == "failed" for result in results)
    if sent_count and not failed_count:
        support_status = "sent"
    elif sent_count:
        support_status = "partial"
    else:
        support_status = "failed"

    report.support_delivery_results = results
    report.support_delivery_status = support_status
    report.support_delivery_error = (
        "No valid support recipients are configured."
        if not results
        else "; ".join(result.get("error", "") for result in results if result.get("error"))[:1000]
    )
    report.support_delivered_at = timezone.now() if sent_count else None

    reporter_email = (report.reported_by.email or "").strip()
    if not reporter_email:
        report.acknowledgment_status = "skipped"
        report.acknowledgment_error = "The reporting user has no email address."
        report.acknowledgment_delivered_at = None
    elif report.acknowledgment_status != "sent":
        try:
            validate_email(reporter_email)
            delivered = send_mail(
                f"Problem report {report.reference} received",
                _acknowledgment_message(report),
                from_email,
                [reporter_email],
                fail_silently=False,
            )
            if delivered != 1:
                raise RuntimeError("Email backend did not accept the acknowledgment message.")
        except Exception as exc:  # noqa: BLE001
            report.acknowledgment_status = "failed"
            report.acknowledgment_error = _delivery_error(exc)
            report.acknowledgment_delivered_at = None
        else:
            report.acknowledgment_status = "sent"
            report.acknowledgment_error = ""
            report.acknowledgment_delivered_at = timezone.now()

    report.save(
        update_fields=[
            "support_delivery_results",
            "support_delivery_status",
            "support_delivery_error",
            "support_delivered_at",
            "acknowledgment_status",
            "acknowledgment_error",
            "acknowledgment_delivered_at",
            "updated_at",
        ]
    )


@app.task
def poll_awx_job(awx_run_pk: int):
    """Poll AWX job status until completion and update workflow run status."""
    poll_seconds = int(PLUGIN_CFG.get("awx_poll_seconds", 10))
    ar = AwxRun.objects.select_related("workflow_run").get(pk=awx_run_pk)
    integ = ExternalIntegration.objects.get(name=PLUGIN_CFG["awx_external_integration_name"])
    url = integ.remote_url.rstrip("/")
    verify = integ.verify_ssl
    username, password = parse_awx_auth(integ)

    while True:
        r = requests.get(f"{url}/api/v2/jobs/{ar.job_id}/", auth=(username, password), verify=verify, timeout=15)
        r.raise_for_status()
        payload = r.json()
        status = payload.get("status")
        ar.status = status
        ar.raw = payload
        ar.save(update_fields=["status", "raw"])

        if status in {"successful", "failed", "error", "canceled"}:
            rr = ar.workflow_run
            # Append to existing logs instead of overwriting
            rr.log += f"\nAWX polling task: job {ar.job_id} -> {status}"

            # Log artifacts info if present for debugging
            if status == "successful" and payload.get("artifacts"):
                rr.log += f"\nAWX job artifacts captured: {list(payload['artifacts'].keys())}"
            elif status == "successful":
                rr.log += "\nAWX job completed without artifacts"

            rr.save(update_fields=["log"])
            break
        time.sleep(poll_seconds)


@app.task(bind=True)
def execute_workflow_task(self, workflow_run_id):
    """Execute a complete workflow in the background."""
    from .executors import _run_workflow_synchronous

    try:
        workflow_run = WorkflowRun.objects.get(pk=workflow_run_id)
        # Status should already be 'running', but ensure it for safety
        if workflow_run.status not in ("running", "canceled"):
            workflow_run.status = "running"
            workflow_run.save(update_fields=["status"])

        if workflow_run.execution_started is None:
            workflow_run.execution_started = timezone.now()
            workflow_run.save(update_fields=["execution_started"])

        # Execute the workflow using the synchronous version
        _run_workflow_synchronous(workflow_run)

    except Exception as exc:
        try:
            from .executors import _append_run_output

            workflow_run = WorkflowRun.objects.get(pk=workflow_run_id)
            workflow_run.status = "failed"
            workflow_run.finished = timezone.now()
            workflow_run.save(update_fields=["status", "finished"])
            _append_run_output(workflow_run, log=f"\nTask execution failed: {exc}\n{traceback.format_exc()}")
        except Exception:  # noqa: S110
            # If we can't even update the workflow run, just let the task fail
            pass
        raise


@app.task(bind=True)
def prepare_scheduled_workflow_task(self, workflow_run_id):
    """Run pre-actions asynchronously, then create the delayed ScheduledJob for main execution."""
    try:
        workflow_run = WorkflowRun.objects.select_related("workflow", "requested_by").get(pk=workflow_run_id)

        if workflow_run.status == "canceled":
            return

        if workflow_run.status != "running":
            workflow_run.status = "running"
            workflow_run.save(update_fields=["status"])

        if not workflow_run.scheduled_for:
            raise RuntimeError("Scheduled execution requested, but no scheduled_for timestamp was set.")

        from .executors import _append_run_output

        _append_run_output(workflow_run, log="\nPreparing scheduled workflow: executing pre-actions...")

        run_pre_actions_for_scheduled_run(workflow_run)
        workflow_run.refresh_from_db()

        if workflow_run.status == "canceled":
            return
        create_scheduled_job_for_run(workflow_run)
        workflow_run.refresh_from_db(fields=["scheduled_job", "status"])
        _append_run_output(
            workflow_run,
            log=(
                "\nScheduled job created; execution planned for "
                f"{workflow_run.scheduled_for.strftime('%Y-%m-%d %H:%M:%S')} UTC"
            ),
        )

    except Exception as exc:
        logger.exception("prepare_scheduled_workflow_task failed for run %s", workflow_run_id)
        try:
            from .executors import _append_run_output

            workflow_run = WorkflowRun.objects.get(pk=workflow_run_id)
            if workflow_run.status != "canceled":
                workflow_run.status = "failed"
                workflow_run.finished = timezone.now()
                workflow_run.save(update_fields=["status", "finished"])
                _append_run_output(workflow_run, log=f"\nScheduling aborted: {exc}\n{traceback.format_exc()}")
        except Exception:  # noqa: S110
            pass
        raise
