"""Reporting channel handed to workflow scripts, plus structured-result normalization.

Scripts may declare either ``run(params)`` (legacy) or ``run(params, ctx)`` to gain
live progress reporting, structured results, and downloadable artifacts.
"""

from django.conf import settings

PLUGIN_CFG = settings.PLUGINS_CONFIG.get("nautobot_workflow_launcher", {})

DEFAULT_ARTIFACT_MAX_BYTES = 1024 * 1024
DEFAULT_ARTIFACT_RUN_MAX_BYTES = 10 * 1024 * 1024

STRUCTURED_RESULT_KEYS = ("summary", "links", "table", "metrics", "changed")

MAX_SUMMARY_CHARS = 4000
MAX_TABLE_ROWS = 500
MAX_TABLE_COLUMNS = 25
MAX_LINKS = 50
MAX_METRICS = 50


class ArtifactTooLargeError(ValueError):
    """Raised when a script writes an artifact exceeding the configured size cap."""


def _artifact_max_bytes():
    return int(PLUGIN_CFG.get("artifact_max_bytes", DEFAULT_ARTIFACT_MAX_BYTES))


def _artifact_run_max_bytes():
    return int(PLUGIN_CFG.get("artifact_run_max_bytes", DEFAULT_ARTIFACT_RUN_MAX_BYTES))


def is_safe_url(value):
    """Return True for relative paths and http(s) URLs, rejecting javascript:/data: and protocol-relative URLs."""
    if not isinstance(value, str):
        return False
    candidate = value.strip()
    if not candidate or candidate.startswith("//"):
        return False
    if candidate.startswith("/"):
        return True
    lowered = candidate.lower()
    return lowered.startswith("http://") or lowered.startswith("https://")


def safe_artifact_name(value):
    """Reduce a caller-supplied artifact name to a bare filename safe for a download header."""
    candidate = str(value or "").strip().replace("\\", "/")
    candidate = candidate.rsplit("/", 1)[-1]
    candidate = "".join(char for char in candidate if char.isprintable() and char not in '"\r\n')
    candidate = candidate.strip(". ")
    return candidate[:255]


def _clean_text(value, limit=500):
    if value is None:
        return ""
    return str(value)[:limit]


def _normalize_links(value):
    links = []
    if not isinstance(value, (list, tuple)):
        return links
    for item in value[:MAX_LINKS]:
        if isinstance(item, str):
            url, label = item, item
        elif isinstance(item, dict):
            url = item.get("url") or item.get("href") or ""
            label = item.get("label") or item.get("name") or url
        else:
            continue
        if not is_safe_url(url):
            continue
        links.append({"label": _clean_text(label, 200), "url": _clean_text(url, 2000)})
    return links


def _normalize_table(value):
    if not isinstance(value, dict):
        return None
    raw_columns = value.get("columns")
    raw_rows = value.get("rows")
    if not isinstance(raw_columns, (list, tuple)) or not isinstance(raw_rows, (list, tuple)):
        return None

    columns = [_clean_text(column, 120) for column in raw_columns[:MAX_TABLE_COLUMNS]]
    if not columns:
        return None

    rows = []
    for raw_row in raw_rows[:MAX_TABLE_ROWS]:
        if isinstance(raw_row, dict):
            cells = [_clean_text(raw_row.get(column), 500) for column in columns]
        elif isinstance(raw_row, (list, tuple)):
            cells = [_clean_text(cell, 500) for cell in raw_row[: len(columns)]]
            cells += [""] * (len(columns) - len(cells))
        else:
            continue
        rows.append(cells)

    return {
        "columns": columns,
        "rows": rows,
        "truncated": len(raw_rows) > MAX_TABLE_ROWS,
    }


def _normalize_metrics(value):
    metrics = []
    if isinstance(value, dict):
        items = list(value.items())[:MAX_METRICS]
        return [{"label": _clean_text(label, 120), "value": _clean_text(item, 120)} for label, item in items]
    if not isinstance(value, (list, tuple)):
        return metrics
    for item in value[:MAX_METRICS]:
        if not isinstance(item, dict):
            continue
        metrics.append(
            {
                "label": _clean_text(item.get("label") or item.get("name"), 120),
                "value": _clean_text(item.get("value"), 120),
            }
        )
    return metrics


def _normalize_changed(value):
    changed = []
    if not isinstance(value, (list, tuple)):
        return changed
    for item in value[:MAX_TABLE_ROWS]:
        if isinstance(item, str):
            changed.append({"label": _clean_text(item, 200), "url": ""})
        elif isinstance(item, dict):
            url = item.get("url") or ""
            changed.append(
                {
                    "label": _clean_text(item.get("label") or item.get("name") or url, 200),
                    "url": _clean_text(url, 2000) if is_safe_url(url) else "",
                }
            )
    return changed


def normalize_structured_result(value):
    """Coerce a script return value into the structured-result schema, or return None."""
    if not isinstance(value, dict):
        return None
    if not any(key in value for key in STRUCTURED_RESULT_KEYS):
        return None

    structured = {}
    if value.get("summary") is not None:
        structured["summary"] = _clean_text(value.get("summary"), MAX_SUMMARY_CHARS)

    links = _normalize_links(value.get("links"))
    if links:
        structured["links"] = links

    table = _normalize_table(value.get("table"))
    if table:
        structured["table"] = table

    metrics = _normalize_metrics(value.get("metrics"))
    if metrics:
        structured["metrics"] = metrics

    changed = _normalize_changed(value.get("changed"))
    if changed:
        structured["changed"] = changed

    return structured or None


class WorkflowContext:  # pylint: disable=too-many-instance-attributes
    """Live reporting channel for a single action's script execution."""

    def __init__(  # pylint: disable=too-many-arguments
        self, workflow_run, action_name, *, inputs=None, dry_run=False, on_progress=None, on_message=None
    ):
        """Initialize reporting state and optional progress callbacks for an action."""
        self.run = workflow_run
        self.action_name = action_name
        self.inputs = inputs if inputs is not None else (workflow_run.inputs or {})
        self.user = workflow_run.requested_by
        self.dry_run = dry_run
        self._on_progress = on_progress
        self._on_message = on_message
        self._structured = {}

    # -- progress ---------------------------------------------------------

    def progress(self, percent, message=None):
        """Report completion percentage (0-100) for the current action."""
        try:
            value = max(0, min(100, int(percent)))
        except (TypeError, ValueError):
            return
        if self._on_progress:
            self._on_progress(percent=value, message=_clean_text(message, 200) or None, step=None)

    def step(self, name):
        """Report a named sub-step of the current action."""
        if self._on_progress:
            self._on_progress(percent=None, message=None, step=_clean_text(name, 200))

    # -- messages ---------------------------------------------------------

    def _emit(self, prefix, message):
        line = f"{prefix}{message}"
        if self._on_message:
            self._on_message(line)
        else:
            print(line)

    def info(self, message):
        """Write an informational line to the run's user-facing output."""
        self._emit("INFO: ", message)

    def warn(self, message):
        """Write a warning line to the run's user-facing output."""
        self._emit("WARNING: ", message)

    def error(self, message):
        """Write an error line to the run's user-facing output."""
        self._emit("ERROR: ", message)

    # -- results ----------------------------------------------------------

    def result(self, **kwargs):
        """Merge structured result data (summary/links/table/metrics/changed) for this action."""
        unknown = set(kwargs) - set(STRUCTURED_RESULT_KEYS)
        if unknown:
            raise ValueError(
                f"Unknown structured result key(s): {', '.join(sorted(unknown))}. "
                f"Allowed: {', '.join(STRUCTURED_RESULT_KEYS)}"
            )
        self._structured.update(kwargs)

    def get_structured_result(self):
        """Return the normalized structured result accumulated via result()."""
        return normalize_structured_result(self._structured)

    # -- artifacts --------------------------------------------------------

    def artifact(self, name, content, content_type="text/plain"):
        """Attach a downloadable artifact to the run. Raises ArtifactTooLargeError if over the cap."""
        from .models import WorkflowRunArtifact

        safe_name = safe_artifact_name(name)
        if not safe_name:
            raise ValueError("Artifact name is required")

        if isinstance(content, bytes):
            payload = content
        else:
            payload = str(content).encode("utf-8")

        per_artifact_cap = _artifact_max_bytes()
        if len(payload) > per_artifact_cap:
            raise ArtifactTooLargeError(
                f"Artifact '{safe_name}' is {len(payload)} bytes, exceeding the {per_artifact_cap} byte limit."
            )

        existing_total = sum(WorkflowRunArtifact.objects.filter(workflow_run=self.run).values_list("size", flat=True))
        run_cap = _artifact_run_max_bytes()
        if existing_total + len(payload) > run_cap:
            raise ArtifactTooLargeError(
                f"Artifact '{safe_name}' would exceed the {run_cap} byte per-run artifact limit."
            )

        if content_type not in WorkflowRunArtifact.ALLOWED_CONTENT_TYPES:
            content_type = "application/octet-stream"

        artifact, _created = WorkflowRunArtifact.objects.update_or_create(
            workflow_run=self.run,
            name=safe_name,
            defaults={
                "action_name": self.action_name,
                "content_type": content_type,
                "size": len(payload),
                "data": payload,
            },
        )
        return artifact
