"""Workflow run progress serialization shared by the UI polling views and the REST API."""

from datetime import timezone as dt_timezone

from django.utils import timezone

from .models import WorkflowRun
from .ui_helpers import (
    LIVE_RUN_STATUSES,
    TERMINAL_RUN_STATUSES,
    awx_status_meta,
    build_run_steps,
    collect_structured_results,
    format_bytes,
    format_duration,
    run_status_meta,
)

TERMINAL_WORKFLOW_STATUSES = TERMINAL_RUN_STATUSES
TERMINAL_AWX_STATUSES = {"successful", "failed", "error", "canceled"}

# Fallback runtime estimate, in seconds, when a workflow has no completed runs yet.
DEFAULT_EXPECTED_RUNTIME_SECONDS = 600


def serialize_run_artifacts(workflow_run):
    """Serialize downloadable artifacts attached to a run."""
    return [
        {
            "pk": str(artifact.pk),
            "name": artifact.name,
            "action_name": artifact.action_name,
            "content_type": artifact.content_type,
            "size": artifact.size,
            "size_display": format_bytes(artifact.size),
            "url": artifact.get_absolute_url(),
        }
        for artifact in workflow_run.artifacts.all()
    ]


def estimate_expected_runtime_seconds(workflow_run):
    """Estimate expected runtime for progress tracking using historical durations."""
    workflow = workflow_run.workflow
    if not workflow:
        return DEFAULT_EXPECTED_RUNTIME_SECONDS

    sample_size = 20
    trim_ratio = 0.10

    recent_terminal_runs = (
        WorkflowRun.objects.filter(workflow=workflow, finished__isnull=False)
        .exclude(status="canceled")
        .exclude(started__isnull=True)
        .order_by("-finished")[:sample_size]
    )

    durations = []
    for run in recent_terminal_runs:
        started = run.effective_started
        if run.finished and started and run.finished >= started:
            durations.append(int((run.finished - started).total_seconds()))

    if durations:
        durations.sort()
        trim_count = int(len(durations) * trim_ratio)
        if (2 * trim_count) < len(durations):
            durations = durations[trim_count : len(durations) - trim_count]

        midpoint = len(durations) // 2
        if len(durations) % 2 == 1:
            median_seconds = durations[midpoint]
        else:
            median_seconds = int((durations[midpoint - 1] + durations[midpoint]) / 2)

        return max(60, median_seconds)

    return DEFAULT_EXPECTED_RUNTIME_SECONDS


def run_headline(workflow_run, exec_duration_seconds):
    """Return a one-line, human-readable summary of a run's state."""
    status = workflow_run.status
    duration_text = format_duration(exec_duration_seconds) if exec_duration_seconds is not None else ""
    if status == "running":
        return f"Running for {duration_text}" if duration_text else "Running"
    if status == "pending":
        return "Queued, waiting for a worker"
    if status == "scheduled":
        if workflow_run.scheduled_for:
            return f"Scheduled for {workflow_run.scheduled_for.astimezone(dt_timezone.utc):%b %d, %Y %H:%M} UTC"
        return "Scheduled"
    if status == "success":
        return f"Completed successfully in {duration_text}" if duration_text else "Completed successfully"
    if status == "failed":
        return f"Failed after {duration_text}" if duration_text else "Failed"
    if status == "partial":
        return f"Completed with errors in {duration_text}" if duration_text else "Completed with errors"
    if status == "canceled":
        return "Canceled before execution"
    return run_status_meta(status)["label"]


def step_progress_fraction(steps, awx_fraction=None):
    """Return (completed_units, total_units) where a running step contributes its reported sub-progress."""
    countable = [step for step in steps if step.get("status") != "not_run"]
    total = len(countable)
    if not total:
        return 0.0, 0

    completed = 0.0
    for step in countable:
        status = step.get("status")
        if status in ("success", "failed", "skipped"):
            completed += 1
        elif status == "running":
            reported = step.get("progress_percent")
            if isinstance(reported, int):
                completed += reported / 100
            elif awx_fraction is not None:
                completed += awx_fraction
            else:
                # A running step with no self-reported progress counts as half done.
                completed += 0.5

    return completed, total


def serialize_workflow_run_progress(workflow_run, include_logs=True):
    """Serialize a workflow run into a progress payload for polling clients."""
    meta = run_status_meta(workflow_run.status)
    status_badge = {
        "label": meta["label"],
        "tone": meta["tone"],
        "icon": meta["icon"],
        "live": workflow_run.status in LIVE_RUN_STATUSES,
    }

    started = workflow_run.effective_started
    if workflow_run.finished and started and workflow_run.finished >= started:
        exec_duration_seconds = int((workflow_run.finished - started).total_seconds())
        execution_duration_display = format_duration(exec_duration_seconds)
    elif workflow_run.status == "running":
        execution_duration_display = "Still running..."
        exec_duration_seconds = int((timezone.now() - started).total_seconds()) if started else 0
    else:
        execution_duration_display = "-"
        exec_duration_seconds = None

    awx_runs = []
    awx_completed = 0
    for awx_run in workflow_run.awx_runs.all().order_by("id"):
        if awx_run.status in TERMINAL_AWX_STATUSES:
            awx_completed += 1
        awx_meta = awx_status_meta(awx_run.status)
        awx_runs.append(
            {
                "template_id": awx_run.template_id,
                "job_id": awx_run.job_id,
                "url": awx_run.url,
                "status": awx_run.status,
                "tone": awx_meta["tone"],
                "icon": awx_meta["icon"],
            }
        )

    expected_runtime_seconds = estimate_expected_runtime_seconds(workflow_run)
    elapsed_seconds = max(0, int((timezone.now() - started).total_seconds())) if started else 0

    steps = build_run_steps(workflow_run)
    awx_fraction = (awx_completed / len(awx_runs)) if awx_runs else None

    progress_percent = 0
    progress_text = meta["label"]
    if workflow_run.status in TERMINAL_WORKFLOW_STATUSES:
        progress_percent = 100
    elif workflow_run.status == "scheduled":
        progress_percent = 5
        progress_text = "Scheduled"
    elif workflow_run.status == "pending":
        progress_percent = 10
        progress_text = "Queued"
    elif workflow_run.status == "running":
        completed_units, total_units = step_progress_fraction(steps, awx_fraction=awx_fraction)
        if total_units:
            progress_percent = int(round((completed_units / total_units) * 100))
            progress_text = f"Step {min(int(completed_units) + 1, total_units)} of {total_units}"
        else:
            progress_percent = 5
            progress_text = "Running"

        active = next((step for step in steps if step.get("status") == "running"), None)
        if active:
            detail = active.get("progress_message") or active.get("current_step") or active.get("name")
            if detail:
                progress_text = f"{progress_text} • {detail}"

        remaining = expected_runtime_seconds - elapsed_seconds
        if remaining > 30:
            progress_text = f"{progress_text} • ~{format_duration(remaining)} left"
    else:
        progress_percent = 15

    progress_percent = max(0, min(100, progress_percent))

    payload = {
        "pk": str(workflow_run.pk),
        "status": workflow_run.status,
        "status_label": meta["label"],
        "status_badge": status_badge,
        "headline": run_headline(workflow_run, exec_duration_seconds),
        "started": workflow_run.started.isoformat() if workflow_run.started else None,
        "execution_started": (workflow_run.execution_started.isoformat() if workflow_run.execution_started else None),
        "finished": workflow_run.finished.isoformat() if workflow_run.finished else None,
        "scheduled_for": workflow_run.scheduled_for.isoformat() if workflow_run.scheduled_for else None,
        "is_terminal": workflow_run.status in TERMINAL_WORKFLOW_STATUSES,
        "execution_duration_seconds": exec_duration_seconds,
        "execution_duration_display": execution_duration_display,
        "progress_percent": progress_percent,
        "progress_text": progress_text,
        "has_post_action_errors": bool(
            isinstance(workflow_run.phase_results, dict)
            and workflow_run.phase_results.get("post", {}).get("any_failed", False)
        ),
        "awx_runs": awx_runs,
        "steps": steps,
        "results": collect_structured_results(steps),
        "artifacts": serialize_run_artifacts(workflow_run),
    }
    if include_logs:
        payload["log"] = workflow_run.log or ""
        payload["user_log"] = workflow_run.user_log or ""
    return payload
