"""Tests for per-workflow user guides: repo sync validation, rendering and the guide view."""

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

from django.urls import reverse
from nautobot.apps.testing import TestCase

from nautobot_workflow_launcher.datasources import GUIDE_MAX_BYTES, _load_workflow_guide
from nautobot_workflow_launcher.models import Workflow
from nautobot_workflow_launcher.ui_helpers import render_workflow_guide


class LoadWorkflowGuideTestCase(unittest.TestCase):
    """Verify guide files are resolved safely from the repository."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()  # pylint: disable=consider-using-with
        self.addCleanup(self._tmp.cleanup)
        self.repo_path = Path(self._tmp.name)
        (self.repo_path / "userguides").mkdir()
        self.job_result = SimpleNamespace(log=MagicMock())

    def _write(self, relative_path, content):
        target = self.repo_path / relative_path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return target

    def test_returns_empty_when_guide_key_absent(self):
        self.assertEqual(_load_workflow_guide(self.repo_path, {"key": "wf"}, self.job_result), ("", "", ""))
        self.job_result.log.assert_not_called()

    def test_loads_markdown_guide(self):
        self._write("userguides/wf.md", "# Title")

        path, content, guide_format = _load_workflow_guide(
            self.repo_path, {"key": "wf", "guide": "userguides/wf.md"}, self.job_result
        )

        self.assertEqual((path, content, guide_format), ("userguides/wf.md", "# Title", "markdown"))

    def test_loads_text_guide(self):
        self._write("userguides/wf.txt", "plain steps")

        path, content, guide_format = _load_workflow_guide(
            self.repo_path, {"key": "wf", "guide": "userguides/wf.txt"}, self.job_result
        )

        self.assertEqual((path, content, guide_format), ("userguides/wf.txt", "plain steps", "text"))

    def test_strips_leading_slash(self):
        self._write("userguides/wf.md", "# Title")

        path, _content, _format = _load_workflow_guide(
            self.repo_path, {"key": "wf", "guide": "/userguides/wf.md"}, self.job_result
        )

        self.assertEqual(path, "userguides/wf.md")

    def test_rejects_disallowed_extension(self):
        self._write("userguides/wf.html", "<b>hi</b>")

        result = _load_workflow_guide(self.repo_path, {"key": "wf", "guide": "userguides/wf.html"}, self.job_result)

        self.assertEqual(result, ("", "", ""))
        self.assertIn("only", self.job_result.log.call_args.kwargs["message"])

    def test_rejects_path_escaping_the_repository(self):
        outside = Path(self._tmp.name).parent / "outside-guide.md"
        outside.write_text("secret", encoding="utf-8")
        self.addCleanup(outside.unlink)

        result = _load_workflow_guide(self.repo_path, {"key": "wf", "guide": "../outside-guide.md"}, self.job_result)

        self.assertEqual(result, ("", "", ""))
        self.assertIn("escapes the repository", self.job_result.log.call_args.kwargs["message"])

    def test_missing_file_is_a_warning_not_an_error(self):
        result = _load_workflow_guide(self.repo_path, {"key": "wf", "guide": "userguides/missing.md"}, self.job_result)

        self.assertEqual(result, ("", "", ""))
        self.assertIn("not found", self.job_result.log.call_args.kwargs["message"])

    def test_rejects_oversized_guide(self):
        self._write("userguides/wf.md", "x" * (GUIDE_MAX_BYTES + 1))

        result = _load_workflow_guide(self.repo_path, {"key": "wf", "guide": "userguides/wf.md"}, self.job_result)

        self.assertEqual(result, ("", "", ""))
        self.assertIn("exceeds", self.job_result.log.call_args.kwargs["message"])


class RenderWorkflowGuideTestCase(unittest.TestCase):
    """Verify guide content is rendered and sanitized for display."""

    @staticmethod
    def _workflow(content, guide_format="markdown"):
        return SimpleNamespace(guide_content=content, guide_format=guide_format)

    def test_returns_empty_string_without_content(self):
        self.assertEqual(render_workflow_guide(self._workflow("")), "")
        self.assertEqual(render_workflow_guide(self._workflow(None)), "")

    def test_renders_markdown(self):
        html = render_workflow_guide(self._workflow("# Heading\n\n- one\n- two"))

        self.assertIn("<h1>Heading</h1>", html)
        self.assertIn("<li>one</li>", html)

    def test_strips_unsafe_markup_from_markdown(self):
        html = render_workflow_guide(self._workflow('Hi <script>alert("xss")</script><img src=x onerror=alert(1)>'))

        self.assertNotIn("<script", html)
        self.assertNotIn("onerror", html)

    def test_escapes_plain_text_guides(self):
        html = render_workflow_guide(self._workflow("<script>alert(1)</script>", guide_format="text"))

        self.assertIn("wl-guide__text", html)
        self.assertNotIn("<script>", html)
        self.assertIn("&lt;script&gt;", html)


class WorkflowGuideViewTestCase(TestCase):
    """Verify the guide endpoint is permission-gated and only serves workflows that have a guide."""

    user_permissions = []

    def setUp(self):
        super().setUp()
        self.guided = Workflow.objects.create(
            key="guided-workflow",
            name="Guided Workflow",
            enabled=True,
            raw_definition={"key": "guided-workflow"},
            guide_path="userguides/guided.md",
            guide_content="## Steps\n\n1. Do the thing",
            guide_format="markdown",
        )
        self.plain = Workflow.objects.create(
            key="plain-workflow",
            name="Plain Workflow",
            enabled=True,
            raw_definition={"key": "plain-workflow"},
        )

    @staticmethod
    def _url(workflow):
        return reverse("plugins:nautobot_workflow_launcher:workflow_guide", kwargs={"key": workflow.key})

    def test_requires_view_permission(self):
        self.assertIn(self.client.get(self._url(self.guided)).status_code, (403, 302))

    def test_renders_guide_fragment(self):
        self.add_permissions("nautobot_workflow_launcher.view_workflow")

        response = self.client.get(self._url(self.guided))

        self.assertEqual(response.status_code, 200)
        content = response.content.decode()
        self.assertIn("<h2>Steps</h2>", content)
        self.assertIn("userguides/guided.md", content)

    def test_workflow_without_guide_returns_404(self):
        self.add_permissions("nautobot_workflow_launcher.view_workflow")

        self.assertEqual(self.client.get(self._url(self.plain)).status_code, 404)

    def test_unknown_workflow_returns_404(self):
        self.add_permissions("nautobot_workflow_launcher.view_workflow")
        url = reverse("plugins:nautobot_workflow_launcher:workflow_guide", kwargs={"key": "does-not-exist"})

        self.assertEqual(self.client.get(url).status_code, 404)

    def test_catalog_shows_the_trigger_only_for_workflows_with_a_guide(self):
        self.add_permissions("nautobot_workflow_launcher.view_workflow")

        content = self.client.get(reverse("plugins:nautobot_workflow_launcher:workflows_list")).content.decode()

        self.assertIn(self._url(self.guided), content)
        self.assertNotIn(self._url(self.plain), content)
