"""Tests for the two-step workflow launch confirmation flow."""

from unittest.mock import patch

from django.urls import reverse
from nautobot.apps.testing import TestCase

from nautobot_workflow_launcher.models import Workflow, WorkflowInput, WorkflowRun


class WorkflowConfirmationViewTestCase(TestCase):
    """A valid launch must be reviewed and explicitly confirmed before creating a run."""

    user_permissions = []

    def setUp(self):
        super().setUp()
        self.workflow = Workflow.objects.create(
            key="confirm-workflow",
            name="Confirm Workflow",
            category="Testing",
            enabled=True,
            raw_definition={"key": "confirm-workflow", "name": "Confirm Workflow"},
        )
        WorkflowInput.objects.create(
            workflow=self.workflow,
            key="hostname",
            label="Hostname",
            input_type="string",
            required=True,
            order=0,
        )
        self.add_permissions(
            "nautobot_workflow_launcher.view_workflow",
            "nautobot_workflow_launcher.add_workflowrun",
        )
        self.url = reverse(
            "plugins:nautobot_workflow_launcher:workflow_launch",
            kwargs={"key": self.workflow.key},
        )
        self.form_data = {
            "hostname": "edge-01",
            "execution_type": "immediate",
            "form_duration_seconds": "12",
            "browser_timezone_offset_minutes": "0",
            "browser_timezone_name": "UTC",
        }

    def _review(self):
        response = self.client.post(self.url, self.form_data)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "nautobot_workflow_launcher/workflow_confirm.html")
        return response

    def test_valid_post_renders_review_without_creating_run(self):
        response = self._review()

        self.assertEqual(WorkflowRun.objects.count(), 0)
        self.assertContains(response, "Requested changes")
        self.assertContains(response, "edge-01")
        self.assertContains(response, "Confirm and execute")
        self.assertTrue(response.context["confirmation_token"])

    @patch("nautobot_workflow_launcher.tasks.execute_workflow_task")
    def test_confirm_creates_and_dispatches_run(self, mock_task):
        token = self._review().context["confirmation_token"]

        response = self.client.post(
            self.url,
            {
                "confirmation_token": token,
                "confirmation_action": "confirm",
                "hostname": "tampered-after-review",
            },
        )

        self.assertEqual(response.status_code, 302)
        workflow_run = WorkflowRun.objects.get()
        self.assertEqual(workflow_run.inputs, {"hostname": "edge-01"})
        self.assertEqual(workflow_run.form_duration_seconds, 12)
        mock_task.delay.assert_called_once_with(workflow_run.pk)

    @patch("nautobot_workflow_launcher.tasks.execute_workflow_task")
    def test_confirmation_token_cannot_be_replayed(self, mock_task):
        token = self._review().context["confirmation_token"]
        payload = {"confirmation_token": token, "confirmation_action": "confirm"}

        first = self.client.post(self.url, payload)
        second = self.client.post(self.url, payload)

        self.assertEqual(first.status_code, 302)
        self.assertEqual(second.status_code, 302)
        self.assertEqual(WorkflowRun.objects.count(), 1)
        mock_task.delay.assert_called_once()

    def test_back_and_edit_restores_bound_values_without_launching(self):
        token = self._review().context["confirmation_token"]

        response = self.client.post(
            self.url,
            {"confirmation_token": token, "confirmation_action": "edit"},
        )

        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "nautobot_workflow_launcher/workflow_launch.html")
        self.assertEqual(response.context["form"].data["hostname"], "edge-01")
        self.assertEqual(WorkflowRun.objects.count(), 0)

    def test_unknown_token_returns_to_launch_form(self):
        response = self.client.post(
            self.url,
            {"confirmation_token": "not-valid", "confirmation_action": "confirm"},
        )

        self.assertRedirects(response, self.url, fetch_redirect_response=False)
        self.assertEqual(WorkflowRun.objects.count(), 0)

    def test_expired_token_returns_to_launch_form(self):
        token = self._review().context["confirmation_token"]
        session = self.client.session
        pending = session["workflow_launcher_pending_confirmations"]
        pending[token]["created"] = 0
        session["workflow_launcher_pending_confirmations"] = pending
        session.save()

        response = self.client.post(
            self.url,
            {"confirmation_token": token, "confirmation_action": "confirm"},
        )

        self.assertRedirects(response, self.url, fetch_redirect_response=False)
        self.assertEqual(WorkflowRun.objects.count(), 0)

    def test_launch_button_describes_review_step(self):
        response = self.client.get(self.url)

        self.assertContains(response, "Review changes")
        self.assertNotContains(response, ">Launch now<")
