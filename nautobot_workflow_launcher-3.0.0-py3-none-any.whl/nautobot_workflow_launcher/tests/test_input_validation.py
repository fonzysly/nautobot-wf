"""Unit tests for schema-driven workflow input validation."""

import unittest
from types import SimpleNamespace

from nautobot_workflow_launcher.input_validation import (
    WorkflowInputValidationError,
    build_input_schema,
    input_is_visible,
    validate_workflow_inputs,
)


class _FakeInputs:
    def __init__(self, items):
        self._items = list(items)

    def all(self):
        return list(self._items)


def _workflow_input(**overrides):
    defaults = {
        "pk": "00000000-0000-0000-0000-000000000000",
        "key": "hostname",
        "label": "Hostname",
        "input_type": "string",
        "required": False,
        "default": None,
        "depends_on": [],
        "visible_when": None,
        "validators": None,
        "content_type": None,
        "columns": None,
        "choices": None,
        "order": 0,
    }
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _workflow(*inputs):
    return SimpleNamespace(inputs=_FakeInputs(inputs))


class ValidateWorkflowInputsTest(unittest.TestCase):
    """Type coercion, required enforcement, and choice/regex validation."""

    def test_scalar_types_are_coerced(self):
        workflow = _workflow(
            _workflow_input(key="name", input_type="string"),
            _workflow_input(key="count", input_type="integer"),
            _workflow_input(key="enabled", input_type="boolean"),
        )

        cleaned = validate_workflow_inputs(workflow, {"name": "sw1", "count": "42", "enabled": "true"})

        self.assertEqual(cleaned["name"], "sw1")
        self.assertEqual(cleaned["count"], 42)
        self.assertIs(cleaned["enabled"], True)

    def test_required_field_is_enforced(self):
        workflow = _workflow(_workflow_input(key="name", required=True))

        with self.assertRaises(WorkflowInputValidationError) as ctx:
            validate_workflow_inputs(workflow, {})

        self.assertIn("name", ctx.exception.errors)

    def test_required_field_satisfied_by_default(self):
        workflow = _workflow(_workflow_input(key="name", required=True, default="fallback"))

        cleaned = validate_workflow_inputs(workflow, {})

        self.assertEqual(cleaned["name"], "fallback")

    def test_non_integer_value_is_rejected(self):
        workflow = _workflow(_workflow_input(key="count", input_type="integer"))

        with self.assertRaises(WorkflowInputValidationError) as ctx:
            validate_workflow_inputs(workflow, {"count": "not-a-number"})

        self.assertIn("count", ctx.exception.errors)

    def test_choice_membership_is_validated(self):
        workflow = _workflow(
            _workflow_input(
                key="env",
                input_type="choice",
                choices=[{"value": "prod", "label": "Prod"}, {"value": "dev", "label": "Dev"}],
            )
        )

        cleaned = validate_workflow_inputs(workflow, {"env": "prod"})
        self.assertEqual(cleaned["env"], "prod")

        with self.assertRaises(WorkflowInputValidationError) as ctx:
            validate_workflow_inputs(workflow, {"env": "staging"})
        self.assertIn("env", ctx.exception.errors)

    def test_jinja_choices_skip_static_validation(self):
        workflow = _workflow(
            _workflow_input(key="env", input_type="choice", choices=[{"value": "{{ inputs.site }}", "label": "Site"}])
        )

        cleaned = validate_workflow_inputs(workflow, {"env": "anything"})

        self.assertEqual(cleaned["env"], "anything")

    def test_multichoice_accepts_native_list(self):
        workflow = _workflow(
            _workflow_input(
                key="tags",
                input_type="multichoice",
                choices=[{"value": "a", "label": "A"}, {"value": "b", "label": "B"}],
            )
        )

        cleaned = validate_workflow_inputs(workflow, {"tags": ["a", "b"]})

        self.assertEqual(cleaned["tags"], ["a", "b"])

    def test_regex_validator_is_applied(self):
        workflow = _workflow(
            _workflow_input(
                key="name",
                validators=[{"regex": r"^[a-z]+$", "message": "Lowercase letters only."}],
            )
        )

        with self.assertRaises(WorkflowInputValidationError) as ctx:
            validate_workflow_inputs(workflow, {"name": "SW1"})

        self.assertEqual(ctx.exception.errors["name"], ["Lowercase letters only."])

    def test_unknown_keys_are_rejected(self):
        workflow = _workflow(_workflow_input(key="name"))

        with self.assertRaises(WorkflowInputValidationError) as ctx:
            validate_workflow_inputs(workflow, {"name": "sw1", "bogus": 1})

        self.assertIn("inputs", ctx.exception.errors)

    def test_hidden_input_is_nulled_and_not_required(self):
        workflow = _workflow(
            _workflow_input(key="request_type", input_type="choice"),
            _workflow_input(key="device", required=True, visible_when={"request_type": "permanent"}),
        )

        cleaned = validate_workflow_inputs(workflow, {"request_type": "decommission"})

        self.assertIsNone(cleaned["device"])

    def test_listdict_validators_surface_row_errors(self):
        workflow = _workflow(
            _workflow_input(
                key="students",
                input_type="listdict",
                columns=[
                    {"key": "name", "label": "Name", "type": "string", "required": True, "unique": True},
                    {"key": "age", "label": "Age", "type": "integer", "required": True},
                ],
            )
        )

        with self.assertRaises(WorkflowInputValidationError) as ctx:
            validate_workflow_inputs(
                workflow,
                {"students": [{"name": "Ada", "age": 36}, {"name": "Ada", "age": "abc"}]},
            )

        messages = " ".join(ctx.exception.errors["students"])
        self.assertIn("must be unique", messages)
        self.assertIn("must be a number", messages)

    def test_non_dict_payload_is_rejected(self):
        workflow = _workflow(_workflow_input(key="name"))

        with self.assertRaises(WorkflowInputValidationError):
            validate_workflow_inputs(workflow, ["not", "a", "dict"])


class InputVisibilityTest(unittest.TestCase):
    """Progressive-disclosure rules shared with the UI form."""

    def test_depends_on_requires_a_value(self):
        workflow_input = _workflow_input(key="device", depends_on=["site"])

        self.assertFalse(input_is_visible(workflow_input, {"site": None}))
        self.assertTrue(input_is_visible(workflow_input, {"site": "abc"}))

    def test_visible_when_accepts_list_of_values(self):
        workflow_input = _workflow_input(key="device", visible_when={"request_type": ["permanent", "move"]})

        self.assertTrue(input_is_visible(workflow_input, {"request_type": "move"}))
        self.assertFalse(input_is_visible(workflow_input, {"request_type": "decommission"}))

    def test_visible_when_handles_booleans(self):
        workflow_input = _workflow_input(key="detail", visible_when={"advanced": True})

        self.assertTrue(input_is_visible(workflow_input, {"advanced": True}))
        self.assertFalse(input_is_visible(workflow_input, {"advanced": False}))


class BuildInputSchemaTest(unittest.TestCase):
    """Discovery payload used by API clients."""

    def test_schema_exposes_input_contract(self):
        workflow = _workflow(
            _workflow_input(key="name", label="Name", required=True),
            _workflow_input(
                key="device",
                input_type="object",
                content_type=SimpleNamespace(app_label="dcim", model="device"),
            ),
        )

        schema = build_input_schema(workflow)

        self.assertEqual([entry["key"] for entry in schema], ["name", "device"])
        self.assertTrue(schema[0]["required"])
        self.assertEqual(schema[1]["content_type"], "dcim.device")


if __name__ == "__main__":
    unittest.main()
