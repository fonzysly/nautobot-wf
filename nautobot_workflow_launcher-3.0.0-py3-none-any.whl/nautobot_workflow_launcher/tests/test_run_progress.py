"""Tests for live run feedback: per-step state, step-derived progress, and partial status."""

# pylint: disable=protected-access

import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from nautobot_workflow_launcher import executors, run_progress, ui_helpers


def _fake_action(name, action_type="nautobot", when=""):
    return SimpleNamespace(name=name, action_type=action_type, when=when, phase="main", order=0)


def _fake_run(actions):
    class FakeQuerySet(list):
        def order_by(self, *_args):
            return self

    query_set = FakeQuerySet(actions)
    return SimpleNamespace(
        pk="00000000-0000-0000-0000-000000000001",
        workflow=SimpleNamespace(source_repo=None, actions=SimpleNamespace(filter=MagicMock(return_value=query_set))),
        log="",
        user_log="",
        phase_results={},
        inputs={},
        requested_by=SimpleNamespace(username="testuser"),
        save=MagicMock(),
    )


def _always_true_env():
    return SimpleNamespace(from_string=lambda _value: SimpleNamespace(render=lambda _ctx: "true"))


class LiveStepStateTestCase(unittest.TestCase):
    """The pipeline must be populated before and during the phase, not only after it finishes."""

    def test_steps_are_seeded_as_pending_before_any_action_runs(self):
        workflow_run = _fake_run([_fake_action("first"), _fake_action("second")])
        snapshots = []

        def _capture(_run, _phase, results, **_kwargs):
            snapshots.append({name: dict(value) for name, value in results.items()})

        with (
            patch.object(executors, "get_jinja_environment", return_value=_always_true_env()),
            patch.object(executors, "_append_run_output"),
            patch.object(executors, "_write_phase_state", side_effect=_capture),
            patch.object(executors, "_run_action_with_context", return_value={"status": "success", "return_value": 1}),
        ):
            executors._execute_phase_actions(workflow_run, {"results": {}, "last": {}}, phase="main")

        self.assertEqual(
            snapshots[0],
            {
                "first": {"status": "pending", "return_value": None},
                "second": {"status": "pending", "return_value": None},
            },
        )

    def test_action_is_marked_running_before_it_is_executed(self):
        workflow_run = _fake_run([_fake_action("only")])
        seen_during_execution = {}

        def _execute(*_args, **_kwargs):
            seen_during_execution.update(workflow_run.phase_results)
            return {"status": "success", "return_value": None}

        def _capture(run, phase, results, **_kwargs):
            run.phase_results = {phase: {"results": {k: dict(v) for k, v in results.items()}}}

        with (
            patch.object(executors, "get_jinja_environment", return_value=_always_true_env()),
            patch.object(executors, "_append_run_output"),
            patch.object(executors, "_write_phase_state", side_effect=_capture),
            patch.object(executors, "_run_action_with_context", side_effect=_execute),
        ):
            executors._execute_phase_actions(workflow_run, {"results": {}, "last": {}}, phase="main")

        self.assertEqual(seen_during_execution["main"]["results"]["only"]["status"], "running")

    def test_completed_action_records_timing(self):
        workflow_run = _fake_run([_fake_action("only")])

        with (
            patch.object(executors, "get_jinja_environment", return_value=_always_true_env()),
            patch.object(executors, "_append_run_output"),
            patch.object(executors, "_write_phase_state"),
            patch.object(executors, "_run_action_with_context", return_value={"status": "success"}),
        ):
            summary = executors._execute_phase_actions(workflow_run, {"results": {}, "last": {}}, phase="main")

        result = summary["results"]["only"]
        self.assertIn("started_at", result)
        self.assertIn("finished_at", result)
        self.assertIsInstance(result["duration_seconds"], int)

    def test_mixed_outcomes_report_both_flags(self):
        workflow_run = _fake_run([_fake_action("good"), _fake_action("bad")])
        results = iter([{"status": "success"}, {"status": "failed", "error": "boom"}])

        with (
            patch.object(executors, "get_jinja_environment", return_value=_always_true_env()),
            patch.object(executors, "_append_run_output"),
            patch.object(executors, "_write_phase_state"),
            patch.object(executors, "_run_action_with_context", side_effect=lambda *a, **k: next(results)),
        ):
            summary = executors._execute_phase_actions(workflow_run, {"results": {}, "last": {}}, phase="main")

        self.assertTrue(summary["any_failed"])
        self.assertTrue(summary["any_succeeded"])


class StepProgressTestCase(unittest.TestCase):
    """Progress must track real step completion rather than elapsed time."""

    def test_progress_counts_completed_steps(self):
        steps = [{"status": "success"}, {"status": "success"}, {"status": "pending"}, {"status": "pending"}]

        completed, total = run_progress.step_progress_fraction(steps)

        self.assertEqual(total, 4)
        self.assertEqual(completed, 2)

    def test_running_step_uses_script_reported_progress(self):
        steps = [{"status": "success"}, {"status": "running", "progress_percent": 40}]

        completed, total = run_progress.step_progress_fraction(steps)

        self.assertEqual(total, 2)
        self.assertAlmostEqual(completed, 1.4)

    def test_running_step_without_report_counts_as_half(self):
        steps = [{"status": "running"}]

        completed, _total = run_progress.step_progress_fraction(steps)

        self.assertAlmostEqual(completed, 0.5)

    def test_skipped_steps_count_as_complete_and_not_run_is_ignored(self):
        steps = [{"status": "skipped"}, {"status": "success"}, {"status": "not_run"}]

        completed, total = run_progress.step_progress_fraction(steps)

        self.assertEqual(total, 2)
        self.assertEqual(completed, 2)

    def test_awx_fraction_is_used_when_the_script_reports_nothing(self):
        steps = [{"status": "running"}]

        completed, _total = run_progress.step_progress_fraction(steps, awx_fraction=0.25)

        self.assertAlmostEqual(completed, 0.25)


class StepPayloadTestCase(unittest.TestCase):
    """The pipeline payload must carry timing, live progress and full error text."""

    def test_make_step_exposes_progress_duration_and_full_error(self):
        long_error = "x" * (ui_helpers.STEP_ERROR_MAX_LENGTH + 50)
        result = {
            "status": "failed",
            "error": long_error,
            "duration_seconds": 75,
            "progress_percent": 60,
            "progress_message": "halfway",
            "current_step": "phase two",
            "return_value": {"ok": False},
        }

        step = ui_helpers._make_step("main", "act", None, result)

        self.assertEqual(step["error"], long_error)
        self.assertTrue(step["error_summary"].endswith("\u2026"))
        self.assertEqual(step["duration_display"], "1m 15s")
        self.assertEqual(step["progress_percent"], 60)
        self.assertEqual(step["progress_message"], "halfway")
        self.assertEqual(step["current_step"], "phase two")
        self.assertEqual(step["return_value"], {"ok": False})

    def test_collect_structured_results_keeps_only_reporting_steps(self):
        steps = [
            {"name": "a", "phase": "main", "phase_label": "Main", "tone": "success", "structured": {"summary": "hi"}},
            {"name": "b", "phase": "main", "phase_label": "Main", "tone": "neutral", "structured": None},
        ]

        collected = ui_helpers.collect_structured_results(steps)

        self.assertEqual(len(collected), 1)
        self.assertEqual(collected[0]["name"], "a")


class PartialStatusTestCase(unittest.TestCase):
    """Partial is a real outcome, distinct from a flat failure."""

    def _run_with(self, main_summary):
        workflow_run = SimpleNamespace(
            pk="00000000-0000-0000-0000-000000000002",
            workflow=SimpleNamespace(name="wf", key="wf", enabled=True, source_repo=None),
            inputs={},
            status="running",
            execution_started=None,
            log="",
            user_log="",
            phase_results={},
            requested_by=SimpleNamespace(username="testuser"),
            save=MagicMock(),
        )
        empty = {"any_failed": False, "any_succeeded": True, "results": {}}
        summaries = iter([main_summary, empty])

        with (
            patch.object(executors, "_should_show_workflow", return_value=True),
            patch.object(executors, "_build_enhanced_inputs_context", return_value={}),
            patch.object(executors, "_append_run_output"),
            patch.object(executors, "_write_phase_state"),
            patch.object(executors, "_get_phase_results", return_value={"pre": {"executed": True}}),
            patch.object(executors, "_execute_phase_actions", side_effect=lambda *a, **k: next(summaries)),
        ):
            executors._run_workflow_synchronous(workflow_run)

        return workflow_run.status

    def test_mixed_main_phase_is_partial(self):
        status = self._run_with({"any_failed": True, "any_succeeded": True, "results": {}})

        self.assertEqual(status, "partial")

    def test_total_main_failure_is_failed(self):
        status = self._run_with({"any_failed": True, "any_succeeded": False, "results": {}})

        self.assertEqual(status, "failed")

    def test_clean_main_phase_is_success(self):
        status = self._run_with({"any_failed": False, "any_succeeded": True, "results": {}})

        self.assertEqual(status, "success")
