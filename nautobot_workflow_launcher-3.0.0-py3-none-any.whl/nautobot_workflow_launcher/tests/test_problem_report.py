"""Tests for authenticated problem reporting and email delivery."""

from unittest.mock import patch

from django.urls import reverse
from nautobot.apps.testing import TestCase

from nautobot_workflow_launcher import tasks
from nautobot_workflow_launcher.models import ProblemReport, Workflow, WorkflowRun


class ProblemReportViewTestCase(TestCase):
    """Problem-report context must be permission-scoped and safe to persist."""

    user_permissions = []

    def setUp(self):
        super().setUp()
        self.workflow = Workflow.objects.create(
            key="problem-workflow",
            name="Problem Workflow",
            enabled=True,
            raw_definition={"key": "problem-workflow"},
        )
        self.workflow_run = WorkflowRun.objects.create(
            workflow=self.workflow,
            requested_by=self.user,
            inputs={"secret": "must-not-be-attached"},
            status="failed",
            log="sensitive debug log",
        )
        self.url = reverse("plugins:nautobot_workflow_launcher:report_problem")
        self.form_data = {
            "category": "execution",
            "summary": "Interface workflow failed",
            "description": "The workflow stopped while creating an interface.",
            "expected_behavior": "The interface should be created.",
            "steps_to_reproduce": "Open the workflow and submit valid inputs.",
        }

    def test_login_is_required(self):
        self.client.logout()

        response = self.client.get(self.url)

        self.assertEqual(response.status_code, 302)
        self.assertIn("login", response.url)

    @patch("nautobot_workflow_launcher.tasks.send_problem_report_emails.delay")
    def test_report_is_persisted_with_authorized_run_context(self, mock_delay):
        self.add_permissions(
            "nautobot_workflow_launcher.view_workflow",
            "nautobot_workflow_launcher.view_workflowrun",
        )
        payload = {
            **self.form_data,
            "workflow_run_context": str(self.workflow_run.pk),
            "context_page": self.workflow_run.get_absolute_url(),
        }

        response = self.client.post(self.url, payload, HTTP_USER_AGENT="Browser/1.0")

        self.assertEqual(response.status_code, 302)
        report = ProblemReport.objects.get()
        self.assertEqual(report.reported_by, self.user)
        self.assertEqual(report.workflow_run, self.workflow_run)
        self.assertEqual(report.workflow, self.workflow)
        self.assertEqual(report.page_url, self.workflow_run.get_absolute_url())
        self.assertEqual(report.user_agent, "Browser/1.0")
        mock_delay.assert_called_once_with(str(report.pk))

    @patch("nautobot_workflow_launcher.tasks.send_problem_report_emails.delay")
    def test_unauthorized_context_is_not_selectable_or_persisted(self, mock_delay):
        get_response = self.client.get(f"{self.url}?run={self.workflow_run.pk}&workflow={self.workflow.key}")

        self.assertIsNone(get_response.context["form"].initial.get("workflow_run_context"))
        self.assertIsNone(get_response.context["form"].initial.get("workflow_context"))
        self.assertFalse(
            get_response.context["form"]
            .fields["workflow_run_context"]
            .queryset.filter(pk=self.workflow_run.pk)
            .exists()
        )

        response = self.client.post(self.url, self.form_data)

        self.assertEqual(response.status_code, 302)
        report = ProblemReport.objects.get()
        self.assertIsNone(report.workflow_run)
        self.assertIsNone(report.workflow)
        mock_delay.assert_called_once()

    @patch("nautobot_workflow_launcher.tasks.send_problem_report_emails.delay")
    def test_selecting_workflow_without_run_persists_workflow_context(self, mock_delay):
        self.add_permissions("nautobot_workflow_launcher.view_workflow")

        response = self.client.post(
            self.url,
            {**self.form_data, "workflow_context": str(self.workflow.pk)},
        )

        self.assertEqual(response.status_code, 302)
        report = ProblemReport.objects.get()
        self.assertEqual(report.workflow, self.workflow)
        self.assertIsNone(report.workflow_run)
        mock_delay.assert_called_once()

    @patch("nautobot_workflow_launcher.tasks.send_problem_report_emails.delay")
    def test_external_page_is_not_stored_or_used_for_redirect(self, mock_delay):
        response = self.client.post(
            self.url,
            {**self.form_data, "context_page": "https://evil.example/collect"},
        )

        self.assertRedirects(
            response,
            reverse("plugins:nautobot_workflow_launcher:workflows_list"),
            fetch_redirect_response=False,
        )
        self.assertEqual(ProblemReport.objects.get().page_url, "")
        mock_delay.assert_called_once()

    @patch("nautobot_workflow_launcher.tasks.send_problem_report_emails.delay")
    def test_user_agent_is_sanitized_and_capped(self, _mock_delay):
        raw_user_agent = "Browser\x00\n" + ("x" * 600)

        self.client.post(self.url, self.form_data, HTTP_USER_AGENT=raw_user_agent)

        stored = ProblemReport.objects.get().user_agent
        self.assertEqual(len(stored), 500)
        self.assertNotIn("\x00", stored)
        self.assertNotIn("\n", stored)

    @patch("nautobot_workflow_launcher.tasks.send_problem_report_emails.delay")
    def test_eleventh_report_within_an_hour_is_rejected(self, mock_delay):
        for index in range(10):
            ProblemReport.objects.create(
                reported_by=self.user,
                category="other",
                summary=f"Existing report {index}",
                description="Existing",
            )

        response = self.client.post(self.url, self.form_data)

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Please wait before trying again")
        self.assertEqual(ProblemReport.objects.count(), 10)
        mock_delay.assert_not_called()

    @patch("nautobot_workflow_launcher.tasks.send_problem_report_emails.delay")
    def test_missing_user_email_skips_acknowledgment(self, mock_delay):
        self.add_permissions("nautobot_workflow_launcher.view_workflow")
        self.user.email = ""
        self.user.save(update_fields=["email"])

        response = self.client.post(self.url, self.form_data, follow=True)

        report = ProblemReport.objects.get()
        self.assertEqual(report.acknowledgment_status, "skipped")
        self.assertContains(response, "acknowledgment email could not be sent")
        mock_delay.assert_called_once()

    def test_template_warns_that_sensitive_context_is_not_attached(self):
        response = self.client.get(self.url)

        self.assertContains(response, "Workflow logs and submitted inputs are not automatically attached")
        self.assertContains(response, "Do not enter passwords, tokens, secrets")


class ProblemReportEmailTaskTestCase(TestCase):
    """Support recipients receive separate messages and independent outcomes."""

    user_permissions = []

    def setUp(self):
        super().setUp()
        self.user.email = "reporter@example.com"
        self.user.save(update_fields=["email"])
        self.workflow = Workflow.objects.create(
            key="email-workflow",
            name="Email Workflow",
            enabled=True,
            raw_definition={"key": "email-workflow"},
        )
        self.workflow_run = WorkflowRun.objects.create(
            workflow=self.workflow,
            requested_by=self.user,
            inputs={"token": "secret-input"},
            status="failed",
            log="secret-log",
        )
        self.report = ProblemReport.objects.create(
            reported_by=self.user,
            workflow=self.workflow,
            workflow_run=self.workflow_run,
            category="execution",
            summary="Execution stopped",
            description="The visible error was generic.",
        )

    @patch("nautobot_workflow_launcher.tasks.send_mail")
    def test_recipients_are_deduplicated_and_sent_separately(self, mock_send):
        mock_send.return_value = 1
        with patch.dict(
            tasks.PLUGIN_CFG,
            {"problem_report_recipients": ["one@example.com", " ONE@example.com ", "two@example.com"]},
            clear=False,
        ):
            tasks.send_problem_report_emails.run(str(self.report.pk))

        self.report.refresh_from_db()
        support_calls = [call for call in mock_send.call_args_list if call.args[3] != ["reporter@example.com"]]
        self.assertEqual([call.args[3] for call in support_calls], [["one@example.com"], ["two@example.com"]])
        self.assertEqual(self.report.support_delivery_status, "sent")
        self.assertEqual(self.report.acknowledgment_status, "sent")
        for call in support_calls:
            self.assertNotIn("two@example.com", call.args[1] if call.args[3] == ["one@example.com"] else "")
            self.assertNotIn("secret-log", call.args[1])
            self.assertNotIn("secret-input", call.args[1])

    @patch("nautobot_workflow_launcher.tasks.send_mail")
    def test_one_recipient_failure_is_partial_and_does_not_block_acknowledgment(self, mock_send):
        def deliver(_subject, _body, _from_email, recipients, **_kwargs):
            if recipients == ["broken@example.com"]:
                raise RuntimeError("mailbox unavailable")
            return 1

        mock_send.side_effect = deliver
        with patch.dict(
            tasks.PLUGIN_CFG,
            {"problem_report_recipients": ["ok@example.com", "broken@example.com"]},
            clear=False,
        ):
            tasks.send_problem_report_emails.run(str(self.report.pk))

        self.report.refresh_from_db()
        self.assertEqual(self.report.support_delivery_status, "partial")
        self.assertEqual(self.report.acknowledgment_status, "sent")
        outcomes = {result["address"]: result["status"] for result in self.report.support_delivery_results}
        self.assertEqual(outcomes, {"ok@example.com": "sent", "broken@example.com": "failed"})

    @patch("nautobot_workflow_launcher.tasks.send_mail")
    def test_missing_support_configuration_does_not_block_acknowledgment(self, mock_send):
        mock_send.return_value = 1
        with patch.dict(tasks.PLUGIN_CFG, {"problem_report_recipients": []}, clear=False):
            tasks.send_problem_report_emails.run(str(self.report.pk))

        self.report.refresh_from_db()
        self.assertEqual(self.report.support_delivery_status, "failed")
        self.assertEqual(self.report.acknowledgment_status, "sent")
        self.assertEqual(mock_send.call_count, 1)
        self.assertEqual(mock_send.call_args.args[3], ["reporter@example.com"])

    @patch("nautobot_workflow_launcher.tasks.send_mail")
    def test_missing_reporter_email_marks_acknowledgment_skipped(self, mock_send):
        self.user.email = ""
        self.user.save(update_fields=["email"])
        mock_send.return_value = 1
        with patch.dict(tasks.PLUGIN_CFG, {"problem_report_recipients": ["support@example.com"]}, clear=False):
            tasks.send_problem_report_emails.run(str(self.report.pk))

        self.report.refresh_from_db()
        self.assertEqual(self.report.support_delivery_status, "sent")
        self.assertEqual(self.report.acknowledgment_status, "skipped")
        self.assertEqual(mock_send.call_count, 1)

    @patch("nautobot_workflow_launcher.tasks.send_mail")
    def test_retry_sends_only_to_failed_recipient(self, mock_send):
        def first_attempt(_subject, _body, _from_email, recipients, **_kwargs):
            if recipients == ["broken@example.com"]:
                raise RuntimeError("mailbox unavailable")
            return 1

        mock_send.side_effect = first_attempt
        with patch.dict(
            tasks.PLUGIN_CFG,
            {"problem_report_recipients": ["ok@example.com", "broken@example.com"]},
            clear=False,
        ):
            tasks.send_problem_report_emails.run(str(self.report.pk))

        mock_send.reset_mock()
        mock_send.side_effect = None
        mock_send.return_value = 1
        tasks.send_problem_report_emails.run(str(self.report.pk), ["broken@example.com"])

        self.report.refresh_from_db()
        self.assertEqual(mock_send.call_count, 1)
        self.assertEqual(mock_send.call_args.args[3], ["broken@example.com"])
        self.assertEqual(self.report.support_delivery_status, "sent")

    @patch("nautobot_workflow_launcher.tasks.send_mail", return_value=0)
    def test_backend_accepting_no_messages_marks_delivery_failed(self, mock_send):
        with patch.dict(tasks.PLUGIN_CFG, {"problem_report_recipients": ["support@example.com"]}, clear=False):
            tasks.send_problem_report_emails.run(str(self.report.pk))

        self.report.refresh_from_db()
        self.assertEqual(self.report.support_delivery_status, "failed")
        self.assertEqual(self.report.acknowledgment_status, "failed")
        self.assertEqual(mock_send.call_count, 2)
