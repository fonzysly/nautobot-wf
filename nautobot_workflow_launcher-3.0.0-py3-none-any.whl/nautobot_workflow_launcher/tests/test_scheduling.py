"""Focused tests for scheduled-run cancellation authorization."""

import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock

from nautobot_workflow_launcher.scheduling import user_can_cancel_run


class UserCanCancelRunTestCase(unittest.TestCase):
    """Run owners may cancel their own schedules without broad change permission."""

    def test_owner_can_cancel(self):
        user = SimpleNamespace(pk="owner", is_authenticated=True, has_perm=MagicMock(return_value=False))
        workflow_run = SimpleNamespace(requested_by_id="owner")

        self.assertTrue(user_can_cancel_run(user, workflow_run))
        user.has_perm.assert_not_called()

    def test_non_owner_with_change_permission_can_cancel(self):
        user = SimpleNamespace(pk="operator", is_authenticated=True, has_perm=MagicMock(return_value=True))
        workflow_run = SimpleNamespace(requested_by_id="owner")

        self.assertTrue(user_can_cancel_run(user, workflow_run))
        user.has_perm.assert_called_once_with("nautobot_workflow_launcher.change_workflowrun", workflow_run)

    def test_non_owner_without_change_permission_cannot_cancel(self):
        user = SimpleNamespace(pk="other", is_authenticated=True, has_perm=MagicMock(return_value=False))
        workflow_run = SimpleNamespace(requested_by_id="owner")

        self.assertFalse(user_can_cancel_run(user, workflow_run))

    def test_unauthenticated_user_cannot_cancel(self):
        user = SimpleNamespace(pk=None, is_authenticated=False, has_perm=MagicMock(return_value=True))
        workflow_run = SimpleNamespace(requested_by_id="owner")

        self.assertFalse(user_can_cancel_run(user, workflow_run))
        user.has_perm.assert_not_called()
