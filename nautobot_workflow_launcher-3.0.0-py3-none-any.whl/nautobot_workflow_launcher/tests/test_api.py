"""REST API tests for the Workflow Launcher app."""

# pylint: disable=too-many-ancestors

from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.urls import reverse
from nautobot.apps.testing import APITestCase
from rest_framework import status

from nautobot_workflow_launcher.models import Workflow, WorkflowInput, WorkflowRun


def _api_url(name, **kwargs):
    return reverse(f"plugins-api:nautobot_workflow_launcher-api:{name}", kwargs=kwargs or None)


class WorkflowLauncherAPITestCase(APITestCase):
    """Shared fixtures for Workflow Launcher API tests."""

    def setUp(self):
        """Create an enabled workflow with one required input."""
        super().setUp()
        self.workflow = Workflow.objects.create(
            key="test-workflow",
            name="Test Workflow",
            category="Testing",
            enabled=True,
            raw_definition={"key": "test-workflow", "name": "Test Workflow"},
        )
        self.hostname_input = WorkflowInput.objects.create(
            workflow=self.workflow,
            key="hostname",
            label="Hostname",
            input_type="string",
            required=True,
            order=0,
        )

    def _grant(self, *codenames):
        """Grant permissions as ObjectPermissions; Nautobot's auth backend ignores Django user_permissions."""
        self.add_permissions(*(f"nautobot_workflow_launcher.{codename}" for codename in codenames))


class WorkflowAPITest(WorkflowLauncherAPITestCase):
    """Workflow list/detail and discovery endpoints."""

    def test_unauthenticated_request_is_rejected(self):
        response = self.client.get(_api_url("workflow-list"))
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_list_requires_view_permission(self):
        response = self.client.get(_api_url("workflow-list"), **self.header)
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_list_returns_workflows(self):
        self._grant("view_workflow")
        response = self.client.get(_api_url("workflow-list"), **self.header)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)

    def test_filter_by_key(self):
        self._grant("view_workflow")
        response = self.client.get(f"{_api_url('workflow-list')}?key=test-workflow", **self.header)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)

    def test_input_schema_describes_inputs(self):
        self._grant("view_workflow")
        url = _api_url("workflow-input-schema", pk=self.workflow.pk)
        response = self.client.get(url, **self.header)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["key"], "hostname")
        self.assertTrue(response.data[0]["required"])

    def test_workflows_are_read_only(self):
        self._grant("view_workflow", "add_workflow", "change_workflow", "delete_workflow")

        create = self.client.post(_api_url("workflow-list"), {"key": "nope"}, format="json", **self.header)
        update = self.client.patch(
            _api_url("workflow-detail", pk=self.workflow.pk), {"name": "Renamed"}, format="json", **self.header
        )
        delete = self.client.delete(_api_url("workflow-detail", pk=self.workflow.pk), **self.header)

        self.assertEqual(create.status_code, status.HTTP_405_METHOD_NOT_ALLOWED)
        self.assertEqual(update.status_code, status.HTTP_405_METHOD_NOT_ALLOWED)
        self.assertEqual(delete.status_code, status.HTTP_405_METHOD_NOT_ALLOWED)
        self.assertTrue(Workflow.objects.filter(pk=self.workflow.pk).exists())


class WorkflowLaunchAPITest(WorkflowLauncherAPITestCase):
    """The launch action and its error mapping."""

    def setUp(self):
        super().setUp()
        self.url = _api_url("workflow-launch", pk=self.workflow.pk)

    def test_launch_requires_add_workflowrun_not_add_workflow(self):
        # add_workflow alone must NOT be sufficient to launch.
        self._grant("view_workflow", "add_workflow")
        response = self.client.post(self.url, {"inputs": {"hostname": "sw1"}}, format="json", **self.header)
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    # run_workflow imports the task lazily, so patch it at its source module.
    @patch("nautobot_workflow_launcher.tasks.execute_workflow_task")
    def test_launch_immediate_creates_running_run(self, mock_task):
        self._grant("view_workflow", "add_workflowrun")

        response = self.client.post(self.url, {"inputs": {"hostname": "sw1"}}, format="json", **self.header)

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        run = WorkflowRun.objects.get(pk=response.data["workflow_run_id"])
        self.assertEqual(run.status, "running")
        self.assertEqual(run.inputs, {"hostname": "sw1"})
        self.assertEqual(run.requested_by, self.user)
        mock_task.delay.assert_called_once_with(run.pk)

    def test_launch_rejects_missing_required_input(self):
        self._grant("view_workflow", "add_workflowrun")

        response = self.client.post(self.url, {"inputs": {}}, format="json", **self.header)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("hostname", str(response.data))
        self.assertFalse(WorkflowRun.objects.exists())

    def test_launch_rejects_unknown_input_key(self):
        self._grant("view_workflow", "add_workflowrun")

        response = self.client.post(self.url, {"inputs": {"hostname": "sw1", "nope": 1}}, format="json", **self.header)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_launch_disabled_workflow_returns_conflict(self):
        self._grant("view_workflow", "add_workflowrun")
        self.workflow.enabled = False
        self.workflow.save()

        response = self.client.post(self.url, {"inputs": {"hostname": "sw1"}}, format="json", **self.header)

        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)
        self.assertFalse(WorkflowRun.objects.exists())

    def test_scheduled_launch_requires_datetime(self):
        self._grant("view_workflow", "add_workflowrun")

        response = self.client.post(
            self.url, {"inputs": {"hostname": "sw1"}, "execution_type": "scheduled"}, format="json", **self.header
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("scheduled_datetime", response.data)

    def test_scheduled_launch_rejects_naive_datetime(self):
        self._grant("view_workflow", "add_workflowrun")

        response = self.client.post(
            self.url,
            {
                "inputs": {"hostname": "sw1"},
                "execution_type": "scheduled",
                "scheduled_datetime": "2999-01-01T00:00:00",
            },
            format="json",
            **self.header,
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    @patch("nautobot_workflow_launcher.tasks.prepare_scheduled_workflow_task")
    def test_scheduled_launch_dispatches_preparation_task(self, mock_task):
        self._grant("view_workflow", "add_workflowrun")

        response = self.client.post(
            self.url,
            {
                "inputs": {"hostname": "sw1"},
                "execution_type": "scheduled",
                "scheduled_datetime": "2999-01-01T00:00:00Z",
            },
            format="json",
            **self.header,
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        run = WorkflowRun.objects.get(pk=response.data["workflow_run_id"])
        self.assertIsNotNone(run.scheduled_for)
        self.assertEqual(run.schedule_source, "manual")
        mock_task.delay.assert_called_once_with(run.pk)


class WorkflowRunAPITest(WorkflowLauncherAPITestCase):
    """Workflow run endpoints and lifecycle actions."""

    def setUp(self):
        super().setUp()
        self.run = WorkflowRun.objects.create(
            workflow=self.workflow,
            requested_by=self.user,
            inputs={"hostname": "sw1"},
            status="scheduled",
        )

    def test_list_runs(self):
        self._grant("view_workflowrun")
        response = self.client.get(_api_url("workflowrun-list"), **self.header)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)

    def test_runs_are_read_only(self):
        self._grant("view_workflowrun", "add_workflowrun", "delete_workflowrun")

        create = self.client.post(_api_url("workflowrun-list"), {"inputs": {}}, format="json", **self.header)
        delete = self.client.delete(_api_url("workflowrun-detail", pk=self.run.pk), **self.header)

        self.assertEqual(create.status_code, status.HTTP_405_METHOD_NOT_ALLOWED)
        self.assertEqual(delete.status_code, status.HTTP_405_METHOD_NOT_ALLOWED)
        self.assertEqual(WorkflowRun.objects.count(), 1)

    def test_progress_returns_status_payload(self):
        self._grant("view_workflowrun")
        url = _api_url("workflowrun-progress", pk=self.run.pk)

        response = self.client.get(url, **self.header)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["status"], "scheduled")
        self.assertFalse(response.data["is_terminal"])
        self.assertIn("log", response.data)

    def test_progress_can_omit_logs(self):
        self._grant("view_workflowrun")
        url = f"{_api_url('workflowrun-progress', pk=self.run.pk)}?include_logs=false"

        response = self.client.get(url, **self.header)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertNotIn("log", response.data)

    def test_owner_can_cancel_with_view_permission(self):
        self._grant("view_workflowrun")
        url = _api_url("workflowrun-cancel", pk=self.run.pk)

        response = self.client.post(url, {}, format="json", **self.header)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.run.refresh_from_db()
        self.assertEqual(self.run.status, "canceled")

    def test_non_owner_requires_change_permission(self):
        other_user = get_user_model().objects.create_user(username="other-run-owner")
        self.run.requested_by = other_user
        self.run.save(update_fields=["requested_by"])
        self._grant("view_workflowrun")
        url = _api_url("workflowrun-cancel", pk=self.run.pk)

        response = self.client.post(url, {}, format="json", **self.header)

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_cancel_marks_run_canceled(self):
        self._grant("view_workflowrun", "change_workflowrun")
        url = _api_url("workflowrun-cancel", pk=self.run.pk)

        response = self.client.post(url, {"reason": "no longer needed"}, format="json", **self.header)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.run.refresh_from_db()
        self.assertEqual(self.run.status, "canceled")
        self.assertIn("no longer needed", self.run.log)

    def test_cancel_terminal_run_returns_conflict(self):
        self._grant("view_workflowrun", "change_workflowrun")
        self.run.status = "success"
        self.run.save()
        url = _api_url("workflowrun-cancel", pk=self.run.pk)

        response = self.client.post(url, {}, format="json", **self.header)

        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)


class ReadOnlyResourceTest(WorkflowLauncherAPITestCase):
    """Every model endpoint is read-only; writes happen only via launch/cancel."""

    def test_git_synced_and_engine_owned_resources_reject_creates(self):
        self._grant(
            "view_workflowinput",
            "add_workflowinput",
            "view_workflowaction",
            "add_workflowaction",
            "view_awxrun",
            "add_awxrun",
            "view_workflowhelper",
            "add_workflowhelper",
            "view_workflowfiltermodule",
            "add_workflowfiltermodule",
        )

        for route in (
            "workflowinput-list",
            "workflowaction-list",
            "awxrun-list",
            "workflowhelper-list",
            "workflowfiltermodule-list",
        ):
            with self.subTest(route=route):
                response = self.client.post(_api_url(route), {}, format="json", **self.header)
                self.assertEqual(response.status_code, status.HTTP_405_METHOD_NOT_ALLOWED)

    def test_helper_content_cannot_be_written(self):
        # WorkflowHelper.content is Python executed by the engine, so it must not be API-writable.
        self._grant("view_workflowhelper", "add_workflowhelper", "change_workflowhelper")

        response = self.client.post(
            _api_url("workflowhelper-list"),
            {"file_path": "scripts/evil.py", "content": "import os"},
            format="json",
            **self.header,
        )

        self.assertEqual(response.status_code, status.HTTP_405_METHOD_NOT_ALLOWED)
