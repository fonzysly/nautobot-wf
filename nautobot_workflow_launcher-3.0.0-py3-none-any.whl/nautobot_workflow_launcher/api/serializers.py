"""Serializers for the Workflow Launcher REST API.

Models here subclass ``BaseModel`` rather than ``PrimaryModel``, so they use
``ValidatedModelSerializer`` instead of ``NautobotModelSerializer``.
"""

# pylint: disable=abstract-method,too-many-ancestors

from django.utils.dateparse import parse_datetime
from nautobot.apps.api import ContentTypeField, ValidatedModelSerializer
from rest_framework import serializers

from nautobot_workflow_launcher.models import (
    AwxRun,
    Workflow,
    WorkflowAction,
    WorkflowFilterModule,
    WorkflowHelper,
    WorkflowInput,
    WorkflowRun,
)

EXECUTION_TYPE_CHOICES = ("immediate", "scheduled", "servicenow")


class WorkflowSerializer(ValidatedModelSerializer):
    """Serializer for the Workflow model."""

    tags = serializers.SerializerMethodField()
    has_guide = serializers.BooleanField(read_only=True)

    class Meta:
        """Meta class for WorkflowSerializer."""

        model = Workflow
        fields = "__all__"
        # Workflow definitions are owned by the Git sync, not by API clients.
        read_only_fields = ["raw_definition", "source_repo", "guide_path", "guide_content", "guide_format"]

    def get_tags(self, obj):
        """Return tag names; Workflow uses a raw taggit manager rather than Nautobot's TagsField."""
        return list(obj.tags.names())


class WorkflowInputSerializer(ValidatedModelSerializer):
    """Serializer for the WorkflowInput model."""

    content_type = ContentTypeField(read_only=True)

    class Meta:
        """Meta class for WorkflowInputSerializer."""

        model = WorkflowInput
        fields = "__all__"


class WorkflowActionSerializer(ValidatedModelSerializer):
    """Serializer for the WorkflowAction model."""

    class Meta:
        """Meta class for WorkflowActionSerializer."""

        model = WorkflowAction
        fields = "__all__"


class WorkflowRunSerializer(ValidatedModelSerializer):
    """Serializer for the WorkflowRun model."""

    class Meta:
        """Meta class for WorkflowRunSerializer."""

        model = WorkflowRun
        fields = "__all__"
        # Execution state is owned by the engine; clients launch via the workflow launch action.
        read_only_fields = [
            "status",
            "started",
            "execution_started",
            "finished",
            "log",
            "user_log",
            "phase_results",
            "scheduled_job",
            "schedule_last_synced",
            "schedule_sync_error",
        ]


class AwxRunSerializer(ValidatedModelSerializer):
    """Serializer for the AwxRun model."""

    class Meta:
        """Meta class for AwxRunSerializer."""

        model = AwxRun
        fields = "__all__"


class WorkflowHelperSerializer(ValidatedModelSerializer):
    """Serializer for the WorkflowHelper model."""

    class Meta:
        """Meta class for WorkflowHelperSerializer."""

        model = WorkflowHelper
        fields = "__all__"


class WorkflowFilterModuleSerializer(ValidatedModelSerializer):
    """Serializer for the WorkflowFilterModule model."""

    class Meta:
        """Meta class for WorkflowFilterModuleSerializer."""

        model = WorkflowFilterModule
        fields = "__all__"


class WorkflowLaunchSerializer(serializers.Serializer):
    """Request body for launching a workflow."""

    inputs = serializers.DictField(required=True, help_text="Input values keyed by workflow input key.")
    execution_type = serializers.ChoiceField(choices=EXECUTION_TYPE_CHOICES, default="immediate")
    scheduled_datetime = serializers.DateTimeField(
        required=False,
        allow_null=True,
        help_text="Required for execution_type=scheduled. Must be timezone-aware ISO-8601.",
    )
    change_ticket = serializers.CharField(
        required=False,
        allow_blank=True,
        help_text="Required for execution_type=servicenow unless the workflow maps a change-ticket input.",
    )
    form_duration_seconds = serializers.IntegerField(required=False, min_value=0, default=0)

    def validate_scheduled_datetime(self, value):
        """Reject naive datetimes; API clients must supply an explicit UTC offset."""
        raw_value = self.initial_data.get("scheduled_datetime")
        raw_datetime = parse_datetime(raw_value) if isinstance(raw_value, str) else raw_value
        if raw_datetime is not None and raw_datetime.tzinfo is None:
            raise serializers.ValidationError("Provide a timezone-aware datetime (include a UTC offset).")
        return value

    def validate(self, attrs):
        """Enforce the fields each execution type requires."""
        execution_type = attrs.get("execution_type", "immediate")

        if execution_type == "scheduled" and not attrs.get("scheduled_datetime"):
            raise serializers.ValidationError(
                {"scheduled_datetime": "This field is required when execution_type is 'scheduled'."}
            )

        if execution_type == "servicenow":
            workflow = self.context.get("workflow")
            has_mapped_input = bool(workflow and workflow.servicenow_change_input_key)
            if not attrs.get("change_ticket") and not has_mapped_input:
                raise serializers.ValidationError(
                    {"change_ticket": "This field is required when execution_type is 'servicenow'."}
                )

        return attrs


class WorkflowLaunchResultSerializer(serializers.Serializer):
    """Response body returned after a successful launch."""

    workflow_run_id = serializers.UUIDField(read_only=True)
    status = serializers.CharField(read_only=True)
    execution_type = serializers.CharField(read_only=True)
    scheduled_for = serializers.DateTimeField(read_only=True, allow_null=True)
    url = serializers.CharField(read_only=True)


class WorkflowInputSchemaSerializer(serializers.Serializer):
    """Machine-readable description of a single workflow input."""

    key = serializers.CharField(read_only=True)
    label = serializers.CharField(read_only=True)
    type = serializers.CharField(read_only=True)
    required = serializers.BooleanField(read_only=True)
    default = serializers.JSONField(read_only=True, allow_null=True)
    choices = serializers.JSONField(read_only=True, allow_null=True)
    content_type = serializers.CharField(read_only=True, allow_null=True)
    depends_on = serializers.JSONField(read_only=True)
    visible_when = serializers.JSONField(read_only=True, allow_null=True)
    validators = serializers.JSONField(read_only=True, allow_null=True)
    columns = serializers.JSONField(read_only=True, allow_null=True)
    order = serializers.IntegerField(read_only=True)


class WorkflowRunCancelSerializer(serializers.Serializer):
    """Request body for cancelling a workflow run."""

    reason = serializers.CharField(required=False, allow_blank=True, default="")


class WorkflowRunProgressSerializer(serializers.Serializer):
    """Progress payload for a workflow run. Declared for schema generation only."""

    pk = serializers.CharField(read_only=True)
    status = serializers.CharField(read_only=True)
    status_label = serializers.CharField(read_only=True)
    status_badge = serializers.JSONField(read_only=True)
    headline = serializers.CharField(read_only=True)
    started = serializers.DateTimeField(read_only=True, allow_null=True)
    finished = serializers.DateTimeField(read_only=True, allow_null=True)
    scheduled_for = serializers.DateTimeField(read_only=True, allow_null=True)
    is_terminal = serializers.BooleanField(read_only=True)
    execution_duration_seconds = serializers.IntegerField(read_only=True, allow_null=True)
    execution_duration_display = serializers.CharField(read_only=True)
    progress_percent = serializers.IntegerField(read_only=True)
    progress_text = serializers.CharField(read_only=True)
    has_post_action_errors = serializers.BooleanField(read_only=True)
    awx_runs = serializers.JSONField(read_only=True)
    steps = serializers.JSONField(read_only=True)
    log = serializers.CharField(read_only=True, required=False)
    user_log = serializers.CharField(read_only=True, required=False)
