"""Permission classes for custom Workflow Launcher API actions.

Nautobot's ``TokenPermissions`` derives the required permission from the viewset's queryset
model. Custom actions act on a different model than the viewset they hang off, so they would
otherwise demand the wrong permission (for example, launching a workflow would require
``add_workflow`` -- the permission to author a workflow definition -- instead of
``add_workflowrun``).
"""

from nautobot.core.api.authentication import TokenPermissions


class WorkflowRunLaunchPermissions(TokenPermissions):
    """Require ``add_workflowrun`` (not ``add_workflow``) to launch a workflow.

    Object-level checks still run against the target Workflow, so a user must also be able to
    view that specific workflow.
    """

    perms_map = {
        **TokenPermissions.perms_map,
        "POST": ["nautobot_workflow_launcher.add_workflowrun"],
    }

    def get_required_object_permissions(self, method, model_cls):
        """Launching reads the workflow; it does not modify it."""
        if method == "POST":
            return ["nautobot_workflow_launcher.view_workflow"]
        return super().get_required_object_permissions(method, model_cls)


class WorkflowRunCancelPermissions(TokenPermissions):
    """Require run visibility; ownership/change authorization is checked by the action."""

    perms_map = {
        **TokenPermissions.perms_map,
        "POST": ["nautobot_workflow_launcher.view_workflowrun"],
    }

    def get_required_object_permissions(self, method, model_cls):
        """Require access to the run before applying owner-or-change authorization."""
        if method == "POST":
            return ["nautobot_workflow_launcher.view_workflowrun"]
        return super().get_required_object_permissions(method, model_cls)
