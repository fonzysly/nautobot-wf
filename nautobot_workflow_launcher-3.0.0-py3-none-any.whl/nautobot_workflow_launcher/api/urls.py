"""URL routing for the Workflow Launcher REST API.

Nautobot auto-discovers this module and mounts it at /api/plugins/workflow-launcher/.
"""

from nautobot.apps.api import OrderedDefaultRouter

from .views import (
    AwxRunViewSet,
    WorkflowActionViewSet,
    WorkflowFilterModuleViewSet,
    WorkflowHelperViewSet,
    WorkflowInputViewSet,
    WorkflowRunViewSet,
    WorkflowViewSet,
)

router = OrderedDefaultRouter(view_name="Workflow Launcher")
router.register("workflows", WorkflowViewSet)
router.register("workflow-inputs", WorkflowInputViewSet)
router.register("workflow-actions", WorkflowActionViewSet)
router.register("workflow-runs", WorkflowRunViewSet)
router.register("awx-runs", AwxRunViewSet)
router.register("workflow-helpers", WorkflowHelperViewSet)
router.register("workflow-filter-modules", WorkflowFilterModuleViewSet)

app_name = "nautobot_workflow_launcher-api"
urlpatterns = router.urls
