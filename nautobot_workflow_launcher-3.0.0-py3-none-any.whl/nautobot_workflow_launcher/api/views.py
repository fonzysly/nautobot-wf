"""Viewsets for the Workflow Launcher REST API."""

# pylint: disable=too-many-ancestors

from drf_spectacular.utils import OpenApiParameter, extend_schema
from nautobot.apps.api import ReadOnlyModelViewSet
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied, ValidationError
from rest_framework.response import Response

from nautobot_workflow_launcher.filters import (
    AwxRunFilterSet,
    WorkflowActionFilterSet,
    WorkflowFilterModuleFilterSet,
    WorkflowFilterSet,
    WorkflowHelperFilterSet,
    WorkflowInputFilterSet,
    WorkflowRunFilterSet,
)
from nautobot_workflow_launcher.input_validation import (
    WorkflowInputValidationError,
    build_input_schema,
    validate_workflow_inputs,
)
from nautobot_workflow_launcher.launching import (
    WorkflowLaunchPermissionError,
    WorkflowLaunchStateError,
    launch_workflow,
)
from nautobot_workflow_launcher.models import (
    AwxRun,
    Workflow,
    WorkflowAction,
    WorkflowFilterModule,
    WorkflowHelper,
    WorkflowInput,
    WorkflowRun,
)
from nautobot_workflow_launcher.run_progress import TERMINAL_WORKFLOW_STATUSES, serialize_workflow_run_progress
from nautobot_workflow_launcher.scheduling import (
    WorkflowRunCancellationError,
    cancel_scheduled_run,
    user_can_cancel_run,
)
from nautobot_workflow_launcher.servicenow import ServiceNowValidationError

from .permissions import WorkflowRunCancelPermissions, WorkflowRunLaunchPermissions
from .serializers import (
    AwxRunSerializer,
    WorkflowActionSerializer,
    WorkflowFilterModuleSerializer,
    WorkflowHelperSerializer,
    WorkflowInputSchemaSerializer,
    WorkflowInputSerializer,
    WorkflowLaunchResultSerializer,
    WorkflowLaunchSerializer,
    WorkflowRunCancelSerializer,
    WorkflowRunProgressSerializer,
    WorkflowRunSerializer,
    WorkflowSerializer,
)


class WorkflowViewSet(ReadOnlyModelViewSet):
    """Browse workflow definitions and launch workflow runs.

    Read-only: definitions are owned by the Git sync and would be overwritten on the next sync.
    """

    queryset = Workflow.objects.order_by("category", "name")
    serializer_class = WorkflowSerializer
    filterset_class = WorkflowFilterSet

    def restrict_queryset(self, request, *args, **kwargs):
        """Launching reads the workflow, so restrict /launch/ by view rather than the POST default of add."""
        if request.user.is_authenticated and self.action == "launch":
            self.queryset = self.queryset.restrict(request.user, "view")
        else:
            super().restrict_queryset(request, *args, **kwargs)

    @extend_schema(
        request=WorkflowLaunchSerializer,
        responses={201: WorkflowLaunchResultSerializer},
    )
    @action(
        detail=True,
        methods=["post"],
        url_path="launch",
        serializer_class=WorkflowLaunchSerializer,
        permission_classes=[WorkflowRunLaunchPermissions],
    )
    def launch(self, request, pk=None):  # pylint: disable=unused-argument
        """Launch this workflow with the supplied inputs."""
        workflow = self.get_object()

        request_serializer = WorkflowLaunchSerializer(
            data=request.data,
            context={"workflow": workflow, "request": request},
        )
        request_serializer.is_valid(raise_exception=True)
        data = request_serializer.validated_data

        try:
            cleaned_inputs = validate_workflow_inputs(workflow, data["inputs"])
        except WorkflowInputValidationError as exc:
            raise ValidationError({"inputs": exc.errors}) from exc

        try:
            result = launch_workflow(
                workflow,
                request.user,
                cleaned_inputs,
                execution_type=data.get("execution_type", "immediate"),
                scheduled_datetime=data.get("scheduled_datetime"),
                change_ticket=data.get("change_ticket"),
                form_duration_seconds=data.get("form_duration_seconds", 0),
            )
        except WorkflowLaunchPermissionError as exc:
            raise PermissionDenied(str(exc)) from exc
        except WorkflowLaunchStateError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_409_CONFLICT)
        except ServiceNowValidationError as exc:
            raise ValidationError({"change_ticket": [str(exc)]}) from exc

        run = result.workflow_run
        payload = {
            "workflow_run_id": run.pk,
            "status": run.status,
            "execution_type": result.execution_type,
            "scheduled_for": result.scheduled_for,
            "url": request.build_absolute_uri(run.get_absolute_url()),
        }
        return Response(
            WorkflowLaunchResultSerializer(payload).data,
            status=status.HTTP_201_CREATED,
        )

    @extend_schema(responses={200: WorkflowInputSchemaSerializer(many=True)})
    @action(detail=True, methods=["get"], url_path="input-schema")
    def input_schema(self, request, pk=None):  # pylint: disable=unused-argument
        """Describe this workflow's inputs so clients can build a valid launch payload."""
        workflow = self.get_object()
        return Response(WorkflowInputSchemaSerializer(build_input_schema(workflow), many=True).data)


class WorkflowInputViewSet(ReadOnlyModelViewSet):
    """Browse workflow input definitions (owned by the Git sync)."""

    queryset = WorkflowInput.objects.order_by("workflow", "order", "key")
    serializer_class = WorkflowInputSerializer
    filterset_class = WorkflowInputFilterSet


class WorkflowActionViewSet(ReadOnlyModelViewSet):
    """Browse workflow action definitions (owned by the Git sync)."""

    queryset = WorkflowAction.objects.order_by("workflow", "phase", "order")
    serializer_class = WorkflowActionSerializer
    filterset_class = WorkflowActionFilterSet


class WorkflowRunViewSet(ReadOnlyModelViewSet):
    """Inspect and control workflow runs.

    Read-only: runs are created through the workflow ``launch`` action so that they actually
    execute, and run history is preserved for audit.
    """

    # WorkflowRun has no Meta.ordering; ordering here keeps API pagination stable.
    queryset = WorkflowRun.objects.order_by("-started")
    serializer_class = WorkflowRunSerializer
    filterset_class = WorkflowRunFilterSet

    def filter_queryset(self, queryset):
        """Skip list filters for progress polling query options."""
        if self.action == "progress":
            return queryset
        return super().filter_queryset(queryset)

    def restrict_queryset(self, request, *args, **kwargs):
        """Resolve visible runs for cancel; the action applies owner-or-change authorization."""
        if request.user.is_authenticated and self.action == "cancel":
            self.queryset = self.queryset.restrict(request.user, "view")
        else:
            super().restrict_queryset(request, *args, **kwargs)

    @extend_schema(
        parameters=[
            OpenApiParameter(
                name="include_logs",
                type=bool,
                location=OpenApiParameter.QUERY,
                description="Include the full execution and user logs in the response. Defaults to true.",
            )
        ],
        responses={200: WorkflowRunProgressSerializer},
    )
    @action(detail=True, methods=["get"], url_path="progress")
    def progress(self, request, pk=None):  # pylint: disable=unused-argument
        """Return live progress for this run, suitable for polling until is_terminal is true."""
        workflow_run = self.get_object()
        include_logs = str(request.query_params.get("include_logs", "true")).lower() not in {"false", "0", "no"}
        return Response(serialize_workflow_run_progress(workflow_run, include_logs=include_logs))

    @extend_schema(
        request=WorkflowRunCancelSerializer,
        responses={200: WorkflowRunProgressSerializer},
    )
    @action(
        detail=True,
        methods=["post"],
        url_path="cancel",
        serializer_class=WorkflowRunCancelSerializer,
        permission_classes=[WorkflowRunCancelPermissions],
    )
    def cancel(self, request, pk=None):  # pylint: disable=unused-argument
        """Cancel a scheduled run before execution begins."""
        workflow_run = self.get_object()

        if not user_can_cancel_run(request.user, workflow_run):
            raise PermissionDenied("You do not have permission to cancel this workflow run.")

        if workflow_run.status in TERMINAL_WORKFLOW_STATUSES:
            return Response(
                {"detail": f"Run is already in a terminal state ('{workflow_run.status}')."},
                status=status.HTTP_409_CONFLICT,
            )

        # Cancelling only updates the database; it cannot stop a task that is already executing.
        if workflow_run.status == "running":
            return Response(
                {"detail": "Run is already executing and cannot be canceled."},
                status=status.HTTP_409_CONFLICT,
            )

        request_serializer = WorkflowRunCancelSerializer(data=request.data)
        request_serializer.is_valid(raise_exception=True)
        reason = request_serializer.validated_data.get("reason") or f"Canceled via REST API by {request.user}."

        try:
            workflow_run = cancel_scheduled_run(workflow_run, reason)
        except WorkflowRunCancellationError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_409_CONFLICT)
        return Response(serialize_workflow_run_progress(workflow_run))


class AwxRunViewSet(ReadOnlyModelViewSet):
    """Inspect AWX job executions associated with workflow runs.

    Read-only: these records are created by the executor when it dispatches AWX jobs.
    """

    queryset = AwxRun.objects.order_by("-id")
    serializer_class = AwxRunSerializer
    filterset_class = AwxRunFilterSet


class WorkflowHelperViewSet(ReadOnlyModelViewSet):
    """Browse helper Python modules synced from Git repositories.

    Read-only: ``content`` is executable Python loaded by the workflow engine, so it is
    owned by the Git sync and must not be writable over the API.
    """

    queryset = WorkflowHelper.objects.order_by("source_repo", "file_path")
    serializer_class = WorkflowHelperSerializer
    filterset_class = WorkflowHelperFilterSet


class WorkflowFilterModuleViewSet(ReadOnlyModelViewSet):
    """Browse Jinja filter modules synced from Git repositories.

    Read-only for the same reason as ``WorkflowHelperViewSet``: ``content`` is executable Python.
    """

    queryset = WorkflowFilterModule.objects.order_by("source_repo", "file_path")
    serializer_class = WorkflowFilterModuleSerializer
    filterset_class = WorkflowFilterModuleFilterSet
