"""Shared workflow launch orchestration used by both the UI view and the REST API."""

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from django.utils import timezone

from .executors import run_workflow
from .models import WorkflowRun
from .servicenow import get_change_window

logger = logging.getLogger(__name__)

ADD_RUN_PERM = "nautobot_workflow_launcher.add_workflowrun"
VIEW_WORKFLOW_PERM = "nautobot_workflow_launcher.view_workflow"


class WorkflowLaunchError(Exception):
    """Base class for launch failures that callers should surface to the requester."""


class WorkflowLaunchPermissionError(WorkflowLaunchError):
    """The requesting user may not launch this workflow."""


class WorkflowLaunchStateError(WorkflowLaunchError):
    """The workflow is not in a launchable state."""


@dataclass
class LaunchResult:
    """Outcome of a launch request, including how the request was ultimately scheduled."""

    workflow_run: WorkflowRun
    execution_type: str
    scheduled_for: Optional[datetime] = None
    schedule_source: str = ""
    schedule_change_ticket: str = ""


def _check_launch_permissions(workflow, user):
    """Reject the launch before any WorkflowRun row is created."""
    if not workflow.enabled:
        raise WorkflowLaunchStateError(f"Workflow '{workflow.name}' is disabled and cannot be executed.")

    if not user.has_perm(ADD_RUN_PERM):
        raise WorkflowLaunchPermissionError("You do not have permission to execute workflows.")

    if not user.has_perm(VIEW_WORKFLOW_PERM, workflow):
        raise WorkflowLaunchPermissionError("You do not have permission to this workflow.")


def resolve_change_ticket(workflow, inputs, change_ticket=None):
    """Return the ServiceNow change ticket, falling back to the workflow's configured input key."""
    if change_ticket:
        return change_ticket
    change_input_key = workflow.servicenow_change_input_key
    if change_input_key:
        return inputs.get(change_input_key) or ""
    return ""


def launch_workflow(  # pylint: disable=too-many-arguments
    workflow,
    user,
    inputs,
    *,
    execution_type="immediate",
    scheduled_datetime=None,
    change_ticket=None,
    form_duration_seconds=0,
):
    """Create and dispatch a WorkflowRun for the given inputs.

    Raises ``WorkflowLaunchPermissionError``, ``WorkflowLaunchStateError``, or
    ``ServiceNowValidationError`` so callers can map failures to their own error surface.
    """
    _check_launch_permissions(workflow, user)

    schedule_source = ""
    schedule_external_system = ""
    schedule_change_ticket = ""
    schedule_external_record_id = ""
    schedule_window_start = None
    schedule_window_end = None
    schedule_last_synced = None

    if execution_type == "servicenow":
        resolved_ticket = resolve_change_ticket(workflow, inputs, change_ticket)
        change_window = get_change_window(change_ticket=resolved_ticket, workflow=workflow)

        execution_type = "scheduled"
        scheduled_datetime = change_window.window_start
        schedule_source = "servicenow"
        schedule_external_system = "ServiceNow"
        schedule_change_ticket = change_window.change_number
        schedule_external_record_id = change_window.sys_id
        schedule_window_start = change_window.window_start
        schedule_window_end = change_window.window_end
        schedule_last_synced = timezone.now()

    elif execution_type == "scheduled":
        if not scheduled_datetime:
            raise WorkflowLaunchStateError("A scheduled date and time is required for scheduled execution.")
        schedule_source = "manual"

    # Scheduled runs start as "running" while pre-actions execute, then flip to "scheduled".
    status = "running" if execution_type == "scheduled" else "pending"
    run_scheduled_for = scheduled_datetime if execution_type == "scheduled" else None

    run = WorkflowRun.objects.create(
        workflow=workflow,
        requested_by=user,
        inputs=inputs,
        status=status,
        scheduled_for=run_scheduled_for,
        schedule_source=schedule_source,
        schedule_external_system=schedule_external_system,
        schedule_change_ticket=schedule_change_ticket,
        schedule_external_record_id=schedule_external_record_id,
        schedule_window_start=schedule_window_start,
        schedule_window_end=schedule_window_end,
        schedule_last_synced=schedule_last_synced,
        schedule_sync_error="",
        form_duration_seconds=form_duration_seconds,
    )

    if execution_type == "immediate":
        # Set running up front to avoid a race with UI progress polling.
        run.status = "running"
        run.save(update_fields=["status"])
        run_workflow(workflow, user, inputs, run)
    else:
        from .tasks import prepare_scheduled_workflow_task

        preparing_message = "Preparing scheduled workflow (running pre-actions before final scheduling)..."
        run.log = f"{run.log}\n{preparing_message}".strip() if run.log else preparing_message
        run.save(update_fields=["status", "log"])

        prepare_scheduled_workflow_task.delay(run.pk)

    return LaunchResult(
        workflow_run=run,
        execution_type=execution_type,
        scheduled_for=run_scheduled_for,
        schedule_source=schedule_source,
        schedule_change_ticket=schedule_change_ticket,
    )
