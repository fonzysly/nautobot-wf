"""Nautobot admin registration for problem-report triage."""

from django.contrib import admin, messages
from nautobot.apps.admin import NautobotModelAdmin

from .models import ProblemReport


@admin.register(ProblemReport)
class ProblemReportAdmin(NautobotModelAdmin):
    """Triage problem reports and retry failed email deliveries."""

    list_display = (
        "reference",
        "summary",
        "category",
        "status",
        "reported_by",
        "workflow",
        "workflow_run",
        "support_delivery_status",
        "acknowledgment_status",
        "created_at",
    )
    list_filter = (
        "category",
        "status",
        "support_delivery_status",
        "acknowledgment_status",
        "created_at",
    )
    search_fields = (
        "id",
        "summary",
        "description",
        "reported_by__username",
        "reported_by__email",
        "workflow__name",
        "workflow__key",
        "workflow_run__id",
    )
    readonly_fields = (
        "reported_by",
        "workflow",
        "workflow_run",
        "category",
        "summary",
        "description",
        "expected_behavior",
        "steps_to_reproduce",
        "page_url",
        "user_agent",
        "support_delivery_status",
        "support_delivery_results",
        "support_delivery_error",
        "support_delivered_at",
        "acknowledgment_status",
        "acknowledgment_error",
        "acknowledgment_delivered_at",
        "created_at",
        "updated_at",
    )
    fields = readonly_fields + ("status", "resolution_notes")
    actions = ("retry_failed_email_delivery",)

    @admin.action(description="Retry failed problem-report email delivery")
    def retry_failed_email_delivery(self, request, queryset):
        """Retry only failed support recipients and an unsent acknowledgment."""
        from .tasks import send_problem_report_emails

        queued = 0
        for report in queryset:
            failed_recipients = [
                result.get("address")
                for result in (report.support_delivery_results or [])
                if isinstance(result, dict) and result.get("status") == "failed" and result.get("address")
            ]
            needs_acknowledgment = report.acknowledgment_status == "failed"
            if (
                not failed_recipients
                and report.support_delivery_status not in ("failed", "partial")
                and not needs_acknowledgment
            ):
                continue
            send_problem_report_emails.delay(str(report.pk), failed_recipients)
            queued += 1
        self.message_user(request, f"Queued email retry for {queued} report(s).", level=messages.INFO)
