"""Schema-driven validation of workflow inputs, shared by the UI form and the REST API.

The UI form intentionally defers most required/visibility checks to client-side JavaScript.
The REST API has no such client, so it relies on this module for full server-side enforcement.
"""

import json
import logging
import re

from django.core.exceptions import ValidationError as DjangoValidationError

logger = logging.getLogger(__name__)

# Sentinel emitted by the UI for "create a new object" selections.
CREATE_NEW_SENTINEL = "__create__"

LIST_INPUT_TYPES = ("multichoice", "multiobject", "list")


class WorkflowInputValidationError(Exception):
    """Raised when a launch payload fails validation against the workflow's input definitions."""

    def __init__(self, errors):
        """Store a mapping of input key to list of error messages."""
        self.errors = errors
        super().__init__("Workflow input validation failed.")


def resolve_regex_flags(flag_names):
    """Translate serialized regex flag names into Python re flags."""
    flags = 0
    for flag_name in flag_names or []:
        resolved = getattr(re, str(flag_name), None)
        if isinstance(resolved, int):
            flags |= resolved
    return flags


def coerce_tabular_value(column, value):
    """Normalize a listdict column value to the expected Python type.

    Returns a ``(value, error_message_or_None)`` tuple.
    """
    column_type = str(column.get("type") or "string").lower()
    label = column.get("label") or column.get("key") or "Value"

    if column_type == "boolean":
        if isinstance(value, bool):
            return value, None
        if value in (None, ""):
            return False, None
        if isinstance(value, (int, float)):
            return bool(value), None
        normalized = str(value).strip().lower()
        if normalized in {"true", "1", "yes", "y", "on"}:
            return True, None
        if normalized in {"false", "0", "no", "n", "off", ""}:
            return False, None
        return value, f"{label} must be true/false."

    if column_type in ("integer", "number"):
        if value in (None, ""):
            return "", None
        try:
            return int(value), None
        except (TypeError, ValueError):
            return value, f"{label} must be a number."

    if column_type == "choice":
        if value in (None, ""):
            return "", None

        normalized_value = str(value).strip()
        normalized_lookup = normalized_value.lower()
        for choice in column.get("choices") or []:
            choice_value = str(choice.get("value", "")).strip()
            choice_label = str(choice.get("label", choice_value)).strip()
            if normalized_lookup in {choice_value.lower(), choice_label.lower()}:
                return choice_value, None

        return normalized_value, None

    if value is None:
        return "", None
    return str(value), None


def validate_tabular_rows(workflow_input, rows):
    """Validate listdict rows in place and return a list of error messages."""
    errors = []

    if not isinstance(rows, list):
        return ["Submitted data must be a list of rows."]

    columns = workflow_input.columns or []
    if not isinstance(columns, list):
        return ["Input columns are misconfigured."]

    unique_values = {
        col.get("key"): {} for col in columns if isinstance(col, dict) and col.get("unique") is True and col.get("key")
    }

    for row_index, row in enumerate(rows, start=1):
        if not isinstance(row, dict):
            errors.append(f"Row {row_index} must be an object.")
            continue

        for column in columns:
            if not isinstance(column, dict):
                continue

            column_key = column.get("key")
            if not column_key:
                continue

            label = column.get("label") or column_key
            column_type = str(column.get("type") or "string").lower()
            required = column.get("required") is True
            value, error = coerce_tabular_value(column, row.get(column_key))
            row[column_key] = value

            if required and column_type != "boolean":
                if value in (None, "") or (isinstance(value, str) and value.strip() == ""):
                    errors.append(f"Row {row_index}, {label}: this value is required.")
                    continue

            if error:
                errors.append(f"Row {row_index}, {label}: {error}")
                continue

            if column_type == "choice" and value not in (None, ""):
                allowed_values = [
                    str(choice.get("value")) for choice in column.get("choices") or [] if "value" in choice
                ]
                if allowed_values and str(value) not in allowed_values:
                    errors.append(f"Row {row_index}, {label}: invalid choice '{value}'.")

            if (
                value not in (None, "")
                and isinstance(value, str)
                and value.strip()
                and isinstance(column.get("validators"), list)
            ):
                for validator in column.get("validators"):
                    if not isinstance(validator, dict) or not validator.get("regex"):
                        continue
                    try:
                        regex = re.compile(
                            validator["regex"],
                            flags=resolve_regex_flags(validator.get("flags")),
                        )
                    except re.error:
                        errors.append(f"Column '{label}' has an invalid regex validator.")
                        continue
                    if not regex.search(value):
                        errors.append(
                            f"Row {row_index}, {label}: {validator.get('message') or 'format is invalid.'}",
                        )

            if column_key in unique_values and value not in (None, ""):
                normalized = str(value).strip().lower()
                if normalized:
                    previous_row = unique_values[column_key].get(normalized)
                    if previous_row is not None:
                        errors.append(
                            f"Row {row_index}, {label}: value must be unique (already used in row {previous_row}).",
                        )
                    else:
                        unique_values[column_key][normalized] = row_index

    return errors


def input_is_visible(workflow_input, values):
    """Mirror the UI's progressive-disclosure rules to decide if an input applies."""
    for dependency in workflow_input.depends_on or []:
        if not values.get(dependency):
            return False

    if workflow_input.visible_when:
        for ctrl_key, ctrl_val in workflow_input.visible_when.items():
            ctrl_vals = ctrl_val if isinstance(ctrl_val, list) else [ctrl_val]
            current_value = values.get(ctrl_key)

            if isinstance(current_value, bool):
                current_str = str(current_value).lower()
                condition_satisfied = any(str(v).lower() == current_str for v in ctrl_vals)
            else:
                condition_satisfied = str(current_value or "") in [str(v) for v in ctrl_vals]

            if not condition_satisfied:
                return False

    return True


def _has_jinja_choices(workflow_input):
    """Return True when choices are Jinja-templated and therefore cannot be validated statically."""
    if not workflow_input.choices:
        return False
    choices_str = str(workflow_input.choices)
    return "{{" in choices_str and "}}" in choices_str


def _static_choice_values(workflow_input):
    """Return the allowed choice values, or None when they cannot be determined statically."""
    if _has_jinja_choices(workflow_input):
        return None
    choices = workflow_input.choices
    if not isinstance(choices, list):
        return None
    values = []
    for choice in choices:
        if isinstance(choice, dict) and "value" in choice:
            values.append(str(choice["value"]))
        elif isinstance(choice, (str, int, float)):
            values.append(str(choice))
    return values or None


def _as_list(value):
    """Coerce a payload value into a list, accepting native lists or JSON-encoded strings."""
    if value is None or value == "":
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except (json.JSONDecodeError, TypeError, ValueError):
            return [value]
        return parsed if isinstance(parsed, list) else [parsed]
    return [value]


def _coerce_value(workflow_input, raw_value):
    """Coerce a raw payload value to the shape the executor expects, without validating it."""
    input_type = workflow_input.input_type

    if input_type in LIST_INPUT_TYPES:
        return _as_list(raw_value)

    if input_type == "listdict":
        parsed = _as_list(raw_value)
        return list(parsed)

    if input_type == "boolean":
        if isinstance(raw_value, bool):
            return raw_value
        if raw_value in (None, ""):
            return False
        return str(raw_value).strip().lower() in {"true", "1", "yes", "y", "on"}

    if input_type == "integer":
        if raw_value in (None, ""):
            return None
        try:
            return int(raw_value)
        except (TypeError, ValueError):
            return raw_value

    if raw_value is None:
        return None
    return str(raw_value)


def _is_empty(value):
    """Return True when a coerced value counts as "not supplied"."""
    if value is None:
        return True
    if isinstance(value, str):
        return value.strip() == ""
    if isinstance(value, (list, dict)):
        return len(value) == 0
    return False


def _object_exists(model, pk):
    """Return True when the referenced object is present in the database."""
    try:
        model.objects.get(pk=pk)
    except (model.DoesNotExist, ValueError, TypeError, DjangoValidationError):
        return False
    return True


def _validate_object_references(workflow_input, value, errors):
    """Verify object/multiobject PKs resolve to real records."""
    if not workflow_input.content_type:
        return value

    model = workflow_input.content_type.model_class()
    if model is None:
        errors.append(f"Input '{workflow_input.key}' references a content type that is no longer installed.")
        return value

    if workflow_input.input_type == "multiobject":
        resolved = []
        for item in value:
            item_pk = str(item)
            if item_pk == CREATE_NEW_SENTINEL:
                resolved.append(item_pk)
                continue
            if not _object_exists(model, item_pk):
                errors.append(f"Object with ID {item_pk} does not exist.")
                continue
            resolved.append(item_pk)
        return resolved

    value_pk = str(value)
    if value_pk == CREATE_NEW_SENTINEL:
        return value_pk
    if not _object_exists(model, value_pk):
        errors.append(f"Object with ID {value_pk} does not exist.")
    return value_pk


def _apply_regex_validators(workflow_input, value, errors):
    """Apply the input's configured regex validators to a string value."""
    validators = workflow_input.validators
    if not isinstance(validators, list) or not isinstance(value, str) or not value.strip():
        return

    for validator in validators:
        if not isinstance(validator, dict) or not validator.get("regex"):
            continue
        try:
            regex = re.compile(validator["regex"], flags=resolve_regex_flags(validator.get("flags")))
        except re.error:
            logger.warning("Invalid regex validator on workflow input %s", workflow_input.pk)
            errors.append(f"Input '{workflow_input.key}' has an invalid regex validator.")
            continue
        if not regex.search(value):
            errors.append(validator.get("message") or "Format is invalid.")


def validate_workflow_inputs(workflow, payload):
    """Validate a launch payload against a workflow's input definitions.

    Returns a dict matching the shape ``DynamicWorkflowForm.clean()`` produces, so the
    executor treats API-launched and UI-launched runs identically.

    Raises ``WorkflowInputValidationError`` with a ``{key: [messages]}`` mapping.
    """
    if not isinstance(payload, dict):
        raise WorkflowInputValidationError({"inputs": ["Inputs must be an object."]})

    workflow_inputs = list(workflow.inputs.all())
    known_keys = {wi.key for wi in workflow_inputs}

    errors = {}
    unknown_keys = sorted(set(payload) - known_keys)
    if unknown_keys:
        errors["inputs"] = [f"Unknown input key(s): {', '.join(unknown_keys)}."]

    # First pass coerces everything so visibility rules can reference any other input.
    coerced = {}
    for workflow_input in workflow_inputs:
        raw_value = payload.get(workflow_input.key, workflow_input.default)
        coerced[workflow_input.key] = _coerce_value(workflow_input, raw_value)

    cleaned = {}
    for workflow_input in workflow_inputs:
        key = workflow_input.key

        if not input_is_visible(workflow_input, coerced):
            cleaned[key] = None
            continue

        value = coerced[key]
        field_errors = []

        if _is_empty(value):
            if workflow_input.required:
                field_errors.append("This field is required.")
            cleaned[key] = value
            if field_errors:
                errors[key] = field_errors
            continue

        if workflow_input.input_type == "integer" and not isinstance(value, int):
            field_errors.append("Enter a valid integer.")

        elif workflow_input.input_type in ("object", "multiobject"):
            value = _validate_object_references(workflow_input, value, field_errors)

        elif workflow_input.input_type in ("choice", "multichoice"):
            allowed = _static_choice_values(workflow_input)
            if allowed is not None:
                candidates = value if workflow_input.input_type == "multichoice" else [value]
                for candidate in candidates:
                    if str(candidate) not in allowed:
                        field_errors.append(f"'{candidate}' is not a valid choice.")

        elif workflow_input.input_type == "listdict":
            field_errors.extend(validate_tabular_rows(workflow_input, value))

        elif workflow_input.input_type == "list":
            value = [str(item) for item in value]

        if workflow_input.input_type in ("string", "choice"):
            _apply_regex_validators(workflow_input, value, field_errors)

        cleaned[key] = value
        if field_errors:
            errors[key] = field_errors

    if errors:
        raise WorkflowInputValidationError(errors)

    return cleaned


def build_input_schema(workflow):
    """Describe a workflow's inputs so API clients can construct a valid launch payload."""
    schema = []
    for workflow_input in workflow.inputs.all():
        content_type = None
        if workflow_input.content_type:
            content_type = f"{workflow_input.content_type.app_label}.{workflow_input.content_type.model}"

        schema.append(
            {
                "key": workflow_input.key,
                "label": workflow_input.label,
                "type": workflow_input.input_type,
                "required": workflow_input.required,
                "default": workflow_input.default,
                "choices": workflow_input.choices,
                "content_type": content_type,
                "depends_on": workflow_input.depends_on or [],
                "visible_when": workflow_input.visible_when,
                "validators": workflow_input.validators,
                "columns": workflow_input.columns,
                "order": workflow_input.order,
            }
        )
    return schema
