"""Views for the workflow launcher plugin."""

import io
import json
import logging
import secrets
import time
from datetime import datetime, timedelta
from datetime import timezone as dt_timezone
from math import ceil, floor
from urllib.parse import urlencode, urlsplit

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.db.models import Count, OuterRef, Q, Subquery
from django.db.models.functions import Coalesce, TruncDay, TruncWeek
from django.http import FileResponse, Http404, JsonResponse, QueryDict
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.dateparse import parse_datetime
from django.utils.http import url_has_allowed_host_and_scheme
from django.views import View
from django.views.generic import FormView, TemplateView
from nautobot.apps.views import NautobotUIViewSet, ObjectView

from .executors import _get_workflow_queryset
from .filters import WorkflowFilterSet
from .forms import DynamicWorkflowForm, ProblemReportForm
from .launching import WorkflowLaunchError, launch_workflow
from .models import ProblemReport, Workflow, WorkflowInput, WorkflowRun, WorkflowRunArtifact
from .run_progress import serialize_workflow_run_progress
from .scheduling import (
    WorkflowRunCancellationError,
    cancel_scheduled_run,
    user_can_cancel_run,
)
from .servicenow import ServiceNowValidationError
from .tables import WorkflowTable
from .ui_helpers import (
    RUN_STATUS_ORDER,
    STATUS_CHART_COLORS,
    build_input_rows,
    describe_action,
    format_duration,
    format_minutes,
    render_workflow_guide,
    run_status_meta,
    sorted_actions,
)

logger = logging.getLogger(__name__)
PLUGIN_CFG = settings.PLUGINS_CONFIG.get("nautobot_workflow_launcher", {})

VIEW_WORKFLOW_PERM = "nautobot_workflow_launcher.view_workflow"
ADD_RUN_PERM = "nautobot_workflow_launcher.add_workflowrun"
VIEW_RUN_PERM = "nautobot_workflow_launcher.view_workflowrun"

RUN_HISTORY_PAGE_SIZE_OPTIONS = (10, 25, 50, 100)
RUN_HISTORY_DEFAULT_PAGE_SIZE = 50
RUN_HISTORY_SESSION_KEY = "nautobot_workflow_launcher_run_history_filters"
RUN_HISTORY_PERSISTED_KEYS = ("workflow", "status", "user", "category", "time_range", "start", "end", "per_page")
CATALOG_DISPLAY_SESSION_KEY = "nautobot_workflow_launcher_catalog_display"
CATALOG_DISPLAY_OPTIONS = ("tiles", "list")
UNCATEGORIZED_KEY = "__uncategorized__"
UNCATEGORIZED_LABEL = "Uncategorized"
TIME_RANGE_DAYS = {"7d": 7, "30d": 30, "90d": 90, "365d": 365}
TIME_RANGE_LABELS = {"7d": "Last 7 days", "30d": "Last 30 days", "90d": "Last 90 days", "365d": "Last 365 days"}
RECENT_RUNS_LIMIT = 5


class ReportProblemView(LoginRequiredMixin, FormView):
    """Accept a permission-scoped problem report and queue email delivery."""

    template_name = "nautobot_workflow_launcher/problem_report.html"
    form_class = ProblemReportForm

    def _request_value(self, query_name, post_name):
        """Return context from POST when present, otherwise from the query string."""
        if self.request.method == "POST":
            return self.request.POST.get(post_name, "")
        return self.request.GET.get(query_name, "")

    def _resolve_run(self):
        """Resolve run context without revealing inaccessible or malformed identifiers."""
        value = self._request_value("run", "context_run")
        if not value:
            return None
        try:
            workflow_run = WorkflowRun.objects.select_related("workflow").get(pk=value)
        except (WorkflowRun.DoesNotExist, ValidationError, ValueError):
            return None
        if not self.request.user.has_perm(VIEW_RUN_PERM, workflow_run):
            return None
        return workflow_run

    def _resolve_workflow(self, workflow_run=None):
        """Resolve visible workflow context, preferring an authorized run's workflow."""
        if workflow_run is not None:
            return workflow_run.workflow
        value = self._request_value("workflow", "context_workflow")
        if not value:
            return None
        try:
            workflow = Workflow.objects.get(key=value)
        except Workflow.DoesNotExist:
            return None
        if not self.request.user.has_perm(VIEW_WORKFLOW_PERM, workflow):
            return None
        return workflow

    def _safe_page_path(self):
        """Return a same-origin path and query, never an external URL or fragment."""
        value = self._request_value("page", "context_page").strip()
        if not value or not url_has_allowed_host_and_scheme(
            value,
            allowed_hosts={self.request.get_host()},
            require_https=self.request.is_secure(),
        ):
            return ""
        parsed = urlsplit(value)
        path = parsed.path or "/"
        if not path.startswith("/"):
            return ""
        return f"{path}?{parsed.query}" if parsed.query else path

    @staticmethod
    def _sanitize_user_agent(value):
        """Remove control characters and cap browser metadata before persistence."""
        return "".join(character for character in (value or "") if character.isprintable())[:500]

    def _context_objects(self):
        workflow_run = self._resolve_run()
        return workflow_run, self._resolve_workflow(workflow_run), self._safe_page_path()

    def get_form_kwargs(self):
        """Provide permission-scoped querysets and preselect URL context on GET."""
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        if self.request.method == "GET":
            workflow_run, workflow, _page_path = self._context_objects()
            kwargs.setdefault("initial", {}).update(
                {
                    "workflow_context": workflow,
                    "workflow_run_context": workflow_run,
                }
            )
        return kwargs

    @staticmethod
    def _form_context(form):
        """Return context selected through permission-scoped form querysets."""
        workflow_run = form.cleaned_data.get("workflow_run_context")
        workflow = workflow_run.workflow if workflow_run else form.cleaned_data.get("workflow_context")
        return workflow_run, workflow

    def get_context_data(self, **kwargs):
        """Add only permission-checked context and safe navigation targets."""
        context = super().get_context_data(**kwargs)
        workflow_run, workflow, page_path = self._context_objects()
        form = context.get("form")
        if form is not None and form.is_bound and hasattr(form, "cleaned_data"):
            selected_run, selected_workflow = self._form_context(form)
            workflow_run = selected_run or workflow_run
            workflow = selected_workflow or workflow
        context.update(
            {
                "context_run": workflow_run,
                "context_workflow": workflow,
                "context_page": page_path,
                "cancel_url": page_path
                or (workflow_run.get_absolute_url() if workflow_run else "")
                or (workflow.get_absolute_url() if workflow else "")
                or reverse("plugins:nautobot_workflow_launcher:workflows_list"),
            }
        )
        return context

    def form_valid(self, form):
        """Persist the report before asynchronously attempting email delivery."""
        limit = max(1, int(PLUGIN_CFG.get("problem_report_rate_limit_per_hour", 10)))
        cutoff = timezone.now() - timedelta(hours=1)
        if ProblemReport.objects.filter(reported_by=self.request.user, created_at__gte=cutoff).count() >= limit:
            form.add_error(None, "You have submitted several reports recently. Please wait before trying again.")
            return self.form_invalid(form)

        workflow_run, workflow = self._form_context(form)
        page_path = self._safe_page_path()
        report = form.save(commit=False)
        report.reported_by = self.request.user
        report.workflow_run = workflow_run
        report.workflow = workflow
        report.page_url = page_path
        report.user_agent = self._sanitize_user_agent(self.request.META.get("HTTP_USER_AGENT", ""))
        if not (self.request.user.email or "").strip():
            report.acknowledgment_status = "skipped"
        report.save()

        try:
            from .tasks import send_problem_report_emails

            send_problem_report_emails.delay(str(report.pk))
        except Exception as exc:  # noqa: BLE001
            report.support_delivery_status = "failed"
            report.support_delivery_error = f"Unable to queue email delivery: {exc}"[:1000]
            if report.acknowledgment_status != "skipped":
                report.acknowledgment_status = "failed"
                report.acknowledgment_error = "Unable to queue acknowledgment delivery."
            report.save(
                update_fields=[
                    "support_delivery_status",
                    "support_delivery_error",
                    "acknowledgment_status",
                    "acknowledgment_error",
                    "updated_at",
                ]
            )

        messages.success(self.request, f"Problem report {report.reference} was submitted.")
        if report.acknowledgment_status == "skipped":
            messages.warning(
                self.request,
                "Your account has no email address, so an acknowledgment email could not be sent.",
            )
        return redirect(
            page_path
            or (workflow_run.get_absolute_url() if workflow_run else "")
            or (workflow.get_absolute_url() if workflow else "")
            or reverse("plugins:nautobot_workflow_launcher:workflows_list")
        )


def _category_label(category):
    """Return the display label for a (possibly blank) workflow category."""
    return category or UNCATEGORIZED_LABEL


def _category_key(category):
    """Return the filter key for a (possibly blank) workflow category."""
    return category or UNCATEGORIZED_KEY


def _filter_by_category(queryset, category, field="category"):
    """Filter a queryset by category key, supporting the synthetic 'uncategorized' key."""
    if not category:
        return queryset
    if category == UNCATEGORIZED_KEY:
        return queryset.filter(Q(**{field: ""}) | Q(**{f"{field}__isnull": True}))
    return queryset.filter(**{field: category})


def _visible_recent_runs(user, queryset, limit=RECENT_RUNS_LIMIT):
    """Return the most recent runs from `queryset` that the user may view."""
    return list(queryset.restrict(user, "view").select_related("workflow", "requested_by").order_by("-started")[:limit])


def _parse_window(time_range, start, end, default_days=None):
    """Resolve a preset time range or custom ISO start/end into aware datetimes (or (None, None))."""
    if start and end:
        start_dt = parse_datetime(start)
        end_dt = parse_datetime(end)
        if start_dt and end_dt:
            if timezone.is_naive(start_dt):
                start_dt = timezone.make_aware(start_dt, dt_timezone.utc)
            if timezone.is_naive(end_dt):
                end_dt = timezone.make_aware(end_dt, dt_timezone.utc)
            return start_dt, end_dt
    days = TIME_RANGE_DAYS.get(time_range, default_days)
    if days:
        now = timezone.now()
        return now - timedelta(days=days), now
    return None, None


def _median(values):
    """Return the median of a non-empty list of numbers."""
    ordered = sorted(values)
    midpoint = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[midpoint]
    return (ordered[midpoint - 1] + ordered[midpoint]) / 2


def _percent(part, whole):
    """Return part/whole as a percentage (0 when whole is 0)."""
    return (part / whole * 100.0) if whole else 0.0


class WorkflowUIViewSet(NautobotUIViewSet):
    """UIViewSet for Workflow model to enable search functionality."""

    queryset = Workflow.objects.all()

    filterset_class = WorkflowFilterSet
    table_class = WorkflowTable

    def get_queryset(self):
        """Return workflows allowed by the disabled-workflow display setting."""
        return _get_workflow_queryset()


def _category_name_from_key(key):
    """Return the display name for a category filter key."""
    return UNCATEGORIZED_LABEL if key == UNCATEGORIZED_KEY else key


class WorkflowListView(PermissionRequiredMixin, TemplateView):
    """Workflow catalog: browse, search and launch workflows grouped by category."""

    template_name = "nautobot_workflow_launcher/workflow_list.html"
    permission_required = VIEW_WORKFLOW_PERM

    def _get_permitted_workflows(self):
        """Return launchable workflows the user may view."""
        return _get_workflow_queryset().restrict(self.request.user, "view").order_by("category", "name")

    def get_queryset(self):
        """Return permitted workflows filtered by category and annotated with last-run details."""
        queryset = _filter_by_category(self._get_permitted_workflows(), self.request.GET.get("category", ""))
        latest_run = WorkflowRun.objects.filter(workflow_id=OuterRef("pk")).order_by("-started", "-id")
        run_count = (
            WorkflowRun.objects.filter(workflow_id=OuterRef("pk"))
            .order_by()
            .values("workflow_id")
            .annotate(total=Count("id"))
            .values("total")
        )
        return queryset.annotate(
            last_run_pk=Subquery(latest_run.values("pk")[:1]),
            last_run_started=Subquery(latest_run.values("started")[:1]),
            last_run_requested_by=Subquery(latest_run.values("requested_by__username")[:1]),
            last_run_status=Subquery(latest_run.values("status")[:1]),
            run_count=Subquery(run_count[:1]),
        ).defer("guide_content")

    def _get_display(self):
        """Return the catalog display mode, remembering an explicit choice in the session."""
        requested = self.request.GET.get("display")
        if requested in CATALOG_DISPLAY_OPTIONS:
            self.request.session[CATALOG_DISPLAY_SESSION_KEY] = requested
            return requested
        stored = self.request.session.get(CATALOG_DISPLAY_SESSION_KEY)
        return stored if stored in CATALOG_DISPLAY_OPTIONS else CATALOG_DISPLAY_OPTIONS[0]

    def get_context_data(self, **kwargs):
        """Build catalog context: category chips, grouped workflows and the user's recent runs."""
        context = super().get_context_data(**kwargs)
        user = self.request.user
        selected_category = self.request.GET.get("category", "")
        display = self._get_display()

        category_counts = {}
        for category in self._get_permitted_workflows().values_list("category", flat=True):
            key = _category_key(category)
            category_counts[key] = category_counts.get(key, 0) + 1
        category_chips = [
            {
                "key": key,
                "name": _category_name_from_key(key),
                "count": count,
                "is_active": key == selected_category,
                "query": urlencode({"category": key}),
            }
            for key, count in sorted(
                category_counts.items(), key=lambda item: (item[0] == UNCATEGORIZED_KEY, item[0].lower())
            )
        ]

        workflows = list(self.get_queryset())
        groups = {}
        for workflow in workflows:
            key = _category_key(workflow.category)
            groups.setdefault(key, {"key": key, "name": _category_label(workflow.category), "workflows": []})
            groups[key]["workflows"].append(workflow)
        workflow_groups = sorted(
            groups.values(), key=lambda group: (group["key"] == UNCATEGORIZED_KEY, group["name"].lower())
        )

        can_view_runs = user.has_perm(VIEW_RUN_PERM)
        recent_runs = []
        if can_view_runs and user.is_authenticated:
            recent_runs = _visible_recent_runs(user, WorkflowRun.objects.filter(requested_by=user))

        base_params = {"category": selected_category} if selected_category else {}
        context.update(
            {
                "workflows": workflows,
                "workflow_groups": workflow_groups,
                "category_chips": category_chips,
                "total_workflow_count": sum(category_counts.values()),
                "selected_category": selected_category,
                "selected_category_label": _category_name_from_key(selected_category),
                "display": display,
                "is_tiles_display": display == "tiles",
                "display_queries": {
                    option: urlencode({**base_params, "display": option}) for option in CATALOG_DISPLAY_OPTIONS
                },
                "can_execute_workflows": user.has_perm(ADD_RUN_PERM),
                "can_view_runs": can_view_runs,
                "recent_runs": recent_runs,
            }
        )
        return context


class WorkflowGuideView(PermissionRequiredMixin, View):
    """Return the rendered user guide for a workflow as an HTML fragment."""

    permission_required = VIEW_WORKFLOW_PERM

    def get(self, request, key):
        """Render the guide fragment, or 404 when the workflow has no guide."""
        workflow = get_object_or_404(_get_workflow_queryset(), key=key)
        if not request.user.has_perm(VIEW_WORKFLOW_PERM, workflow):
            raise Http404
        guide_html = render_workflow_guide(workflow)
        if not guide_html:
            raise Http404
        return render(
            request,
            "nautobot_workflow_launcher/inc/workflow_guide_body.html",
            {"workflow": workflow, "guide_html": guide_html},
        )


class WorkflowRunCreateView(PermissionRequiredMixin, TemplateView):
    """Launch a workflow through its dynamic input form."""

    template_name = "nautobot_workflow_launcher/workflow_launch.html"
    confirmation_template_name = "nautobot_workflow_launcher/workflow_confirm.html"
    permission_required = ADD_RUN_PERM
    confirmation_session_key = "workflow_launcher_pending_confirmations"
    confirmation_max_age_seconds = 30 * 60
    confirmation_limit = 5

    def _get_workflow(self, key):
        """Return the launchable workflow, hiding workflows the user may not view."""
        workflow = get_object_or_404(_get_workflow_queryset(), key=key)
        if not self.request.user.has_perm(VIEW_WORKFLOW_PERM, workflow):
            raise Http404
        return workflow

    def _get_prefill_run(self, workflow):
        """Return the ?from_run= run when it belongs to this workflow and is visible to the user."""
        from_run = self.request.GET.get("from_run")
        if not from_run:
            return None
        try:
            run = WorkflowRun.objects.select_related("requested_by").get(pk=from_run, workflow=workflow)
        except (WorkflowRun.DoesNotExist, ValidationError, ValueError):
            return None
        if not self.request.user.has_perm(VIEW_RUN_PERM, run):
            return None
        return run

    @staticmethod
    def _initial_from_run(workflow, prev_run):
        """Map a previous run's stored inputs onto the shapes the form widgets expect (scheduling excluded)."""
        initial = {}
        if not prev_run or not isinstance(prev_run.inputs, dict):
            return initial
        for wi in workflow.inputs.all():
            val = prev_run.inputs.get(wi.key)
            if val is None:
                continue
            if wi.input_type in ("list", "listdict"):
                initial[wi.key] = val if isinstance(val, str) else json.dumps(val)
            elif wi.input_type == "boolean":
                initial[wi.key] = bool(val)
            elif wi.input_type == "object":
                initial[wi.key] = str(val.get("id") or val.get("pk") or "") if isinstance(val, dict) else str(val)
            elif wi.input_type in ("multichoice", "multiobject"):
                values = val if isinstance(val, (list, tuple)) else [val]
                initial[wi.key] = [
                    str(item.get("id") or item.get("pk") or "") if isinstance(item, dict) else str(item)
                    for item in values
                ]
            elif wi.input_type == "choice":
                initial[wi.key] = "" if val in (None, "") else str(val)
            else:
                initial[wi.key] = val
        return initial

    def _build_launch_context(self, workflow, form, prefill_run=None):
        """Return the template context shared by GET and invalid-POST renders."""
        user = self.request.user
        input_fields = [field for field in form if field.name not in DynamicWorkflowForm.TIMING_FIELDS]
        input_sections = []
        for field in input_fields:
            title = form.field_sections.get(field.name, "")
            if not input_sections or input_sections[-1]["title"] != title:
                input_sections.append({"title": title, "fields": []})
            input_sections[-1]["fields"].append(field)

        workflow_runs = WorkflowRun.objects.filter(workflow=workflow)
        can_view_runs = user.has_perm(VIEW_RUN_PERM)
        return {
            "workflow": workflow,
            "form": form,
            "input_sections": input_sections,
            "input_field_count": len(input_fields),
            "required_field_count": sum(
                1 for field in input_fields if field.field.widget.attrs.get("data-required") == "true"
            ),
            "workflow_steps": [describe_action(action) for action in sorted_actions(workflow.actions.all())],
            "listdict_schemas": [
                {"script_id": f"listdict-columns-{wi.key}", "columns": wi.columns}
                for wi in workflow.inputs.all()
                if wi.input_type == "listdict" and wi.columns
            ],
            "prefill_run": prefill_run,
            "can_view_runs": can_view_runs,
            "recent_runs": _visible_recent_runs(user, workflow_runs) if can_view_runs else [],
            "run_count": workflow_runs.restrict(user, "view").count() if can_view_runs else None,
        }

    def get_context_data(self, **kwargs):
        """Build the launch form, optionally prefilled from ?from_run=<pk> of the same workflow."""
        context = super().get_context_data(**kwargs)
        workflow = self._get_workflow(kwargs["key"])
        prefill_run = self._get_prefill_run(workflow)
        form = DynamicWorkflowForm(workflow, initial=self._initial_from_run(workflow, prefill_run))
        context.update(self._build_launch_context(workflow, form, prefill_run))
        return context

    def _render_form(self, workflow, form):
        """Re-render the launch form with errors after an unsuccessful submission."""
        return render(self.request, self.template_name, self._build_launch_context(workflow, form))

    @staticmethod
    def _serialize_post_data(post_data):
        """Return JSON-safe posted form values without CSRF or confirmation controls."""
        excluded = {"csrfmiddlewaretoken", "confirmation_token", "confirmation_action"}
        return {key: post_data.getlist(key) for key in post_data if key not in excluded}

    @staticmethod
    def _deserialize_post_data(serialized):
        """Rebuild a QueryDict so the dynamic form repeats normal coercion and validation."""
        data = QueryDict("", mutable=True)
        for key, values in serialized.items():
            data.setlist(key, values if isinstance(values, list) else [values])
        return data

    def _prune_confirmations(self, pending):
        """Drop expired entries and cap session storage for concurrent launch tabs."""
        cutoff = time.time() - self.confirmation_max_age_seconds
        entries = [
            (token, value)
            for token, value in pending.items()
            if isinstance(value, dict) and float(value.get("created", 0)) >= cutoff
        ]
        entries.sort(key=lambda item: float(item[1].get("created", 0)), reverse=True)
        return dict(entries[: self.confirmation_limit])

    def _create_confirmation(self, workflow, post_data):
        """Store the validated request server-side and return an opaque browser token."""
        pending = self._prune_confirmations(dict(self.request.session.get(self.confirmation_session_key, {})))
        token = secrets.token_urlsafe(32)
        pending[token] = {
            "workflow_id": str(workflow.pk),
            "user_id": str(self.request.user.pk),
            "created": time.time(),
            "post_data": self._serialize_post_data(post_data),
        }
        self.request.session[self.confirmation_session_key] = self._prune_confirmations(pending)
        self.request.session.modified = True
        return token

    def _get_confirmation(self, workflow, token, *, consume=False):
        """Return a pending confirmation only when it belongs to this user and workflow."""
        pending = self._prune_confirmations(dict(self.request.session.get(self.confirmation_session_key, {})))
        value = pending.get(token)
        valid = bool(
            value and value.get("workflow_id") == str(workflow.pk) and value.get("user_id") == str(self.request.user.pk)
        )
        if not valid:
            value = None
        if consume and value:
            pending.pop(token, None)
        self.request.session[self.confirmation_session_key] = pending
        self.request.session.modified = True
        return value

    @staticmethod
    def _form_launch_data(form):
        """Split validated workflow inputs from execution timing controls."""
        inputs = dict(form.cleaned_data)
        execution_type = inputs.pop("execution_type", "immediate")
        scheduled_datetime = inputs.pop("scheduled_datetime", None)
        return inputs, execution_type, scheduled_datetime

    @staticmethod
    def _form_duration_seconds(post_data):
        """Return the non-negative form-fill duration posted by the browser."""
        try:
            return max(0, int(post_data.get("form_duration_seconds", "0") or "0"))
        except (TypeError, ValueError):
            return 0

    def _render_confirmation(self, workflow, form, token):
        """Render resolved inputs, timing, and action plan without creating a run."""
        inputs, execution_type, scheduled_datetime = self._form_launch_data(form)
        preview_run = WorkflowRun(workflow=workflow, requested_by=self.request.user, inputs=inputs)
        execution_labels = dict(form.fields["execution_type"].choices)
        return render(
            self.request,
            self.confirmation_template_name,
            {
                "workflow": workflow,
                "confirmation_token": token,
                "input_rows": build_input_rows(preview_run, self.request.user),
                "workflow_steps": [describe_action(action) for action in sorted_actions(workflow.actions.all())],
                "execution_type": execution_type,
                "execution_label": execution_labels.get(execution_type, execution_type.title()),
                "scheduled_datetime": scheduled_datetime,
                "change_ticket": inputs.get(workflow.servicenow_change_input_key, "")
                if workflow.servicenow_change_input_key
                else "",
            },
        )

    def _launch_valid_form(self, workflow, form, post_data):
        """Launch from a freshly validated confirmation payload."""
        inputs, execution_type, scheduled_datetime = self._form_launch_data(form)
        try:
            result = launch_workflow(
                workflow,
                self.request.user,
                inputs,
                execution_type=execution_type,
                scheduled_datetime=scheduled_datetime,
                form_duration_seconds=self._form_duration_seconds(post_data),
            )
        except ServiceNowValidationError as exc:
            change_input_key = workflow.servicenow_change_input_key
            if change_input_key and change_input_key in form.fields:
                form.add_error(change_input_key, str(exc))
            else:
                form.add_error(None, str(exc))
            return self._render_form(workflow, form)
        except WorkflowLaunchError as exc:
            form.add_error(None, str(exc))
            return self._render_form(workflow, form)

        if result.execution_type == "scheduled":
            scheduled_display = result.scheduled_for.strftime("%Y-%m-%d %H:%M")
            if result.schedule_source == "servicenow":
                messages.info(
                    self.request,
                    f"Scheduling requested for '{workflow.name}' from ServiceNow change "
                    f"{result.schedule_change_ticket} at {scheduled_display} UTC. Pre-actions are now running.",
                )
            else:
                messages.info(
                    self.request,
                    f"Scheduling requested for '{workflow.name}' at {scheduled_display} UTC. "
                    "Pre-actions are now running.",
                )

        return redirect("plugins:nautobot_workflow_launcher:workflow_run", pk=result.workflow_run.pk)

    def post(self, request, key):
        """Validate for review, then revalidate and launch only after explicit confirmation."""
        wf = self._get_workflow(key)
        confirmation_token = request.POST.get("confirmation_token", "")
        confirmation_action = request.POST.get("confirmation_action", "")

        if confirmation_token and confirmation_action in {"edit", "confirm"}:
            pending = self._get_confirmation(wf, confirmation_token, consume=True)
            if not pending:
                messages.error(request, "This confirmation expired or was already used. Review the workflow again.")
                return redirect("plugins:nautobot_workflow_launcher:workflow_launch", key=wf.key)

            post_data = self._deserialize_post_data(pending.get("post_data", {}))
            form = DynamicWorkflowForm(wf, data=post_data)
            if confirmation_action == "edit":
                form.is_valid()
                return self._render_form(wf, form)
            if not form.is_valid():
                return self._render_form(wf, form)
            return self._launch_valid_form(wf, form, post_data)

        form = DynamicWorkflowForm(wf, data=request.POST)
        if not form.is_valid():
            return self._render_form(wf, form)

        token = self._create_confirmation(wf, request.POST)
        return self._render_confirmation(wf, form, token)


class InputOptionsView(PermissionRequiredMixin, View):
    """Return filtered options for a dependent object field."""

    permission_required = ADD_RUN_PERM
    raise_exception = True

    def _build_enhanced_context(self, workflow, form_data):
        """Build context with both IDs and resolved object properties."""
        context = {"inputs": {}}

        for key, value in form_data.items():
            if not value:
                continue

            # Try to resolve object and add its properties
            try:
                wi = workflow.inputs.get(key=key)
                if wi.content_type:
                    model = wi.content_type.model_class()
                    obj = model.objects.get(pk=value)

                    # Add object with all useful properties
                    context["inputs"][key] = {
                        "id": obj.pk,
                        "name": getattr(obj, "name", str(obj)),
                        "slug": getattr(obj, "slug", None),
                        "description": getattr(obj, "description", None),
                        "__str__": str(obj),  # Default string representation
                    }

                    # Also make the object accessible for template rendering as just the ID (backward compatibility)
                    # This ensures "{{ inputs.tenant }}" still works for ID-based filters
                    context["inputs"][f"{key}_id"] = value
                else:
                    # Non-object field, just use the value
                    context["inputs"][key] = value
            except Exception:
                # Fall back to just the value if resolution fails
                context["inputs"][key] = value

        return context

    def get(self, request, key, child):
        """Get filtered options for a dependent field (object or choice with Jinja)."""
        qs = _get_workflow_queryset()
        wf = get_object_or_404(qs, key=key)
        if not request.user.has_perm(VIEW_WORKFLOW_PERM, wf):
            raise Http404
        try:
            wi = wf.inputs.get(key=child)
        except WorkflowInput.DoesNotExist:
            raise Http404

        # Handle object fields
        if wi.input_type in ("object", "multiobject") and wi.content_type:
            return self._handle_object_field(request, wf, wi)

        # Handle choice fields with Jinja templates
        if wi.input_type in ("choice", "multichoice") and wi.choices:
            return self._handle_choice_field(request, wf, wi)

        raise Http404

    def _handle_object_field(self, request, wf, wi):
        """Handle object field options with optional REST API search."""
        # Check if this is a server-side search request
        search_term = request.GET.get("search", "").strip()
        use_api_search = bool(search_term)

        if use_api_search:
            return self._handle_api_search(request, wf, wi, search_term)

        # For non-search requests, load first 200 entries using ORM
        return self._handle_orm_query(request, wf, wi, default_limit=200)

    def _handle_api_search(self, request, wf, wi, search_term):
        """Handle object field search using Nautobot REST API with proper authentication."""
        import requests

        try:
            # Get the model info
            app_label = wi.content_type.app_label

            api_endpoint = wi.content_type.model_class()._meta.verbose_name_plural.replace(" ", "-")

            # Build API URL
            api_path = f"/api/{app_label}/{api_endpoint}/"

            # Get the base URL
            base_url = request.build_absolute_uri("/").rstrip("/")
            api_url = f"{base_url}{api_path}"

            # Prepare API parameters
            params = {
                "q": search_term,
                "limit": int(request.GET.get("limit", 50)),
                "offset": int(request.GET.get("offset", 0)),
                "format": "json",
            }
            logger.info(f"Making API request to {api_url} with params: {params}")

            # Prepare headers with authentication
            headers = {
                "Content-Type": "application/json",
                "User-Agent": "Nautobot-Workflow-Launcher/1.0",
            }

            # Add authentication headers from the original request
            if hasattr(request, "user") and request.user.is_authenticated:
                # For session-based auth, we need to include session cookies
                session_cookies = request.COOKIES

                # If we have a session cookie, use it
                if "sessionid" in session_cookies:
                    headers["Cookie"] = f"sessionid={session_cookies['sessionid']}"

                # Also add CSRF token if available
                if "csrftoken" in session_cookies:
                    headers["X-CSRFToken"] = session_cookies["csrftoken"]

            # Make the API request
            response = requests.get(api_url, params=params, headers=headers, timeout=120)
            response.raise_for_status()

            api_data = response.json()
            results = api_data.get("results", [])
            id_list = [item["id"] for item in results]
            model = wi.content_type.model_class()
            qs = model.objects.filter(id__in=id_list)

            # Apply additional filters from wi.filter_query
            context = self._build_enhanced_context(wf, request.GET)
            from .executors import _render

            rendered_filters = {}
            if wi.filter_query:
                try:
                    rendered_filters = _render(wi.filter_query, context, repo=wf.source_repo)
                except Exception as e:
                    logger.error(f"Error rendering filter query for API search: {e}")

            # Clean filters and apply
            clean_filters = {k: v for k, v in rendered_filters.items() if v not in (None, "")}
            if clean_filters:
                qs = qs.filter(**clean_filters)

            # Use distinct() to prevent duplicates from JOIN operations (e.g., filtering by related models)
            qs = qs.distinct()

            # Convert API response to our expected format
            data = []

            for obj in qs:
                display_name = (
                    getattr(obj, "display", None)
                    or getattr(obj, "display_name", None)
                    or getattr(obj, "name", None)
                    or getattr(obj, "label", None)
                    or getattr(obj, "prefix", None)
                    or getattr(obj, "address", None)
                    or getattr(obj, "hostname", None)
                    or str(obj)
                )
                data.append({"value": str(obj.pk), "label": display_name})

            response_data = {
                "options": data,
                "total_count": len(data),
                "has_more": bool(api_data.get("next")),
                "limit": params["limit"],
                "offset": params["offset"],
            }

            logger.info(f"API search returned {len(data)} results")
            return JsonResponse(response_data)

        except requests.RequestException as e:
            logger.error(f"API request failed: {e}")
            # Fallback to ORM query
            return self._handle_orm_query(request, wf, wi)
        except Exception as e:
            logger.error(f"Error in API search: {e}")
            # Fallback to ORM query
            return self._handle_orm_query(request, wf, wi)

    def _handle_orm_query(self, request, wf, wi, default_limit=50):
        """Handle object field options using direct ORM queries."""
        # Build enhanced context with resolved objects
        context = self._build_enhanced_context(wf, request.GET)

        # Render filter queries with enhanced context
        if wi.filter_query:
            from .executors import _render

            try:
                rendered_filters = _render(wi.filter_query, context, repo=wf.source_repo)
            except Exception as e:
                logger.error(f"Error rendering filter query for {wi.key}: {e}")
                rendered_filters = {}
        else:
            rendered_filters = {}

        # Apply filters to queryset
        model = wi.content_type.model_class()
        qs = model.objects.all()
        if rendered_filters:
            # Filter out None values and empty strings
            clean_filters = {k: v for k, v in rendered_filters.items() if v not in (None, "")}
            if clean_filters:
                qs = qs.filter(**clean_filters)

        # Use distinct() to prevent duplicates from JOIN operations (e.g., filtering by related models like devices__isnull)
        qs = qs.distinct()

        # Handle pagination
        limit = int(request.GET.get("limit", default_limit))
        offset = int(request.GET.get("offset", 0))
        total_count = qs.count()

        # Apply pagination
        qs = qs[offset : offset + limit]

        # Use display field for consistency with API search results
        data = []
        for obj in qs:
            # Try to get a good display name, similar to API search logic
            display_name = (
                getattr(obj, "display", None)  # Nautobot's main display field
                or getattr(obj, "display_name", None)  # Alternative display field
                or getattr(obj, "name", None)  # Name field
                or getattr(obj, "label", None)  # Label field
                or getattr(obj, "prefix", None)  # For prefix objects
                or getattr(obj, "address", None)  # For IP address objects
                or getattr(obj, "hostname", None)  # For device objects
                or str(obj)  # Fallback to string representation
            )
            data.append({"value": str(obj.pk), "label": display_name})

        # Check if we're supposed to prepend a "Create New XXX" to the dropdown
        show_add_new_item = [x.lower() for x in PLUGIN_CFG.get("show_add_new_item", [])]
        if f"{wi.content_type.app_label}.{wi.content_type.name}" in show_add_new_item:
            data.insert(0, {"value": "__create__", "label": f"Create New {wi.content_type.name.title()}"})

        response_data = {
            "options": data,
            "total_count": total_count,
            "has_more": offset + limit < total_count,
            "limit": limit,
            "offset": offset,
        }

        return JsonResponse(response_data)

    def _handle_choice_field(self, request, wf, wi):
        """Handle choice field options with Jinja templating."""
        # Build enhanced context with resolved objects
        context = self._build_enhanced_context(wf, request.GET)

        try:
            from .executors import _render

            # Handle choices - could be a string (JSON) or already parsed list
            choices_value = wi.choices

            # If choices is a string, try to render it as Jinja template first
            if isinstance(choices_value, str):
                rendered_choices_str = _render(choices_value, context, repo=wf.source_repo)

                # Try to parse as JSON
                try:
                    rendered_choices = json.loads(rendered_choices_str)
                except json.JSONDecodeError as e:
                    logger.error(f"Failed to parse choices as JSON for {wi.key}: {e}")
                    logger.error(f"Choices string was: {rendered_choices_str}")
                    return JsonResponse({"options": []})
            else:
                # Choices is already a list/object, render it directly
                rendered_choices = _render(choices_value, context, repo=wf.source_repo)

            # Convert to options format
            if isinstance(rendered_choices, list):
                data = []
                for choice in rendered_choices:
                    if isinstance(choice, dict):
                        # Choice is a dict with value/label
                        data.append(
                            {"value": choice.get("value", ""), "label": choice.get("label", choice.get("value", ""))}
                        )
                    else:
                        # Choice is a simple value
                        data.append({"value": str(choice), "label": str(choice)})
            else:
                logger.error(f"Rendered choices is not a list for {wi.key}: {rendered_choices}")
                data = []

            return JsonResponse({"options": data})

        except Exception as e:
            logger.error(f"Error rendering choices for {wi.key}: {e}")
            import traceback

            logger.error(f"Traceback: {traceback.format_exc()}")
            return JsonResponse({"options": []})


class WorkflowRunDetailView(ObjectView):
    """Live run console for an individual workflow run."""

    queryset = WorkflowRun.objects.select_related("workflow", "requested_by")
    template_name = "nautobot_workflow_launcher/workflow_run.html"

    def get_extra_context(self, request, instance):
        """Add the initial live state, pipeline, resolved inputs and action permissions."""
        context = super().get_extra_context(request, instance)
        workflow = instance.workflow
        run_state = serialize_workflow_run_progress(instance, include_logs=False)
        can_rerun = (
            request.user.has_perm(ADD_RUN_PERM)
            and _get_workflow_queryset().restrict(request.user, "view").filter(pk=workflow.pk).exists()
        )
        context.update(
            {
                # Show workflow info in run view even if workflow is now disabled
                "workflow_available": workflow.enabled if workflow else False,
                "run_state": run_state,
                "status_meta": run_status_meta(instance.status),
                "input_rows": build_input_rows(instance, request.user),
                "awx_run_count": len(run_state["awx_runs"]),
                "step_count": len(run_state["steps"]),
                "structured_results": run_state["results"],
                "artifacts": run_state["artifacts"],
                "can_rerun": can_rerun,
                "can_cancel": instance.status == "scheduled" and user_can_cancel_run(request.user, instance),
                "progress_url": reverse(
                    "plugins:nautobot_workflow_launcher:workflow_run_progress", kwargs={"pk": instance.pk}
                ),
            }
        )
        return context


class WorkflowRunArtifactView(View):
    """Download a single artifact produced by a workflow run."""

    def get(self, request, pk, artifact_pk):
        """Stream the artifact as an attachment after checking access to the parent run."""
        workflow_run = get_object_or_404(WorkflowRun.objects.select_related("workflow"), pk=pk)

        # Access is governed by the parent run, consistent with the rest of the run views.
        if not request.user.has_perm(VIEW_RUN_PERM, workflow_run):
            raise Http404

        artifact = get_object_or_404(WorkflowRunArtifact, pk=artifact_pk, workflow_run=workflow_run)

        content_type = artifact.content_type
        if content_type not in WorkflowRunArtifact.ALLOWED_CONTENT_TYPES:
            content_type = "application/octet-stream"

        response = FileResponse(
            io.BytesIO(bytes(artifact.data)),
            as_attachment=True,
            filename=artifact.name,
            content_type=content_type,
        )
        response["Content-Length"] = artifact.size
        response["X-Content-Type-Options"] = "nosniff"
        response["Content-Security-Policy"] = "default-src 'none'; sandbox"
        return response


class WorkflowRunCancelView(View):
    """Cancel a scheduled workflow run before execution starts."""

    def post(self, request, pk):
        """Cancel only scheduled runs and mark them as canceled."""
        workflow_run = get_object_or_404(WorkflowRun.objects.select_related("workflow", "scheduled_job"), pk=pk)

        # Keep behavior consistent with other run views: hide inaccessible objects.
        if not request.user.has_perm("nautobot_workflow_launcher.view_workflowrun", workflow_run):
            raise Http404

        if not user_can_cancel_run(request.user, workflow_run):
            messages.error(request, "You do not have permission to cancel this workflow run.")
            return redirect("plugins:nautobot_workflow_launcher:workflow_run", pk=workflow_run.pk)

        canceled_at = timezone.now()
        canceled_msg = (
            f"Workflow run canceled by {request.user.username} on {canceled_at.strftime('%Y-%m-%d %H:%M:%S %Z')} "
            "before execution."
        )
        try:
            cancel_scheduled_run(workflow_run, canceled_msg)
        except WorkflowRunCancellationError as exc:
            messages.info(request, str(exc))
            return redirect("plugins:nautobot_workflow_launcher:workflow_run", pk=workflow_run.pk)

        messages.success(request, "Scheduled workflow run canceled.")
        return redirect("plugins:nautobot_workflow_launcher:workflow_run", pk=pk)


class WorkflowRunProgressView(View):
    """Return live progress data for a workflow run detail page."""

    def get(self, request, pk):
        """Return JSON payload for partial run-detail updates."""
        workflow_run = get_object_or_404(
            WorkflowRun.objects.select_related("workflow", "requested_by").prefetch_related("awx_runs"),
            pk=pk,
        )

        if not request.user.has_perm("nautobot_workflow_launcher.view_workflowrun", workflow_run):
            raise Http404

        return JsonResponse(serialize_workflow_run_progress(workflow_run))


class WorkflowRunListView(PermissionRequiredMixin, TemplateView):
    """Run history with persisted filters, status quick-filters and pagination."""

    template_name = "nautobot_workflow_launcher/workflow_run_list.html"
    permission_required = VIEW_RUN_PERM
    _run_history_filter_state = None

    def _get_filter_state(self):
        """Return persisted filter/page-size state, updated from current query parameters."""
        if self._run_history_filter_state is not None:
            return self._run_history_filter_state

        session_state = self.request.session.get(RUN_HISTORY_SESSION_KEY, {}).copy()
        if not isinstance(session_state, dict):
            session_state = {}

        changed = False
        if self.request.GET.get("reset") in {"1", "true", "yes"}:
            session_state = {}
            changed = True

        for key in RUN_HISTORY_PERSISTED_KEYS:
            if key in self.request.GET:
                session_state[key] = self.request.GET.get(key, "")
                changed = True

        # Picking a preset time range replaces any remembered custom start/end window.
        if "time_range" in self.request.GET and "start" not in self.request.GET:
            session_state.pop("start", None)
            session_state.pop("end", None)

        if changed:
            self.request.session[RUN_HISTORY_SESSION_KEY] = session_state
            self.request.session.modified = True

        self._run_history_filter_state = session_state
        return self._run_history_filter_state

    def _get_filter_value(self, key, default=""):
        """Return effective filter value from current request/session state."""
        state = self._get_filter_state()
        return state.get(key, default)

    def _get_per_page(self):
        """Validate and return page size requested by the user."""
        raw_per_page = self._get_filter_value("per_page", str(RUN_HISTORY_DEFAULT_PAGE_SIZE))
        try:
            per_page = int(raw_per_page)
        except (TypeError, ValueError):
            return RUN_HISTORY_DEFAULT_PAGE_SIZE

        return per_page if per_page in RUN_HISTORY_PAGE_SIZE_OPTIONS else RUN_HISTORY_DEFAULT_PAGE_SIZE

    def _get_permitted_runs(self):
        """Return runs the user may view."""
        return WorkflowRun.objects.restrict(self.request.user, "view")

    def _filtered_queryset(self, apply_status=True):
        """Return permitted runs narrowed by the persisted filters."""
        qs = self._get_permitted_runs().select_related("workflow", "requested_by").order_by("-started")
        workflow_key = self._get_filter_value("workflow", "")
        if workflow_key:
            qs = qs.filter(workflow__key=workflow_key)

        status = self._get_filter_value("status", "")
        if apply_status and status:
            qs = qs.filter(status=status)

        user = self._get_filter_value("user", "")
        if user:
            qs = qs.filter(requested_by__username=user)

        qs = _filter_by_category(qs, self._get_filter_value("category", ""), field="workflow__category")

        start_dt, end_dt = _parse_window(
            self._get_filter_value("time_range", ""),
            self._get_filter_value("start", ""),
            self._get_filter_value("end", ""),
        )
        if start_dt and end_dt:
            qs = qs.filter(started__gte=start_dt, started__lte=end_dt)
        return qs

    def get_queryset(self):
        """Get workflow runs queryset with filtering."""
        return self._filtered_queryset()

    def get_context_data(self, **kwargs):
        """Add paginated runs, filter options and status quick-filter counts."""
        context = super().get_context_data(**kwargs)

        queryset = self.get_queryset()
        total_runs = queryset.count()
        per_page = self._get_per_page()
        paginator = Paginator(queryset, per_page)
        page_obj = paginator.get_page(self.request.GET.get("page"))
        selected = {
            key: self._get_filter_value(key, "")
            for key in ("workflow", "status", "user", "category", "time_range", "start", "end")
        }

        status_counts = dict(
            self._filtered_queryset(apply_status=False).order_by().values_list("status").annotate(count=Count("id"))
        )
        status_filters = [
            {
                "value": "",
                "label": "All",
                "tone": "",
                "icon": "mdi-format-list-bulleted",
                "count": sum(status_counts.values()),
                "is_active": not selected["status"],
            }
        ]
        for status in RUN_STATUS_ORDER:
            meta = run_status_meta(status)
            status_filters.append(
                {
                    "value": status,
                    "label": meta["label"],
                    "tone": meta["tone"],
                    "icon": meta["icon"],
                    "count": status_counts.get(status, 0),
                    "is_active": selected["status"] == status,
                }
            )

        permitted = self._get_permitted_runs().order_by()
        categories = set(permitted.values_list("workflow__category", flat=True).distinct())
        category_options = [
            {"key": _category_key(category), "name": _category_label(category)}
            for category in sorted(categories, key=lambda value: (not value, (value or "").lower()))
        ]

        query_params = {"per_page": str(per_page), **selected}
        context.update(
            {
                "object_list": page_obj.object_list,
                "workflow_runs": page_obj.object_list,
                "show_scheduled_for_column": queryset.filter(scheduled_for__isnull=False).exists(),
                "page_obj": page_obj,
                "paginator": paginator,
                "is_paginated": page_obj.has_other_pages(),
                "page_range": list(paginator.get_elided_page_range(page_obj.number, on_each_side=1, on_ends=1)),
                "page_ellipsis": Paginator.ELLIPSIS,
                "per_page": per_page,
                "per_page_options": RUN_HISTORY_PAGE_SIZE_OPTIONS,
                "total_runs": total_runs,
                "querystring_without_page": urlencode({k: v for k, v in query_params.items() if v not in (None, "")}),
                "status_filters": status_filters,
                "status_choices": WorkflowRun.STATUS_CHOICES,
                "workflows": [
                    {"key": row["workflow__key"], "name": row["workflow__name"]}
                    for row in permitted.values("workflow__key", "workflow__name").distinct().order_by("workflow__name")
                ],
                "users": permitted.values("requested_by__username", "requested_by__pk")
                .distinct()
                .order_by("requested_by__username"),
                "category_options": category_options,
                "time_range_options": [("", "Any time"), *TIME_RANGE_LABELS.items()],
                "has_active_filters": any(
                    selected[key] for key in ("workflow", "user", "category", "time_range", "start", "end")
                ),
                "can_execute_workflows": self.request.user.has_perm(ADD_RUN_PERM),
                "launchable_workflow_ids": set(
                    _get_workflow_queryset().restrict(self.request.user, "view").values_list("pk", flat=True)
                ),
                "selected_workflow": selected["workflow"],
                "selected_status": selected["status"],
                "selected_user": selected["user"],
                "selected_category": selected["category"],
                "selected_time_range": selected["time_range"],
                "selected_start": selected["start"],
                "selected_end": selected["end"],
            }
        )
        return context


class WorkflowReportView(PermissionRequiredMixin, TemplateView):
    """Operations dashboard: KPIs, outcomes, trends and automation time savings."""

    template_name = "nautobot_workflow_launcher/workflow_report.html"
    permission_required = VIEW_RUN_PERM

    def get_context_data(self, **kwargs):
        """Build KPI and chart-ready data for the selected scope."""
        context = super().get_context_data(**kwargs)
        params = self.request.GET
        selected_category = params.get("category", "")
        selected_status = params.get("status", "")
        selected_user = params.get("user", "")
        selected_time_range = params.get("time_range", "30d")
        selected_start = params.get("start", "")
        selected_end = params.get("end", "")
        start_dt, end_dt = _parse_window(selected_time_range, selected_start, selected_end, default_days=30)

        permitted = WorkflowRun.objects.restrict(self.request.user, "view")
        scope = _filter_by_category(permitted, selected_category, field="workflow__category")
        if selected_user:
            try:
                scope = scope.filter(requested_by__pk=str(selected_user))
            except (ValidationError, ValueError):
                scope = scope.none()
        base_qs = scope.filter(started__gte=start_dt, started__lte=end_dt)
        if selected_status:
            base_qs = base_qs.filter(status=selected_status)
        base_qs = base_qs.select_related("workflow", "requested_by")

        status_counts = dict(base_qs.order_by().values_list("status").annotate(count=Count("id")))
        total_runs = sum(status_counts.values())
        success_count = status_counts.get("success", 0)
        partial_count = status_counts.get("partial", 0)
        failed_count = status_counts.get("failed", 0)
        completed_count = success_count + partial_count + failed_count
        # Partial runs are their own outcome, so they are excluded from the headline success rate.
        decisive_count = success_count + failed_count
        durations = [
            (finished - started).total_seconds()
            for started, finished in base_qs.filter(finished__isnull=False)
            .annotate(run_started=Coalesce("execution_started", "started"))
            .values_list("run_started", "finished")
            if started and finished and finished >= started
        ]
        time_savings = self._calculate_time_savings(base_qs.filter(status="success"))
        kpis = {
            "total_runs": total_runs,
            "success_count": success_count,
            "partial_count": partial_count,
            "failed_count": failed_count,
            "completed_count": completed_count,
            "success_rate": _percent(success_count, decisive_count) if decisive_count else None,
            "in_flight": sum(status_counts.get(status, 0) for status in ("running", "pending", "scheduled")),
            "active_users": base_qs.order_by().values("requested_by").distinct().count(),
            "active_workflows": base_qs.order_by().values("workflow").distinct().count(),
            "median_duration": format_duration(_median(durations)) if durations else None,
            "time_saved": time_savings["time_saved_display"],
            "time_saved_runs": time_savings["runs_with_duration_count"],
        }

        ordered_statuses = [status for status in RUN_STATUS_ORDER if status_counts.get(status)]
        ordered_statuses += [
            status for status, count in status_counts.items() if count and status not in RUN_STATUS_ORDER
        ]
        status_breakdown = []
        gradient = []
        cursor = 0.0
        for index, status in enumerate(ordered_statuses):
            meta = run_status_meta(status)
            color = STATUS_CHART_COLORS.get(status, "var(--bs-secondary)")
            percent = _percent(status_counts[status], total_runs)
            end = 100.0 if index == len(ordered_statuses) - 1 else cursor + percent
            gradient.append(f"{color} {cursor:.2f}% {end:.2f}%")
            cursor = end
            status_breakdown.append(
                {
                    "status": status,
                    "label": meta["label"],
                    "tone": meta["tone"],
                    "icon": meta["icon"],
                    "color": color,
                    "count": status_counts[status],
                    "percent": percent,
                }
            )

        users = list(
            permitted.order_by()
            .values("requested_by__username", "requested_by__pk")
            .distinct()
            .order_by("requested_by__username")
        )
        selected_username = next(
            (row["requested_by__username"] for row in users if str(row["requested_by__pk"]) == str(selected_user)), ""
        )
        history_params = {"reset": "1"}
        if selected_category:
            history_params["category"] = selected_category
        if selected_status:
            history_params["status"] = selected_status
        if selected_username:
            history_params["user"] = selected_username
        is_custom_window = bool(selected_time_range == "custom" and selected_start and selected_end)
        if is_custom_window:
            history_params.update({"start": selected_start, "end": selected_end})
        elif selected_time_range in TIME_RANGE_DAYS:
            history_params["time_range"] = selected_time_range

        success_q = Q(status="success")
        failed_q = Q(status__in=("failed", "partial"))
        workflow_rows = list(
            base_qs.order_by()
            .values("workflow__key", "workflow__name", "workflow__category")
            .annotate(total=Count("id"), success=Count("id", filter=success_q), failed=Count("id", filter=failed_q))
            .order_by("-total", "workflow__name")[:10]
        )
        max_workflow_total = max((row["total"] for row in workflow_rows), default=0)
        workflow_leaderboard = []
        for row in workflow_rows:
            completed = row["success"] + row["failed"]
            workflow_leaderboard.append(
                {
                    "key": row["workflow__key"],
                    "name": row["workflow__name"],
                    "category": _category_label(row["workflow__category"]),
                    "total": row["total"],
                    "success": row["success"],
                    "failed": row["failed"],
                    "success_rate": _percent(row["success"], completed) if completed else None,
                    "percent": _percent(row["total"], max_workflow_total),
                    "history_query": urlencode({**history_params, "workflow": row["workflow__key"]}),
                }
            )

        category_rows = list(
            base_qs.order_by()
            .values("workflow__category")
            .annotate(total=Count("id"), success=Count("id", filter=success_q), failed=Count("id", filter=failed_q))
            .order_by("-total")
        )
        max_category_total = max((row["total"] for row in category_rows), default=0)
        category_breakdown = []
        for row in category_rows:
            other = row["total"] - row["success"] - row["failed"]
            completed = row["success"] + row["failed"]
            category_breakdown.append(
                {
                    "key": _category_key(row["workflow__category"]),
                    "name": _category_label(row["workflow__category"]),
                    "total": row["total"],
                    "success": row["success"],
                    "failed": row["failed"],
                    "other": other,
                    "success_percent": _percent(row["success"], max_category_total),
                    "failed_percent": _percent(row["failed"], max_category_total),
                    "other_percent": _percent(other, max_category_total),
                    "success_rate": _percent(row["success"], completed) if completed else None,
                }
            )

        user_rows = list(
            base_qs.order_by()
            .values("requested_by__username", "requested_by__pk")
            .annotate(count=Count("id"))
            .order_by("-count", "requested_by__username")[:10]
        )
        max_user_total = max((row["count"] for row in user_rows), default=0)
        user_leaderboard = [
            {
                "username": row["requested_by__username"],
                "pk": row["requested_by__pk"],
                "count": row["count"],
                "percent": _percent(row["count"], max_user_total),
            }
            for row in user_rows
        ]

        monthly = self._calculate_monthly_time_savings(scope)
        categories = (
            _get_workflow_queryset()
            .exclude(category="")
            .exclude(category__isnull=True)
            .values_list("category", flat=True)
            .distinct()
            .order_by("category")
        )
        if is_custom_window:
            window_label = f"{start_dt:%Y-%m-%d} to {end_dt:%Y-%m-%d}"
        else:
            window_label = TIME_RANGE_LABELS.get(selected_time_range, "Selected period")

        context.update(
            {
                "kpis": kpis,
                "status_breakdown": status_breakdown,
                "status_gradient": ", ".join(gradient),
                "usage": self._usage_series(base_qs, start_dt, end_dt),
                "workflow_leaderboard": workflow_leaderboard,
                "category_breakdown": category_breakdown,
                "user_leaderboard": user_leaderboard,
                "time_savings": time_savings,
                "monthly_time_savings": monthly,
                "monthly_total_display": format_minutes(sum(month["total_minutes"] for month in monthly)),
                "has_monthly_savings": any(month["total_minutes"] for month in monthly),
                "categories": list(categories),
                "status_choices": WorkflowRun.STATUS_CHOICES,
                "users": users,
                "time_range_options": [
                    ("7d", "7d", "Last 7 days"),
                    ("30d", "30d", "Last 30 days"),
                    ("90d", "90d", "Last 90 days"),
                    ("365d", "1y", "Last 365 days"),
                    ("custom", "Custom", "Custom range"),
                ],
                "selected_category": selected_category,
                "selected_status": selected_status,
                "selected_user": selected_user,
                "selected_time_range": selected_time_range,
                "selected_start": selected_start,
                "selected_end": selected_end,
                "window_label": window_label,
                "history_query": urlencode(history_params),
                "has_active_filters": bool(selected_category or selected_status or selected_user),
            }
        )
        return context

    @staticmethod
    def _usage_series(base_qs, start_dt, end_dt):
        """Return per-day (per-week beyond 90 days) run counts with empty buckets filled in."""
        weekly = (end_dt - start_dt).days > 90
        trunc = TruncWeek("started") if weekly else TruncDay("started")
        counts = {}
        for row in base_qs.order_by().annotate(bucket=trunc).values("bucket").annotate(count=Count("id")):
            bucket = row["bucket"]
            if bucket is None:
                continue
            if isinstance(bucket, datetime):
                bucket = timezone.localtime(bucket).date() if timezone.is_aware(bucket) else bucket.date()
            counts[bucket] = counts.get(bucket, 0) + row["count"]

        day = timezone.localtime(start_dt).date()
        end_day = timezone.localtime(end_dt).date()
        if weekly:
            day -= timedelta(days=day.weekday())
        step = timedelta(days=7 if weekly else 1)
        points = []
        while day <= end_day:
            points.append({"date": day, "count": counts.get(day, 0)})
            day += step

        peak = max((point["count"] for point in points), default=0)
        last_index = len(points) - 1
        tick_positions = set(range(len(points))) if len(points) <= 12 else {round(i * last_index / 5) for i in range(6)}
        for index, point in enumerate(points):
            point["percent"] = _percent(point["count"], peak)
            point["label"] = f"Week of {point['date']:%b %d, %Y}" if weekly else f"{point['date']:%a, %b %d, %Y}"
            point["tick"] = f"{point['date']:%b %d}" if index in tick_positions else ""
        return {
            "points": points,
            "bucket": "week" if weekly else "day",
            "peak": peak,
            "total": sum(point["count"] for point in points),
        }

    def _calculate_time_savings(self, recent_runs):
        """Calculate time savings from workflow automation over the last 30 days."""
        # Get runs with manual duration data and calculate totals
        runs_with_duration = recent_runs.select_related("workflow").filter(
            workflow__manual_duration_minutes__isnull=False
        )

        # Calculate total manual time that would have been required
        total_manual_minutes = 0
        total_automation_minutes = 0
        runs_count = 0

        for run in runs_with_duration:
            if run.workflow.manual_duration_minutes:
                total_manual_minutes += run.workflow.manual_duration_minutes
                runs_count += 1

                # Calculate actual workflow execution time and measured form-fill duration
                run_started = run.effective_started
                if run_started and run.finished and run.finished >= run_started:
                    execution_seconds = int((run.finished - run_started).total_seconds())
                    # Fallback to 60s (1 minute) for legacy runs without measured form duration
                    form_seconds = 60 if run.form_duration_seconds in (None, "") else int(run.form_duration_seconds)
                    total_automation_minutes += ceil((execution_seconds + form_seconds) / 60.0)

        # Calculate savings
        time_saved_minutes = total_manual_minutes - total_automation_minutes

        return {
            "total_manual_minutes": total_manual_minutes,
            "total_automation_time": total_automation_minutes,
            "total_automation_minutes": total_automation_minutes % 60,
            "total_automation_hours": floor(total_automation_minutes / 60),
            "time_saved_minutes": time_saved_minutes % 60,
            "time_saved_hours": floor(time_saved_minutes / 60),
            "time_saved_total_minutes": time_saved_minutes,
            "runs_with_duration_count": runs_count,
            "time_saved_display": format_minutes(time_saved_minutes),
            "manual_display": format_minutes(total_manual_minutes),
            "automation_display": format_minutes(total_automation_minutes),
            "savings_percent": max(0.0, _percent(time_saved_minutes, total_manual_minutes)),
            "automation_percent": min(100.0, _percent(total_automation_minutes, total_manual_minutes)),
        }

    def _calculate_monthly_time_savings(self, runs_queryset):
        """Aggregate time saved per month over the last 12 months.

        Returns a list of dicts sorted by month ascending (oldest to newest) with:
        - month_label: e.g. 'Jan 2025'
        - total_minutes: total time saved in that month (manual - automation)
        - hours, minutes: breakdown of total_minutes
        - percent_of_max: percent relative to maximum monthly saved minutes in the period
        """
        now = timezone.now()
        # Start from beginning of current month
        current_month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        # Collect month boundaries (12 months back including current)
        month_starts = []
        cursor = current_month_start
        for _ in range(12):
            month_starts.append(cursor)
            # Move back one month: subtract one day from the first of month then set day=1
            prev_month_last_day = cursor - timedelta(days=1)
            cursor = prev_month_last_day.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        # Reverse to oldest -> newest
        month_starts.reverse()

        # Helper to get next month start
        def next_month(dt):
            if dt.month == 12:
                return dt.replace(year=dt.year + 1, month=1)
            return dt.replace(month=dt.month + 1)

        monthly = []
        # Pre-fetch successful runs in the 12-month span for efficiency
        earliest_start = month_starts[0]
        all_runs = runs_queryset.filter(started__gte=earliest_start, status="success").select_related("workflow")

        for start in month_starts:
            end = next_month(start)
            runs = [
                r for r in all_runs if r.started >= start and r.started < end and r.workflow.manual_duration_minutes
            ]
            total_manual = 0
            total_automation = 0
            for run in runs:
                total_manual += run.workflow.manual_duration_minutes or 0
                run_started = run.effective_started
                if run_started and run.finished and run.finished >= run_started:
                    execution_seconds = int((run.finished - run_started).total_seconds())
                    form_seconds = 60 if run.form_duration_seconds in (None, "") else int(run.form_duration_seconds)
                    total_automation += ceil((execution_seconds + form_seconds) / 60.0)
            time_saved = max(total_manual - total_automation, 0)
            monthly.append(
                {
                    "month_label": start.strftime("%b %Y"),
                    "short_label": start.strftime("%b"),
                    "total_minutes": time_saved,
                    "display": format_minutes(time_saved),
                    "hours": floor(time_saved / 60),
                    "minutes": time_saved % 60,
                }
            )

        max_saved = max((m["total_minutes"] for m in monthly), default=0)
        for m in monthly:
            if max_saved > 0:
                m["percent_of_max"] = (m["total_minutes"] / max_saved) * 100
            else:
                m["percent_of_max"] = 0

            # Determine a simple CSS class for coloring in the template
            pct = m["percent_of_max"]
            if pct >= 70:
                m["bar_class"] = "best"
            elif pct >= 40:
                m["bar_class"] = "high"
            elif pct >= 20:
                m["bar_class"] = "med"
            else:
                m["bar_class"] = "low"

        return monthly
